/*
 * ============================================================================
 * NEON STICK WAR - NON-MINIFIED / BEAUTIFIED SOURCE CODE
 * ============================================================================
 * 
 * This is the beautified (readable) version of the game's core JavaScript.
 * Original file: 0cf1o-rq41zxz.js (minified, ~388KB)
 * This file:     0cf1o-rq41zxz.beautified.js (16,500+ lines, ~668KB)
 * 
 * ⚠️  NOTE: This file is for READING/ANALYSIS ONLY. The game still runs
 *     from the minified version. If you make changes here, you must also
 *     apply them to the minified file for them to take effect.
 * 
 * ============================================================================
 * NAVIGATION GUIDE - Key Sections by Line Number
 * ============================================================================
 * 
 * Lines 1-300:     styled-jsx / StyleSheet system (React CSS-in-JS)
 * Lines 301-303:   Module exports
 * Lines 304-340:   Zustand state management library
 * Lines 338-350:   COLOR PALETTE (n=cyan, i=magenta, s=green, c=orange, etc.)
 * Lines 350-386:   UPGRADE SYSTEM config (damage, fireRate, bulletSpeed, etc.)
 * Lines 392-492:   PET DATA (neonWolf, plasmaFalcon, shadowSpider, etc.)
 * Lines 493-731:   PET SKINS data (colors, rarity, effects)
 * Lines 732-772:   ALLY CHARACTERS (Shadow, Blaze, Volt, Ice)
 * Lines 773-934:   PLAYER SKINS ( Toxic, Blaze, Royal, Prism, etc.)
 * Lines 935-938:   DIFFICULTY SCALING arrays
 * Lines 939-967:   DAILY REWARDS config
 * Lines 968-1290:  SKILLS/SPELLS DATA (fireball, iceShard, shadowStep, etc.)
 * Lines ~1300-2550: CHAPTER/LEVEL DATA (platforms, waves, bosses)
 * Lines ~2550-3500: MORE GAME CONFIG (chapters, enemies, boss definitions)
 * Lines ~3500-3600: AUDIO SYSTEM (SoundManager, playTone, canPlaySfx)
 * Lines ~3600-5000: UI COMPONENTS (menu screens, shop, inventory)
 * Lines ~4860-4870: FULLSCREEN + SCREEN ORIENTATION lock
 * Lines ~4980-4990: ROTATE SCREEN overlay ("Best played in landscape")
 * Lines ~5000-5300: SHOP/STORE UI component
 * Lines ~5260-5300: Shop state management (useState hooks)
 * Lines ~6400-6800: ★ MAIN GAME ENGINE (canvas, requestAnimationFrame loop)
 * Lines ~6560-6590: Player init (health, invincible, jumpCount, vx, vy)
 * Lines ~6640-6670: AI/Enemy init (health, invincible, jumpCount)
 * Lines ~6690-6760: Enemy spawning + platform placement
 * Lines ~6750-6800: ★ PHYSICS UPDATE (collision, gravity, movement)
 * Lines ~6800-7000: ★ PLAYER CONTROLS (touch, keyboard, joystick)
 * Lines ~6970-6980: Window controls bridge (__neonWarriorControls)
 * Lines ~7100-7300: GAME LOOP (update + render cycle)
 * Lines ~7220:     requestAnimationFrame call
 * Lines ~9700-9710: Canvas game component mount
 * Lines ~9900-10100: ONLINE/MULTIPLAYER state
 * Lines ~13000-14200: VERSUS MODE game engine
 * Lines ~14300-14400: Asset loading (images, sprites)
 * Lines ~15400-15600: Background rendering (stars, particles, effects)
 * Lines ~16570:     Screen orientation lock attempt
 * 
 * ============================================================================
 * KEY VARIABLE NAMES (minified → meaning)
 * ============================================================================
 * 
 * eG          → isMobile flag (used for timer scaling: decrement by 2 on mobile)
 * n,i,s,c... → Color constants (see line 338-349)
 * r           → Current level/chapter config
 * p           → Player object
 * t           → AI/Enemy object (in versus mode)
 * e           → Generic entity (enemy in campaign loop)
 * a           → Alternate entity reference
 * .vx, .vy    → Velocity X, Velocity Y
 * .x, .y      → Position
 * .invincible → Invincibility frames counter
 * .jumpCount  → Jump counter (0=ground, 1=first jump, 2=double jump)
 * .health     → Current health
 * .maxHealth  → Maximum health
 * .shootCooldown → Cooldown timer before next shot
 * .onGround   → Whether entity is on a platform
 * 
 * ============================================================================
 * APPLIED PHYSICS PATCHES (from previous sessions)
 * ============================================================================
 * 
 * 1.  Knockback → velocity-based (was position displacement, caused wall clip)
 * 2.  Versus player invincibility after hit (p.invincible=20)
 * 3.  Versus AI invincibility after hit (t.invincible=20)
 * 4.  Versus double jump system (jumpCount tracking)
 * 5.  Platform collision tunneling fix (tolerance 2px→4px)
 * 6.  Air control reduction (5→3.5 campaign, 4.5→3 versus)
 * 7.  Mobile invincibility timer scaling (e.invincible-=(eG?2:1))
 * 8.  Ground safety clamp (prevent falling through floor)
 * 9.  AI jumpCount tracking fix
 * 10. Enemy bullet knockback (e.vx += direction * 3)
 * 11. Operator precedence fix (42+4 instances of &&variable-=value)
 * 12. Rotate screen disabled (condition made always false)
 * 
 * ============================================================================
 */

(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript :
  void 0, 16015, (e, t, o) => {},
  98547, (e, t, o) => {
    var a = e.i(47167);
    e.r(16015);
    var l = e.r(71645),
      r = l && "object" == typeof l && "default" in l ? l : {
        default: l
      },
      n = void 0 !== a.default && a.default.env && !0,
      i = function(e) {
        return "[object String]" === Object.prototype.toString.call(e)
      },
      s = function() {
        function e(e) {
          var t = void 0 === e ? {} : e,
            o = t.name,
            a = void 0 === o ? "stylesheet" : o,
            l = t.optimizeForSpeed,
            r = void 0 === l ? n : l;
          c(i(a), "`name` must be a string"), this._name = a, this._deletedRulePlaceholder = "#" + a +
            "-deleted-rule____{}", c("boolean" == typeof r, "`optimizeForSpeed` must be a boolean"), this
            ._optimizeForSpeed = r, this._serverSheet = void 0, this._tags = [], this._injected = !1, this
            ._rulesCount = 0;
          var s = "u" > typeof window && document.querySelector('meta[property="csp-nonce"]');
          this._nonce = s ? s.getAttribute("content") : null
        }
        var t, o = e.prototype;
        return o.setOptimizeForSpeed = function(e) {
            c("boolean" == typeof e, "`setOptimizeForSpeed` accepts a boolean"), c(0 === this._rulesCount,
                "optimizeForSpeed cannot be when rules have already been inserted"), this.flush(), this
              ._optimizeForSpeed = e, this.inject()
          }, o.isOptimizeForSpeed = function() {
            return this._optimizeForSpeed
          }, o.inject = function() {
            var e = this;
            if (c(!this._injected, "sheet already injected"), this._injected = !0, "u" > typeof window && this
              ._optimizeForSpeed) {
              this._tags[0] = this.makeStyleTag(this._name), this._optimizeForSpeed = "insertRule" in this
              .getSheet(), this._optimizeForSpeed || (n || console.warn(
                  "StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."), this.flush(),
                this._injected = !0);
              return
            }
            this._serverSheet = {
              cssRules: [],
              insertRule: function(t, o) {
                return "number" == typeof o ? e._serverSheet.cssRules[o] = {
                  cssText: t
                } : e._serverSheet.cssRules.push({
                  cssText: t
                }), o
              },
              deleteRule: function(t) {
                e._serverSheet.cssRules[t] = null
              }
            }
          }, o.getSheetForTag = function(e) {
            if (e.sheet) return e.sheet;
            for (var t = 0; t < document.styleSheets.length; t++)
              if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
          }, o.getSheet = function() {
            return this.getSheetForTag(this._tags[this._tags.length - 1])
          }, o.insertRule = function(e, t) {
            if (c(i(e), "`insertRule` accepts only strings"), "u" < typeof window) return "number" != typeof t && (
              t = this._serverSheet.cssRules.length), this._serverSheet.insertRule(e, t), this._rulesCount++;
            if (this._optimizeForSpeed) {
              var o = this.getSheet();
              "number" != typeof t && (t = o.cssRules.length);
              try {
                o.insertRule(e, t)
              } catch (t) {
                return n || console.warn("StyleSheet: illegal rule: \n\n" + e +
                  "\n\nSee https://stackoverflow.com/q/20007992 for more info"), -1
              }
            } else {
              var a = this._tags[t];
              this._tags.push(this.makeStyleTag(this._name, e, a))
            }
            return this._rulesCount++
          }, o.replaceRule = function(e, t) {
            if (this._optimizeForSpeed || "u" < typeof window) {
              var o = "u" > typeof window ? this.getSheet() : this._serverSheet;
              if (t.trim() || (t = this._deletedRulePlaceholder), !o.cssRules[e]) return e;
              o.deleteRule(e);
              try {
                o.insertRule(t, e)
              } catch (a) {
                n || console.warn("StyleSheet: illegal rule: \n\n" + t +
                  "\n\nSee https://stackoverflow.com/q/20007992 for more info"), o.insertRule(this
                  ._deletedRulePlaceholder, e)
              }
            } else {
              var a = this._tags[e];
              c(a, "old rule at index `" + e + "` not found"), a.textContent = t
            }
            return e
          }, o.deleteRule = function(e) {
            if ("u" < typeof window) return void this._serverSheet.deleteRule(e);
            if (this._optimizeForSpeed) this.replaceRule(e, "");
            else {
              var t = this._tags[e];
              c(t, "rule at index `" + e + "` not found"), t.parentNode.removeChild(t), this._tags[e] = null
            }
          }, o.flush = function() {
            this._injected = !1, this._rulesCount = 0, "u" > typeof window ? (this._tags.forEach(function(e) {
              return e && e.parentNode.removeChild(e)
            }), this._tags = []) : this._serverSheet.cssRules = []
          }, o.cssRules = function() {
            var e = this;
            return "u" < typeof window ? this._serverSheet.cssRules : this._tags.reduce(function(t, o) {
              return o ? t = t.concat(Array.prototype.map.call(e.getSheetForTag(o).cssRules, function(t) {
                return t.cssText === e._deletedRulePlaceholder ? null : t
              })) : t.push(null), t
            }, [])
          }, o.makeStyleTag = function(e, t, o) {
            t && c(i(t), "makeStyleTag accepts only strings as second parameter");
            var a = document.createElement("style");
            this._nonce && a.setAttribute("nonce", this._nonce), a.type = "text/css", a.setAttribute("data-" + e,
              ""), t && a.appendChild(document.createTextNode(t));
            var l = document.head || document.getElementsByTagName("head")[0];
            return o ? l.insertBefore(a, o) : l.appendChild(a), a
          }, t = [{
            key: "length",
            get: function() {
              return this._rulesCount
            }
          }],
          function(e, t) {
            for (var o = 0; o < t.length; o++) {
              var a = t[o];
              a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object
                .defineProperty(e, a.key, a)
            }
          }(e.prototype, t), e
      }();

    function c(e, t) {
      if (!e) throw Error("StyleSheet: " + t + ".")
    }
    var d = function(e) {
        for (var t = 5381, o = e.length; o;) t = 33 * t ^ e.charCodeAt(--o);
        return t >>> 0
      },
      h = {};

    function f(e, t) {
      if (!t) return "jsx-" + e;
      var o = String(t),
        a = e + o;
      return h[a] || (h[a] = "jsx-" + d(e + "-" + o)), h[a]
    }

    function u(e, t) {
      "u" < typeof window && (t = t.replace(/\/style/gi, "\\/style"));
      var o = e + t;
      return h[o] || (h[o] = t.replace(/__jsx-style-dynamic-selector/g, e)), h[o]
    }
    var m = function() {
        function e(e) {
          var t = void 0 === e ? {} : e,
            o = t.styleSheet,
            a = void 0 === o ? null : o,
            l = t.optimizeForSpeed,
            r = void 0 !== l && l;
          this._sheet = a || new s({
              name: "styled-jsx",
              optimizeForSpeed: r
            }), this._sheet.inject(), a && "boolean" == typeof r && (this._sheet.setOptimizeForSpeed(r), this
              ._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer = void 0, this._indices = {},
            this._instancesCounts = {}
        }
        var t = e.prototype;
        return t.add = function(e) {
          var t = this;
          void 0 === this._optimizeForSpeed && (this._optimizeForSpeed = Array.isArray(e.children), this._sheet
            .setOptimizeForSpeed(this._optimizeForSpeed), this._optimizeForSpeed = this._sheet
            .isOptimizeForSpeed()), "u" > typeof window && !this._fromServer && (this._fromServer = this
            .selectFromServer(), this._instancesCounts = Object.keys(this._fromServer).reduce(function(e, t) {
              return e[t] = 0, e
            }, {}));
          var o = this.getIdAndRules(e),
            a = o.styleId,
            l = o.rules;
          if (a in this._instancesCounts) {
            this._instancesCounts[a] += 1;
            return
          }
          var r = l.map(function(e) {
            return t._sheet.insertRule(e)
          }).filter(function(e) {
            return -1 !== e
          });
          this._indices[a] = r, this._instancesCounts[a] = 1
        }, t.remove = function(e) {
          var t = this,
            o = this.getIdAndRules(e).styleId;
          if (function(e, t) {
              if (!e) throw Error("StyleSheetRegistry: " + t + ".")
            }(o in this._instancesCounts, "styleId: `" + o + "` not found"), this._instancesCounts[o] -= 1, this
            ._instancesCounts[o] < 1) {
            var a = this._fromServer && this._fromServer[o];
            a ? (a.parentNode.removeChild(a), delete this._fromServer[o]) : (this._indices[o].forEach(function(
            e) {
              return t._sheet.deleteRule(e)
            }), delete this._indices[o]), delete this._instancesCounts[o]
          }
        }, t.update = function(e, t) {
          this.add(t), this.remove(e)
        }, t.flush = function() {
          this._sheet.flush(), this._sheet.inject(), this._fromServer = void 0, this._indices = {}, this
            ._instancesCounts = {}
        }, t.cssRules = function() {
          var e = this,
            t = this._fromServer ? Object.keys(this._fromServer).map(function(t) {
              return [t, e._fromServer[t]]
            }) : [],
            o = this._sheet.cssRules();
          return t.concat(Object.keys(this._indices).map(function(t) {
            return [t, e._indices[t].map(function(e) {
              return o[e].cssText
            }).join(e._optimizeForSpeed ? "" : "\n")]
          }).filter(function(e) {
            return !!e[1]
          }))
        }, t.styles = function(e) {
          var t, o;
          return t = this.cssRules(), void 0 === (o = e) && (o = {}), t.map(function(e) {
            var t = e[0],
              a = e[1];
            return r.default.createElement("style", {
              id: "__" + t,
              key: "__" + t,
              nonce: o.nonce ? o.nonce : void 0,
              dangerouslySetInnerHTML: {
                __html: a
              }
            })
          })
        }, t.getIdAndRules = function(e) {
          var t = e.children,
            o = e.dynamic,
            a = e.id;
          if (o) {
            var l = f(a, o);
            return {
              styleId: l,
              rules: Array.isArray(t) ? t.map(function(e) {
                return u(l, e)
              }) : [u(l, t)]
            }
          }
          return {
            styleId: f(a),
            rules: Array.isArray(t) ? t : [t]
          }
        }, t.selectFromServer = function() {
          return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e, t) {
            return e[t.id.slice(2)] = t, e
          }, {})
        }, e
      }(),
      x = l.createContext(null);

    function p() {
      return new m
    }

    function g() {
      return l.useContext(x)
    }
    x.displayName = "StyleSheetContext";
    var y = r.default.useInsertionEffect || r.default.useLayoutEffect,
      b = "u" > typeof window ? p() : void 0;

    function v(e) {
      var t = b || g();
      return t && ("u" < typeof window ? t.add(e) : y(function() {
        return t.add(e),
          function() {
            t.remove(e)
          }
      }, [e.id, String(e.dynamic)])), null
    }
    v.dynamic = function(e) {
      return e.map(function(e) {
        return f(e[0], e[1])
      }).join(" ")
    }, o.StyleRegistry = function(e) {
      var t = e.registry,
        o = e.children,
        a = l.useContext(x),
        n = l.useState(function() {
          return a || t || p()
        })[0];
      return r.default.createElement(x.Provider, {
        value: n
      }, o)
    }, o.createStyleRegistry = p, o.style = v, o.useStyleRegistry = g
  },
  37902, (e, t, o) => {
    t.exports = e.r(98547).style
  },
  52683, e => {
    "use strict";
    let t;
    var o = e.i(43476),
      a = e.i(71645);
    let l = e => {
        let t, o = new Set,
          a = (e, a) => {
            let l = "function" == typeof e ? e(t) : e;
            if (!Object.is(l, t)) {
              let e = t;
              t = (null != a ? a : "object" != typeof l || null === l) ? l : Object.assign({}, t, l), o.forEach(o =>
                o(t, e))
            }
          },
          l = () => t,
          r = {
            setState: a,
            getState: l,
            getInitialState: () => n,
            subscribe: e => (o.add(e), () => o.delete(e))
          },
          n = t = e(a, l, r);
        return r
      },
      r = e => {
        let t = e ? l(e) : l,
          o = e => (function(e, t = e => e) {
            let o = a.default.useSyncExternalStore(e.subscribe, a.default.useCallback(() => t(e.getState()), [e,
              t]), a.default.useCallback(() => t(e.getInitialState()), [e, t]));
            return a.default.useDebugValue(o), o
          })(t, e);
        return Object.assign(o, t), o
      },
      n = "#00ffff",
      i = "#ff00ff",
      s = "#00ff66",
      c = "#ff6600",
      d = "#ffff00",
      h = "#aa00ff",
      f = "#ff3333",
      u = "#050510",
      m = "#ffd700",
      x = "#ff69b4",
      p = "#4488ff",
      g = "#ffffff",
      y = {
        damage: {
          name: "Damage",
          baseCost: 500,
          costMultiplier: 1.5,
          effectPerLevel: .15,
          maxLevel: 999
        },
        fireRate: {
          name: "Fire Rate",
          baseCost: 800,
          costMultiplier: 1.6,
          effectPerLevel: .1,
          maxLevel: 999
        },
        bulletSpeed: {
          name: "Bullet Speed",
          baseCost: 600,
          costMultiplier: 1.4,
          effectPerLevel: .12,
          maxLevel: 999
        },
        bulletSize: {
          name: "Bullet Size",
          baseCost: 400,
          costMultiplier: 1.3,
          effectPerLevel: .1,
          maxLevel: 999
        },
        criticalChance: {
          name: "Critical Hit",
          baseCost: 1500,
          costMultiplier: 2,
          effectPerLevel: .02,
          maxLevel: 50
        }
      };

    function b(e, t) {
      let o = y[e];
      return Math.floor(o.baseCost * Math.pow(o.costMultiplier, t))
    }
    let v = [{
        id: "neonWolf",
        name: "NEON WOLF",
        color: n,
        glowColor: n,
        shootColor: n,
        damage: 6,
        shootRate: 45,
        description: "Loyal companion. Balanced fighter.",
        price: 0
      }, {
        id: "plasmaFalcon",
        name: "PLASMA FALCON",
        color: c,
        glowColor: d,
        shootColor: c,
        damage: 4,
        shootRate: 30,
        description: "Fast attacks. Quick and agile.",
        price: 2e3
      }, {
        id: "shadowSpider",
        name: "SHADOW SPIDER",
        color: h,
        glowColor: i,
        shootColor: h,
        damage: 8,
        shootRate: 60,
        description: "Slow but devastating hits.",
        price: 3500
      }, {
        id: "crystalGolem",
        name: "CRYSTAL GOLEM",
        color: s,
        glowColor: s,
        shootColor: s,
        damage: 5,
        shootRate: 50,
        description: "Tanky. Absorbs damage for you.",
        price: 5500
      }, {
        id: "voidDrake",
        name: "VOID DRAKE",
        color: i,
        glowColor: f,
        shootColor: i,
        damage: 10,
        shootRate: 55,
        description: "Legendary power. Devastating attacks.",
        price: 25e3
      }, {
        id: "neonCat",
        name: "NEON CAT",
        color: "#ff44aa",
        glowColor: "#ff88cc",
        shootColor: "#ff44aa",
        damage: 5,
        shootRate: 40,
        description: "Agile and quick. Lands critical hits.",
        price: 3e3
      }, {
        id: "thunderBird",
        name: "THUNDER BIRD",
        color: "#ffff00",
        glowColor: "#ffffff",
        shootColor: "#ffff00",
        damage: 7,
        shootRate: 50,
        description: "Strikes with lightning bolts.",
        price: 4500
      }, {
        id: "iceFox",
        name: "ICE FOX",
        color: "#88eeff",
        glowColor: "#ffffff",
        shootColor: "#88eeff",
        damage: 6,
        shootRate: 42,
        description: "Freezing attacks slow enemies.",
        price: 7500
      }, {
        id: "magmaSnail",
        name: "MAGMA SNAIL",
        color: "#ff4400",
        glowColor: "#ff8844",
        shootColor: "#ff4400",
        damage: 9,
        shootRate: 70,
        description: "Slow but devastating fireballs.",
        price: 15e3
      }, {
        id: "cosmicOwl",
        name: "COSMIC OWL",
        color: "#aa44ff",
        glowColor: "#dd88ff",
        shootColor: "#aa44ff",
        damage: 11,
        shootRate: 58,
        description: "Legendary wisdom. Devastating cosmic blasts.",
        price: 4e4
      }],
      w = [{
        id: "wolf-default",
        name: "CYAN",
        petId: "neonWolf",
        color: n,
        glowColor: n,
        trailColor: n,
        price: 0,
        rarity: "common"
      }, {
        id: "wolf-crimson",
        name: "CRIMSON",
        petId: "neonWolf",
        color: f,
        glowColor: c,
        trailColor: f,
        price: 2400,
        rarity: "rare"
      }, {
        id: "wolf-golden",
        name: "GOLDEN",
        petId: "neonWolf",
        color: m,
        glowColor: d,
        trailColor: m,
        price: 15e3,
        rarity: "legendary"
      }, {
        id: "falcon-default",
        name: "FLAME",
        petId: "plasmaFalcon",
        color: c,
        glowColor: d,
        trailColor: c,
        price: 0,
        rarity: "common"
      }, {
        id: "falcon-ice",
        name: "ICE",
        petId: "plasmaFalcon",
        color: "#88eeff",
        glowColor: g,
        trailColor: "#88eeff",
        price: 2400,
        rarity: "rare"
      }, {
        id: "spider-default",
        name: "VOID",
        petId: "shadowSpider",
        color: h,
        glowColor: i,
        trailColor: h,
        price: 0,
        rarity: "common"
      }, {
        id: "spider-toxic",
        name: "TOXIC",
        petId: "shadowSpider",
        color: s,
        glowColor: s,
        trailColor: s,
        price: 4e3,
        rarity: "rare"
      }, {
        id: "golem-default",
        name: "CRYSTAL",
        petId: "crystalGolem",
        color: s,
        glowColor: s,
        trailColor: s,
        price: 0,
        rarity: "common"
      }, {
        id: "golem-magma",
        name: "MAGMA",
        petId: "crystalGolem",
        color: f,
        glowColor: c,
        trailColor: c,
        price: 5500,
        rarity: "epic"
      }, {
        id: "drake-default",
        name: "ABYSS",
        petId: "voidDrake",
        color: i,
        glowColor: f,
        trailColor: i,
        price: 0,
        rarity: "common"
      }, {
        id: "drake-prism",
        name: "PRISM",
        petId: "voidDrake",
        color: g,
        glowColor: n,
        trailColor: i,
        price: 25e3,
        rarity: "legendary",
        effect: "rainbow"
      }, {
        id: "cat-default",
        name: "PINK",
        petId: "neonCat",
        color: "#ff44aa",
        glowColor: "#ff88cc",
        trailColor: "#ff44aa",
        price: 0,
        rarity: "common"
      }, {
        id: "cat-shadow",
        name: "SHADOW",
        petId: "neonCat",
        color: "#442244",
        glowColor: "#664466",
        trailColor: "#442244",
        price: 2400,
        rarity: "rare"
      }, {
        id: "cat-cosmic",
        name: "COSMIC",
        petId: "neonCat",
        color: "#aa44ff",
        glowColor: "#dd88ff",
        trailColor: "#aa44ff",
        price: 8e3,
        rarity: "epic"
      }, {
        id: "bird-default",
        name: "STORM",
        petId: "thunderBird",
        color: "#ffff00",
        glowColor: "#ffffff",
        trailColor: "#ffff00",
        price: 0,
        rarity: "common"
      }, {
        id: "bird-plasma",
        name: "PLASMA",
        petId: "thunderBird",
        color: c,
        glowColor: d,
        trailColor: c,
        price: 2400,
        rarity: "rare"
      }, {
        id: "bird-void",
        name: "VOID STORM",
        petId: "thunderBird",
        color: "#8800ff",
        glowColor: i,
        trailColor: "#8800ff",
        price: 9e3,
        rarity: "epic"
      }, {
        id: "fox-default",
        name: "FROST",
        petId: "iceFox",
        color: "#88eeff",
        glowColor: "#ffffff",
        trailColor: "#88eeff",
        price: 0,
        rarity: "common"
      }, {
        id: "fox-arctic",
        name: "ARCTIC",
        petId: "iceFox",
        color: "#ffffff",
        glowColor: "#ccffff",
        trailColor: "#ffffff",
        price: 4e3,
        rarity: "rare"
      }, {
        id: "fox-aurora",
        name: "AURORA",
        petId: "iceFox",
        color: "#44ff88",
        glowColor: "#88ffcc",
        trailColor: "#44ff88",
        price: 12e3,
        rarity: "legendary",
        effect: "rainbow"
      }, {
        id: "snail-default",
        name: "LAVA",
        petId: "magmaSnail",
        color: "#ff4400",
        glowColor: "#ff8844",
        trailColor: "#ff4400",
        price: 0,
        rarity: "common"
      }, {
        id: "snail-obsidian",
        name: "OBSIDIAN",
        petId: "magmaSnail",
        color: "#333344",
        glowColor: "#666688",
        trailColor: "#333344",
        price: 7e3,
        rarity: "rare"
      }, {
        id: "snail-infernal",
        name: "INFERNAL",
        petId: "magmaSnail",
        color: "#ff0000",
        glowColor: "#ffaa00",
        trailColor: "#ff0000",
        price: 2e4,
        rarity: "legendary",
        effect: "fire"
      }, {
        id: "owl-default",
        name: "NEBULA",
        petId: "cosmicOwl",
        color: "#aa44ff",
        glowColor: "#dd88ff",
        trailColor: "#aa44ff",
        price: 0,
        rarity: "common"
      }, {
        id: "owl-stellar",
        name: "STELLAR",
        petId: "cosmicOwl",
        color: "#ffdd44",
        glowColor: "#ffffff",
        trailColor: "#ffdd44",
        price: 12e3,
        rarity: "rare"
      }, {
        id: "owl-eternity",
        name: "ETERNITY",
        petId: "cosmicOwl",
        color: "#ffffff",
        glowColor: "#ff44ff",
        trailColor: "#ffffff",
        price: 35e3,
        rarity: "legendary",
        effect: "rainbow"
      }],
      k = [{
        id: "shadow",
        name: "SHADOW",
        color: "#8800ff",
        glowColor: "#aa44ff",
        ability: "Stealth Dash",
        joinChapter: 2,
        active: !1,
        health: 80,
        maxHealth: 80
      }, {
        id: "blaze",
        name: "BLAZE",
        color: "#ff4400",
        glowColor: "#ff8844",
        ability: "Fire Burst",
        joinChapter: 3,
        active: !1,
        health: 100,
        maxHealth: 100
      }, {
        id: "volt",
        name: "VOLT",
        color: "#ffff00",
        glowColor: "#ffff88",
        ability: "Lightning Strike",
        joinChapter: 4,
        active: !1,
        health: 70,
        maxHealth: 70
      }, {
        id: "ice",
        name: "ICE",
        color: "#44ddff",
        glowColor: "#88eeff",
        ability: "Freeze Blast",
        joinChapter: 5,
        active: !1,
        health: 90,
        maxHealth: 90
      }],
      C = [{
        id: "neon-green",
        name: "TOXIC",
        color: s,
        glowColor: s,
        trailColor: s,
        price: 0,
        rarity: "common"
      }, {
        id: "fire-red",
        name: "BLAZE",
        color: f,
        glowColor: c,
        trailColor: c,
        price: 5e3,
        rarity: "rare"
      }, {
        id: "royal-purple",
        name: "ROYAL",
        color: h,
        glowColor: i,
        trailColor: i,
        price: 5e3,
        rarity: "rare",
        unlockLevel: 6
      }, {
        id: "crimson",
        name: "CRIMSON",
        color: "#ff2222",
        glowColor: "#ff6644",
        trailColor: "#ff2222",
        price: 3e3,
        rarity: "rare"
      }, {
        id: "emerald",
        name: "EMERALD",
        color: "#00cc66",
        glowColor: "#44ff88",
        trailColor: "#00cc66",
        price: 3e3,
        rarity: "rare"
      }, {
        id: "sapphire",
        name: "SAPPHIRE",
        color: "#2266ff",
        glowColor: "#4488ff",
        trailColor: "#2266ff",
        price: 3e3,
        rarity: "rare"
      }, {
        id: "gold",
        name: "GOLDEN",
        color: m,
        glowColor: d,
        trailColor: d,
        price: 15e3,
        rarity: "epic"
      }, {
        id: "shadow",
        name: "PHANTOM",
        color: "#4444ff",
        glowColor: "#8888ff",
        trailColor: h,
        price: 15e3,
        rarity: "epic",
        unlockLevel: 10
      }, {
        id: "sunset",
        name: "SUNSET",
        color: "#ff8800",
        glowColor: "#ffaa44",
        trailColor: "#ff8800",
        price: 1e4,
        rarity: "epic"
      }, {
        id: "arctic",
        name: "ARCTIC",
        color: "#88ddff",
        glowColor: "#ffffff",
        trailColor: "#88ddff",
        price: 1e4,
        rarity: "epic"
      }, {
        id: "venom",
        name: "VENOM",
        color: "#88ff00",
        glowColor: "#aaff44",
        trailColor: "#88ff00",
        price: 1e4,
        rarity: "epic"
      }, {
        id: "neon-pink",
        name: "NEON PINK",
        color: "#ff44aa",
        glowColor: "#ff88cc",
        trailColor: "#ff44aa",
        price: 18e3,
        rarity: "epic"
      }, {
        id: "rainbow",
        name: "PRISM",
        color: g,
        glowColor: i,
        trailColor: n,
        price: 3e4,
        rarity: "legendary",
        effect: "rainbow"
      }, {
        id: "diamond",
        name: "DIAMOND",
        color: "#88ffff",
        glowColor: g,
        trailColor: n,
        price: 4e4,
        rarity: "legendary",
        effect: "sparkle"
      }, {
        id: "obsidian",
        name: "OBSIDIAN",
        color: "#333344",
        glowColor: "#666688",
        trailColor: "#333344",
        price: 3e4,
        rarity: "legendary",
        effect: "shadow"
      }, {
        id: "plasma",
        name: "PLASMA",
        color: "#ff44ff",
        glowColor: "#ff88ff",
        trailColor: "#ff44ff",
        price: 3e4,
        rarity: "legendary",
        effect: "plasma"
      }, {
        id: "celestial",
        name: "CELESTIAL",
        color: "#ffdd44",
        glowColor: "#ffffff",
        trailColor: "#ffdd44",
        price: 4e4,
        rarity: "legendary",
        effect: "holy"
      }, {
        id: "abyssal",
        name: "ABYSSAL",
        color: "#220044",
        glowColor: "#440088",
        trailColor: "#220044",
        price: 5e4,
        rarity: "legendary",
        effect: "abyss"
      }, {
        id: "cyber",
        name: "CYBER",
        color: "#00ffaa",
        glowColor: "#44ffcc",
        trailColor: "#00ffaa",
        price: 5e4,
        rarity: "legendary",
        effect: "glitch"
      }],
      S = [1, 1.2, 1.5, 1.8, 2.2],
      T = [1, .9, .8, .7, .6],
      M = [0, 1500, 3e3, 5400, 10500],
      j = [!1, !1, !0, !0, !0],
      N = [{
        day: 1,
        coins: 50,
        type: "coins"
      }, {
        day: 2,
        coins: 100,
        type: "coins"
      }, {
        day: 3,
        coins: 150,
        type: "coins"
      }, {
        day: 4,
        coins: 200,
        type: "coins"
      }, {
        day: 5,
        coins: 300,
        type: "coins"
      }, {
        day: 6,
        coins: 500,
        type: "coins"
      }, {
        day: 7,
        coins: 1e3,
        type: "coins"
      }],
      P = [{
        id: "fireball",
        name: "FIREBALL",
        element: "fire",
        description: "Launch a devastating fireball that explodes on impact, dealing area damage to all nearby enemies.",
        damage: 25,
        cooldown: 180,
        duration: 30,
        color: "#ff4400",
        glowColor: "#ff8844",
        rarity: "common",
        unlockMethod: "level",
        unlockCost: 0,
        unlockLevel: 2,
        effectType: "projectile",
        projectileCount: 1
      }, {
        id: "fireStorm",
        name: "FIRE STORM",
        element: "fire",
        description: "Rain fire from above! Multiple fireballs cascade across the battlefield, creating a devastating inferno.",
        damage: 40,
        cooldown: 360,
        duration: 60,
        color: "#ff2200",
        glowColor: "#ff6600",
        rarity: "rare",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossRedKing",
        effectType: "aoe",
        effectRadius: 200
      }, {
        id: "inferno",
        name: "INFERNO",
        element: "fire",
        description: "Unleash the ultimate fire technique. A massive pillar of flame erupts from the ground, incinerating everything.",
        damage: 60,
        cooldown: 480,
        duration: 90,
        color: "#ff0000",
        glowColor: "#ffaa00",
        rarity: "legendary",
        unlockMethod: "ad",
        unlockCost: 4e3,
        effectType: "beam",
        effectRadius: 150
      }, {
        id: "iceShard",
        name: "ICE SHARD",
        element: "frost",
        description: "Fire razor-sharp ice shards that pierce through enemies and slow their movement.",
        damage: 20,
        cooldown: 150,
        duration: 60,
        color: "#88eeff",
        glowColor: "#ffffff",
        rarity: "common",
        unlockMethod: "level",
        unlockCost: 0,
        unlockLevel: 5,
        effectType: "projectile",
        projectileCount: 3
      }, {
        id: "blizzard",
        name: "BLIZZARD",
        element: "frost",
        description: "Summon a raging blizzard that freezes all enemies in a wide area.",
        damage: 35,
        cooldown: 300,
        duration: 90,
        color: "#44ddff",
        glowColor: "#ffffff",
        rarity: "rare",
        unlockMethod: "chest",
        unlockCost: 1800,
        effectType: "aoe",
        effectRadius: 250
      }, {
        id: "absoluteZero",
        name: "ABSOLUTE ZERO",
        element: "frost",
        description: "Flash-freeze the entire battlefield, stopping ALL enemies in their tracks.",
        damage: 50,
        cooldown: 600,
        duration: 120,
        color: "#ffffff",
        glowColor: "#88eeff",
        rarity: "legendary",
        unlockMethod: "ad",
        unlockCost: 5e3,
        effectType: "aoe",
        effectRadius: 500
      }, {
        id: "shadowStep",
        name: "SHADOW STEP",
        element: "shadow",
        description: "Teleport behind the nearest enemy and strike from the shadows. Grants brief invincibility.",
        damage: 30,
        cooldown: 200,
        duration: 20,
        color: "#8800ff",
        glowColor: "#aa44ff",
        rarity: "common",
        unlockMethod: "level",
        unlockCost: 0,
        unlockLevel: 8,
        effectType: "buff"
      }, {
        id: "shadowClone",
        name: "SHADOW CLONE",
        element: "shadow",
        description: "Create shadow clones that fight alongside you and draw enemy fire.",
        damage: 15,
        cooldown: 360,
        duration: 180,
        color: "#6600cc",
        glowColor: "#9933ff",
        rarity: "epic",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossCorrupted",
        effectType: "summon",
        summonCount: 2
      }, {
        id: "voidWalk",
        name: "VOID WALK",
        element: "shadow",
        description: "Enter the void dimension, becoming invisible and invincible. Next attack deals 3x damage.",
        damage: 45,
        cooldown: 480,
        duration: 60,
        color: "#4400aa",
        glowColor: "#8800ff",
        rarity: "legendary",
        unlockMethod: "ad",
        unlockCost: 4e3,
        effectType: "buff"
      }, {
        id: "summonWraith",
        name: "SUMMON WRAITH",
        element: "summon",
        description: "Summon a spectral wraith that hunts down enemies and drains their life force.",
        damage: 12,
        cooldown: 240,
        duration: 200,
        color: "#aa00ff",
        glowColor: "#ff00ff",
        rarity: "common",
        unlockMethod: "purchase",
        unlockCost: 1200,
        effectType: "summon",
        summonCount: 1
      }, {
        id: "summonLegion",
        name: "SUMMON LEGION",
        element: "summon",
        description: "Raise an army of shadow soldiers that charge forward, overwhelming enemies with numbers.",
        damage: 20,
        cooldown: 420,
        duration: 180,
        color: "#8800cc",
        glowColor: "#cc44ff",
        rarity: "epic",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossMechGolem",
        effectType: "summon",
        summonCount: 5
      }, {
        id: "summonDeathKnight",
        name: "DEATH KNIGHT",
        element: "summon",
        description: "Summon the legendary Death Knight, an unstoppable warrior that cleaves through enemies.",
        damage: 35,
        cooldown: 600,
        duration: 240,
        color: "#440066",
        glowColor: "#8800aa",
        rarity: "legendary",
        unlockMethod: "ad",
        unlockCost: 6e3,
        effectType: "summon",
        summonCount: 1
      }, {
        id: "deathTouch",
        name: "DEATH TOUCH",
        element: "death",
        description: "Channel the power of death. A close-range touch that instantly kills weaker enemies.",
        damage: 50,
        cooldown: 300,
        duration: 15,
        color: "#330033",
        glowColor: "#660066",
        rarity: "rare",
        unlockMethod: "chest",
        unlockCost: 2400,
        effectType: "beam"
      }, {
        id: "soulHarvest",
        name: "SOUL HARVEST",
        element: "death",
        description: "Reap the souls of nearby enemies, dealing damage and healing yourself for each hit.",
        damage: 30,
        cooldown: 360,
        duration: 45,
        color: "#220022",
        glowColor: "#550055",
        rarity: "epic",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossFather",
        effectType: "aoe",
        effectRadius: 200
      }, {
        id: "annihilation",
        name: "ANNIHILATION",
        element: "death",
        description: "Obliterate everything in a massive radius. Non-boss enemies are instantly killed.",
        damage: 999,
        cooldown: 900,
        duration: 30,
        color: "#110011",
        glowColor: "#330033",
        rarity: "legendary",
        unlockMethod: "ad",
        unlockCost: 1e4,
        effectType: "aoe",
        effectRadius: 400
      }, {
        id: "lightningBolt",
        name: "LIGHTNING BOLT",
        element: "lightning",
        description: "Strike enemies with a bolt of lightning that chains between nearby targets.",
        damage: 22,
        cooldown: 160,
        duration: 20,
        color: "#ffff00",
        glowColor: "#ffffff",
        rarity: "common",
        unlockMethod: "level",
        unlockCost: 0,
        unlockLevel: 12,
        effectType: "projectile",
        projectileCount: 1
      }, {
        id: "thunderStorm",
        name: "THUNDER STORM",
        element: "lightning",
        description: "Call down a devastating thunder storm that repeatedly strikes the battlefield.",
        damage: 38,
        cooldown: 350,
        duration: 90,
        color: "#ffff44",
        glowColor: "#ffffff",
        rarity: "epic",
        unlockMethod: "purchase",
        unlockCost: 3600,
        effectType: "aoe",
        effectRadius: 300
      }, {
        id: "voidBlast",
        name: "VOID BLAST",
        element: "void",
        description: "Fire a concentrated blast of void energy that tears through enemies and distorts reality.",
        damage: 28,
        cooldown: 200,
        duration: 40,
        color: "#ff00ff",
        glowColor: "#ff44ff",
        rarity: "rare",
        unlockMethod: "level",
        unlockCost: 0,
        unlockLevel: 20,
        effectType: "projectile",
        projectileCount: 1
      }, {
        id: "voidRift",
        name: "VOID RIFT",
        element: "void",
        description: "Tear open a rift in reality that continuously damages and slows all enemies within.",
        damage: 20,
        cooldown: 400,
        duration: 150,
        color: "#cc00cc",
        glowColor: "#ff44ff",
        rarity: "epic",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossDragon",
        effectType: "aoe",
        effectRadius: 180
      }, {
        id: "bloodStrike",
        name: "BLOOD STRIKE",
        element: "blood",
        description: "Sacrifice health to deal massive damage. The lower your health, the more damage this deals.",
        damage: 35,
        cooldown: 180,
        duration: 15,
        color: "#cc0000",
        glowColor: "#ff3333",
        rarity: "rare",
        unlockMethod: "purchase",
        unlockCost: 1500,
        effectType: "projectile",
        projectileCount: 1
      }, {
        id: "bloodFury",
        name: "BLOOD FURY",
        element: "blood",
        description: "Enter a blood rage that massively increases attack speed and damage, but drains health.",
        damage: 0,
        cooldown: 420,
        duration: 180,
        color: "#990000",
        glowColor: "#ff0000",
        rarity: "epic",
        unlockMethod: "boss",
        unlockCost: 0,
        unlockBoss: "bossPhoenix",
        effectType: "buff"
      }];

    function A(e) {
      return e <= 10 ? "neonCity" : e <= 20 ? "scorchedWasteland" : e <= 30 ? "frozenTundra" : e <= 40 ?
        "shadowRealm" : e <= 50 ? "volcanicCore" : e <= 60 ? "crystalCaves" : e <= 70 ? "voidDimension" : e <= 80 ?
        "cyberForest" : e <= 90 ? "stormPlains" : e <= 100 ? "bloodMoon" : ["neonCity", "scorchedWasteland",
          "frozenTundra", "shadowRealm", "volcanicCore", "crystalCaves", "voidDimension", "cyberForest",
          "stormPlains", "bloodMoon"
        ][(e - 101) % 10]
    }

    function R(e) {
      switch (e) {
        case "neonCity":
          return {
            skyColor: "#020210", skyGradient: ["#020210", "#040418", "#020212"], groundColor: "#000a0a",
              platformColor: "#000a0a", platformGlow: n, particleColor: n, weatherType: "rain", ambientDescription:
              "The neon city pulses with digital energy"
          };
        case "scorchedWasteland":
          return {
            skyColor: "#080300", skyGradient: ["#080300", "#0c0500", "#060200"], groundColor: "#0a0500",
              platformColor: "#0a0500", platformGlow: c, particleColor: c, weatherType: "embers",
              ambientDescription: "The wasteland burns under a dying sun"
          };
        case "frozenTundra":
          return {
            skyColor: "#010408", skyGradient: ["#010408", "#030810", "#02060a"], groundColor: "#000810",
              platformColor: "#000810", platformGlow: "#88eeff", particleColor: "#88eeff", weatherType: "snow",
              ambientDescription: "Ice covers everything in this frozen digital tundra"
          };
        case "shadowRealm":
          return {
            skyColor: "#050008", skyGradient: ["#050008", "#080012", "#040006"], groundColor: "#050008",
              platformColor: "#080010", platformGlow: h, particleColor: h, weatherType: "glitch",
              ambientDescription: "Shadows twist and writhe in this corrupted realm"
          };
        case "volcanicCore":
          return {
            skyColor: "#080000", skyGradient: ["#080000", "#0c0200", "#060000"], groundColor: "#0a0200",
              platformColor: "#0a0200", platformGlow: f, particleColor: f, weatherType: "embers",
              ambientDescription: "Molten data flows through the volcanic core"
          };
        case "crystalCaves":
          return {
            skyColor: "#000a08", skyGradient: ["#000a08", "#000c0a", "#000605"], groundColor: "#000a08",
              platformColor: "#000a08", platformGlow: s, particleColor: s, weatherType: "none", ambientDescription:
              "Crystals hum with ancient power"
          };
        case "voidDimension":
          return {
            skyColor: "#060006", skyGradient: ["#060006", "#0a000a", "#030003"], groundColor: "#050008",
              platformColor: "#050008", platformGlow: i, particleColor: i, weatherType: "voidParticles",
              ambientDescription: "Reality fractures in the void dimension"
          };
        case "cyberForest":
          return {
            skyColor: "#000805", skyGradient: ["#000805", "#000c08", "#000403"], groundColor: "#000c08",
              platformColor: "#000c08", platformGlow: "#00ff66", particleColor: "#00ff66", weatherType: "rain",
              ambientDescription: "Digital trees pulse with living code"
          };
        case "stormPlains":
          return {
            skyColor: "#080800", skyGradient: ["#080800", "#0a0a04", "#060600"], groundColor: "#080800",
              platformColor: "#080800", platformGlow: d, particleColor: d, weatherType: "glitch",
              ambientDescription: "Lightning tears across the storm plains"
          };
        case "bloodMoon":
          return {
            skyColor: "#080002", skyGradient: ["#080002", "#0c0004", "#060001"], groundColor: "#080002",
              platformColor: "#080002", platformGlow: "#cc0033", particleColor: "#cc0033", weatherType: "embers",
              ambientDescription: "The blood moon watches. Everything ends here."
          }
      }
    }
    let I = ["voidBat", "stormEagle", "emberWisp", "frostWraith", "shadowDrake", "plasmaSerpent", "neonWyrm",
      "crystalMoth", "dragon", "phoenix"
    ];

    function E(e) {
      return I.includes(e)
    }
    let L = {
        id: -1,
        name: "VERSUS ARENA",
        chapter: "VS",
        width: 1200,
        height: 600,
        playerSpawn: {
          x: 100,
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 1200,
          height: 40,
          type: "static"
        }, {
          x: 80,
          y: 380,
          width: 150,
          height: 16,
          type: "static"
        }, {
          x: 320,
          y: 320,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 500,
          y: 260,
          width: 120,
          height: 16,
          type: "moving",
          moveRange: 80,
          moveSpeed: 1,
          moveAxis: "x",
          moveOffset: 0
        }, {
          x: 700,
          y: 320,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 920,
          y: 380,
          width: 150,
          height: 16,
          type: "static"
        }, {
          x: 200,
          y: 220,
          width: 80,
          height: 16,
          type: "static"
        }, {
          x: 880,
          y: 220,
          width: 80,
          height: 16,
          type: "static"
        }, {
          x: 520,
          y: 160,
          width: 100,
          height: 16,
          type: "static"
        }],
        waves: [],
        background: "core",
        introText: "FIGHT!",
        introColor: m,
        missionType: "fight",
        gangMembersAvailable: []
      },
      D = {
        elo: 1e3,
        wins: 0,
        losses: 0
      },
      W = [{
        rank: "Bronze",
        min: 0,
        icon: "🥉"
      }, {
        rank: "Silver",
        min: 1e3,
        icon: "🥈"
      }, {
        rank: "Gold",
        min: 1200,
        icon: "🥇"
      }, {
        rank: "Platinum",
        min: 1400,
        icon: "💎"
      }, {
        rank: "Diamond",
        min: 1600,
        icon: "💠"
      }, {
        rank: "Master",
        min: 2e3,
        icon: "👑"
      }];

    function O(e) {
      let t = W[0];
      for (let o of W) e >= o.min && (t = o);
      return {
        rank: t.rank,
        icon: t.icon
      }
    }
    let B = {
        currentChapter: 1,
        highestLevel: 1,
        totalCoins: 0,
        totalScore: 0,
        unlockedSkins: ["neon-green"],
        currentSkin: "neon-green",
        currentPet: "crystalGolem",
        unlockedPets: ["neonWolf", "crystalGolem"],
        currentPetSkin: "wolf-default",
        unlockedPetSkins: ["wolf-default"],
        gangMembersUnlocked: [],
        missionsCompleted: [],
        endlessHighScore: 0,
        endlessHighestWave: 0,
        totalKills: 0,
        totalDeaths: 0,
        lastSaveTime: 0,
        rankingData: {
          ...D
        },
        username: "NeonWarrior",
        avatar: "⚔️",
        about: "",
        nationality: "",
        unlockedSkills: [],
        equippedSkills: ["", "", ""],
        skillUpgrades: {},
        lastDailyRewardDay: "",
        dailyRewardStreak: 0,
        levelStars: {},
        weaponUpgrades: {},
        hasSeenTapToStart: !1,
        skinUpgrades: {}
      },
      G = [{
        id: 1,
        name: "FIRST STEPS",
        chapter: "CH.1",
        width: 2e3,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 2e3,
          height: 40,
          type: "static"
        }, {
          x: 400,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 800,
          y: 360,
          width: 120,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 600,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Who took her... I'll find out."
        }],
        background: "city",
        introText: "They took LUNA. Blue wakes up alone in the neon city. Your journey begins.",
        introColor: n,
        missionType: "fight",
        gangMembersAvailable: []
      }, {
        id: 2,
        name: "LEARNING TO FIGHT",
        chapter: "CH.1",
        width: 2200,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 2200,
          height: 40,
          type: "static"
        }, {
          x: 500,
          y: 380,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 1e3,
          y: 350,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 1500,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "drone"
          }, {
            x: 700,
            y: 480,
            type: "drone"
          }],
          voiceLine: "More of them. I can handle this."
        }, {
          enemies: [{
            x: 1200,
            y: 480,
            type: "drone"
          }, {
            x: 1400,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Luna... I'm coming."
        }],
        background: "city",
        introText: "The streets are crawling with Red King's drones. Fight through.",
        introColor: c,
        missionType: "fight",
        gangMembersAvailable: []
      }, {
        id: 3,
        name: "MEET SHADOW",
        chapter: "CH.2",
        width: 2400,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 2400,
          height: 40,
          type: "static"
        }, {
          x: 400,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 900,
          y: 360,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 1400,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 1900,
          y: 350,
          width: 120,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "drone"
          }, {
            x: 700,
            y: 480,
            type: "drone"
          }, {
            x: 900,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Someone's fighting ahead..."
        }, {
          enemies: [{
            x: 1300,
            y: 480,
            type: "drone"
          }, {
            x: 1500,
            y: 480,
            type: "glitchWalker"
          }],
          voiceLine: "That fighter... he's good."
        }],
        background: "warehouse",
        introText: "A lone fighter stands against Red King's army. His name is SHADOW.",
        introColor: h,
        missionType: "fight",
        gangMembersAvailable: []
      }, {
        id: 4,
        name: "THE WAREHOUSE",
        chapter: "CH.2",
        width: 2600,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 3e3,
          height: 40,
          type: "static"
        }, {
          x: 350,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 650,
          y: 320,
          width: 110,
          height: 16,
          type: "static"
        }, {
          x: 1e3,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 1400,
          y: 350,
          width: 100,
          height: 16,
          type: "moving",
          moveRange: 100,
          moveSpeed: 1.5,
          moveAxis: "x",
          moveOffset: 0
        }, {
          x: 1800,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 2200,
          y: 340,
          width: 110,
          height: 16,
          type: "static"
        }, {
          x: 2600,
          y: 390,
          width: 120,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "drone"
          }, {
            x: 650,
            y: 480,
            type: "glitchWalker"
          }],
          voiceLine: "Shadow, cover the left!"
        }, {
          enemies: [{
            x: 900,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1050,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 1200,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Turret up ahead!"
        }, {
          enemies: [{
            x: 1600,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1750,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1900,
            y: 480,
            type: "drone"
          }, {
            x: 2e3,
            y: 480,
            type: "drone"
          }],
          voiceLine: "The Blue Gang doesn't quit."
        }, {
          enemies: [{
            x: 2400,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 2500,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2600,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2750,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Warehouse is ours."
        }],
        background: "warehouse",
        introText: "Blue and Shadow raid Red King's weapons warehouse.",
        introColor: h,
        missionType: "fight",
        gangMembersAvailable: []
      }, {
        id: 5,
        name: "RESCUE MISSION",
        chapter: "CH.3",
        width: 2800,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 2800,
          height: 40,
          type: "static"
        }, {
          x: 400,
          y: 380,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 700,
          y: 310,
          width: 110,
          height: 16,
          type: "static"
        }, {
          x: 1050,
          y: 390,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 1500,
          y: 350,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 1800,
          y: 300,
          width: 120,
          height: 16,
          type: "moving",
          moveRange: 120,
          moveSpeed: 1.5,
          moveAxis: "x",
          moveOffset: 0
        }, {
          x: 2200,
          y: 380,
          width: 100,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 650,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 800,
            y: 480,
            type: "voidGuardian"
          }],
          voiceLine: "Luna is close. I can feel it."
        }, {
          enemies: [{
            x: 1100,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 1250,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1400,
            y: 480,
            type: "drone"
          }, {
            x: 1500,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Nothing stops me now."
        }, {
          enemies: [{
            x: 1900,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2e3,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2100,
            y: 480,
            type: "voidGuardian"
          }],
          voiceLine: "Shadow, BLAZE — cover me!"
        }],
        background: "firewall",
        introText: "Luna is held in the Red King's fortress. The Blue Gang breaches the walls.",
        introColor: f,
        missionType: "rescue",
        gangMembersAvailable: []
      }, {
        id: 6,
        name: "RED KING'S THRONE",
        chapter: "CH.3",
        width: 2e3,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 800,
          height: 40,
          type: "static"
        }, {
          x: 900,
          y: 520,
          width: 1100,
          height: 40,
          type: "static"
        }, {
          x: 350,
          y: 380,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 600,
          y: 310,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 1200,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 1600,
          y: 330,
          width: 110,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 650,
            y: 480,
            type: "drone"
          }],
          voiceLine: "The throne room. This is it."
        }],
        bossWave: {
          enemies: [{
            x: 1500,
            y: 480,
            type: "bossRedKing",
            bossName: "RED KING",
            bossColor: f
          }],
          voiceLine: "RED KING. Let her go. NOW."
        },
        background: "core",
        introText: "The Red King himself. Luna is behind him. This ends now.",
        introColor: i,
        missionType: "boss",
        gangMembersAvailable: []
      }, {
        id: 7,
        name: "PROTECT NEON",
        chapter: "CH.4",
        width: 2500,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 2500,
          height: 40,
          type: "static"
        }, {
          x: 300,
          y: 400,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 600,
          y: 340,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 900,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 1200,
          y: 350,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 1600,
          y: 400,
          width: 120,
          height: 16,
          type: "moving",
          moveRange: 80,
          moveSpeed: 1.5,
          moveAxis: "x",
          moveOffset: 0
        }, {
          x: 2e3,
          y: 340,
          width: 110,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 400,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 550,
            y: 480,
            type: "drone"
          }, {
            x: 700,
            y: 480,
            type: "drone"
          }],
          voiceLine: "They're coming for Mom. NOT happening."
        }, {
          enemies: [{
            x: 1e3,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 1150,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1300,
            y: 480,
            type: "drone"
          }, {
            x: 1400,
            y: 480,
            type: "glitchWalker"
          }],
          voiceLine: "Gang, protect the left flank!"
        }, {
          enemies: [{
            x: 1800,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1900,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2e3,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 2100,
            y: 480,
            type: "drone"
          }, {
            x: 2200,
            y: 480,
            type: "drone"
          }],
          voiceLine: "She's safe. The Gang protects its own."
        }],
        background: "city",
        introText: "Red King's army attacks Blue's mother NEON. Protect her at all costs.",
        introColor: x,
        missionType: "protect",
        gangMembersAvailable: []
      }, {
        id: 8,
        name: "THE FINAL WAR",
        chapter: "CH.5",
        width: 3500,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: [{
          x: 0,
          y: 520,
          width: 3500,
          height: 40,
          type: "static"
        }, {
          x: 300,
          y: 380,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 600,
          y: 310,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 900,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 1300,
          y: 340,
          width: 110,
          height: 16,
          type: "moving",
          moveRange: 100,
          moveSpeed: 2,
          moveAxis: "x",
          moveOffset: 0
        }, {
          x: 1700,
          y: 370,
          width: 120,
          height: 16,
          type: "static"
        }, {
          x: 2100,
          y: 330,
          width: 100,
          height: 16,
          type: "static"
        }, {
          x: 2400,
          y: 380,
          width: 130,
          height: 16,
          type: "static"
        }, {
          x: 2800,
          y: 340,
          width: 110,
          height: 16,
          type: "static"
        }],
        waves: [{
          enemies: [{
            x: 500,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 600,
            y: 480,
            type: "drone"
          }, {
            x: 700,
            y: 480,
            type: "drone"
          }, {
            x: 800,
            y: 480,
            type: "voidGuardian"
          }],
          voiceLine: "The final war. EVERYONE fights!"
        }, {
          enemies: [{
            x: 1200,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 1350,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1500,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 1600,
            y: 480,
            type: "drone"
          }, {
            x: 1700,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Blue Gang, UNLEASH!"
        }, {
          enemies: [{
            x: 2200,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2300,
            y: 480,
            type: "voidGuardian"
          }, {
            x: 2400,
            y: 480,
            type: "glitchWalker"
          }, {
            x: 2500,
            y: 480,
            type: "drone"
          }],
          voiceLine: "Push them back!"
        }],
        bossWave: {
          enemies: [{
            x: 3e3,
            y: 480,
            type: "bossTitan",
            bossName: "THE TITAN",
            bossColor: "#ff0000"
          }],
          voiceLine: "This is for EVERYONE you hurt. OVERLOAD!"
        },
        background: "core",
        introText: "THE FINAL WAR. The Blue Gang vs Red King's entire army. No retreat.",
        introColor: m,
        missionType: "boss",
        gangMembersAvailable: []
      }],
      $ = {
        6: "THE INFINITE GRID",
        7: "DRAGON'S DOMAIN",
        8: "MECH WARFARE",
        9: "SHADOW REALM",
        10: "PHOENIX RISING",
        11: "THE VOID AWAKENS",
        12: "CORRUPTED KINGDOM",
        13: "NEON APOCALYPSE",
        14: "THE FINAL FRONTIER",
        15: "ETERNAL WAR"
      },
      F = {
        1: "ch1-intro",
        10: "ch2-intro",
        20: "ch3-intro",
        30: "lv20-luna",
        40: "lv40-mother",
        50: "lv50-void",
        60: "ch4-intro",
        70: "lv70-betrayal",
        80: "lv80-truth",
        90: "lv90-final",
        100: "lv100-turning",
        110: "ch5-intro",
        120: "ch1-intro",
        130: "ch2-intro",
        140: "ch3-intro",
        150: "ch4-intro",
        160: "ch5-intro",
        170: "ch1-intro",
        180: "ch2-intro",
        190: "ch3-intro",
        200: "ch4-intro",
        210: "ch5-intro",
        220: "ch1-intro",
        230: "ch2-intro",
        240: "ch3-intro",
        250: "lv250-father"
      },
      H = {
        5: {
          type: "ambush",
          text: "BEHIND YOU!",
          color: f,
          spawnEnemies: ["glitchWalker", "drone"],
          enemyCount: 4,
          duration: 120
        },
        15: {
          type: "thugsAppear",
          text: "THUGS BLOCKING THE PATH!",
          color: c,
          spawnEnemies: ["glitchWalker"],
          enemyCount: 5,
          duration: 120
        },
        25: {
          type: "allyArrives",
          text: 'SHADOW: "Need a hand?"',
          color: h,
          spawnEnemies: [],
          duration: 150
        },
        35: {
          type: "trapTriggered",
          text: "THE FLOOR IS COLLAPSING!",
          color: f,
          spawnEnemies: [],
          duration: 90
        },
        45: {
          type: "voidRift",
          text: "A VOID RIFT! SOMETHING IS COMING THROUGH!",
          color: i,
          spawnEnemies: ["voidGuardian"],
          enemyCount: 3,
          duration: 120
        },
        55: {
          type: "betrayal",
          text: "WAIT... WHOSE SIDE ARE YOU ON?!",
          color: c,
          spawnEnemies: ["eliteDrone"],
          enemyCount: 3,
          duration: 150
        },
        65: {
          type: "rescue",
          text: "SOMEONE IS TRAPPED AHEAD! SAVE THEM!",
          color: x,
          spawnEnemies: [],
          duration: 150
        },
        75: {
          type: "bossSurprise",
          text: "A HIDDEN BOSS AWAKENS!",
          color: f,
          spawnEnemies: ["bossCorrupted"],
          enemyCount: 1,
          duration: 180
        },
        85: {
          type: "flashback",
          text: "Blue sees his father's memory...",
          color: n,
          spawnEnemies: [],
          duration: 120
        },
        95: {
          type: "earthquake",
          text: "THE GRID IS SHAKING! PLATFORMS SHIFTING!",
          color: m,
          spawnEnemies: [],
          duration: 90
        }
      };

    function U(e) {
      let t, o, a, l, r = V(e),
        d = Math.min(Math.floor((e - 1) / 100) + 6, 200),
        u = $[d] ? $[d] : `ZONE ${d}`;
      t = e <= 3 ? 2700 + 150 * e : e <= 10 ? 3e3 + 75 * e : e <= 50 ? 3750 + (e - 10) * 75 : e <= 200 ? 6750 + (e -
        50) * 45 : Math.min(13500 + (e - 200) * 30, 3e4);
      let x = [],
        g = [],
        y = 0,
        b = e > 50 && r() > .6;
      for (; y < t;) {
        let e = 200 + Math.floor(400 * r());
        g.push({
          x: y,
          y: 520,
          width: e,
          height: 40,
          type: "static"
        }), y += e, b && r() > .6 && y > 300 && y < t - 300 && (y += 80 + Math.floor(60 * r()))
      }
      x.push(...g), o = e <= 10 ? 2 : e <= 30 ? 2 + Math.floor(2 * r()) : e <= 50 ? 3 + Math.floor(2 * r()) : e <=
        200 ? 4 + Math.floor(2 * r()) : 5 + Math.floor(Math.min(e / 100, 8));
      for (let e = 0; e < o; e++) {
        let e = 200 + Math.floor(r() * (t - 400)),
          o = 280 + Math.floor(180 * r()),
          a = 80 + Math.floor(80 * r()),
          l = r() > .7;
        x.push({
          x: e,
          y: o,
          width: a,
          height: 16,
          type: l ? "moving" : "static",
          ...l ? {
            moveRange: 60 + Math.floor(60 * r()),
            moveSpeed: .8 + 1.5 * r(),
            moveAxis: "x",
            moveOffset: 0
          } : {}
        })
      }
      a = e <= 3 || e <= 5 ? 1 : e <= 10 || e <= 30 ? 2 : e <= 50 ? 2 + Math.floor(2 * r()) : e <= 100 ? 3 + Math
        .floor(2 * r()) : e <= 200 ? 5 + Math.floor(3 * r()) : e <= 500 ? 7 + Math.floor(4 * r()) : 10 + Math.floor(
          5 * r());
      let v = [],
        w = [];
      e <= 15 ? w.push("drone") : e <= 30 ? w.push("drone", "glitchWalker") : e <= 50 ? w.push("drone", "drone",
          "glitchWalker", "voidGuardian") : w.push("drone", "glitchWalker", "voidGuardian"), e >= 50 && w.push(
          "shadowAssassin", "eliteDrone"), e >= 80 && w.push("dragon"), e >= 100 && w.push("voidBat", "stormEagle",
          "emberWisp", "zombie"), e >= 150 && w.push("frostWraith", "shadowDrake", "plasmaSerpent", "giant"), e >=
        200 && w.push("neonWyrm", "crystalMoth", "necromancer"), e >= 300 && w.push("mechGolem"), e >= 400 && w
        .push("phoenix"), e >= 500 && w.push("bomber"), e >= 700 && w.push("heavyWalker");
      let k = ["Stay focused. They're coming.", "Another wave... bring it.", "We've come too far to stop now.",
          "This zone is crawling with them.", "Keep pushing. Don't look back.", "They think they can stop us?",
          "For Luna. For everyone.", "This is getting intense...", "We will beat the Red King!",
          "I can do this all day.", "The Grid trembles before us.", "No retreat. No surrender.",
          "I am the Neon Stickman. I don't go dark.", "Every battle makes me stronger.",
          "This realm will know my name."
        ],
        C = `Level ${e} — ${u}`;
      e % 100 == 1 && (C = `CHAPTER ${d}: ${u} — A new frontier awaits!`);
      for (let o = 0; o < a; o++) {
        let l;
        l = e <= 3 ? 1 : e <= 5 ? 1 + Math.floor(+r()) : e <= 10 ? 1 + Math.floor(2 * r()) : e <= 30 ? 2 + Math
          .floor(+r()) : e <= 50 ? 2 + Math.floor(2 * r()) : e <= 100 ? 4 + Math.floor(3 * r()) : e <= 200 ? 5 +
          Math.floor(4 * r()) : e <= 500 ? 7 + Math.floor(5 * r()) : 10 + Math.floor(6 * r());
        let n = 300 + Math.floor(o / a * (t - 800)),
          i = n + Math.floor((t - 800) / a),
          s = [];
        for (let e = 0; e < l; e++) {
          let e = w[Math.floor(r() * w.length)],
            t = E(e);
          s.push({
            x: n + Math.floor(r() * (i - n)),
            y: t ? 150 + Math.floor(200 * r()) : 480,
            type: e
          })
        }
        v.push({
          enemies: s,
          voiceLine: 0 === o ? k[Math.floor(r() * k.length)] : void 0
        })
      }
      let S = e >= 50 && e % 10 == 0,
        T = e >= 100 && e % 50 == 0;
      if (S || T)
        if (100 === e) l = {
          enemies: [{
            x: t - 400,
            y: 480,
            type: "bossTwin",
            bossName: "YOUR TWIN BROTHER",
            bossColor: p
          }],
          voiceLine: "You... you look just like me!"
        };
        else {
          let e = ["bossRedKing", "bossTitan", "bossCorrupted", "bossDragon", "bossPhoenix", "bossMechGolem",
              "bossFather", "bossTwin"
            ],
            o = e[Math.floor(r() * e.length)],
            a = ["CORRUPTED KING", "THE ABYSS", "VOID EMPEROR", "DARK TITAN", "SHADOW LORD", "PLASMA REAPER",
              "NEON DEVOURER", "THE INFINITE", "DRAGON KING", "PHOENIX LORD", "MECH OVERLORD", "VOID SERPENT",
              "CHROME REAPER", "THE HUNGRY DARK", "IRON JUGGERNAUT", "PHANTOM WYRM", "CRYSTAL TYRANT",
              "THE NAMELESS", "STORM BRINGER", "DOOM WEAVER", "FATHER", "THE PATRIARCH", "BLUE'S FATHER",
              "YOUR TWIN"
            ],
            s = [f, h, i, c, "#ff0044", "#8800ff", m, n, p];
          l = {
            enemies: [{
              x: t - 400,
              y: 480,
              type: o,
              bossName: a[Math.floor(r() * a.length)],
              bossColor: s[Math.floor(r() * s.length)]
            }],
            voiceLine: "This ends NOW!"
          }
        } let M = ["city", "corrupted", "firewall", "warehouse", "rooftop", "void", "core", "grid"],
        j = M[Math.floor(r() * M.length)],
        N = ["fight", "fight", "fight", "rescue", "protect", "escape"],
        P = S || T ? "boss" : N[Math.floor(r() * N.length)],
        A = ["NEON ALLEY", "DARK CORRIDOR", "FIRE ZONE", "VOID SECTOR", "CORRUPTED PATH", "GRID MAZE",
          "SHADOW TUNNEL", "CRYSTAL CAVE", "PLASMA BRIDGE", "DEATH ROW", "BURNING HALL", "FROZEN GATE", "THE ABYSS",
          "CHASM WALK", "IRON GAUNTLET", "TOXIC DRAIN", "DATA STREAM", "GLITCH HIGHWAY", "RENDER ZONE", "DEEP CORE",
          "DRAGON'S LAIR", "MECH FACTORY", "PHOENIX NEST", "SHADOW CITADEL", "CHROME WASTES", "EMBER FIELDS",
          "FROST SPIRE", "VOLT ARENA", "SILENT RUINS", "WARP TUNNEL", "PHANTOM GATE", "NEON CATHEDRAL",
          "BLOOD GRID", "SOUL REEF", "NULL ZONE"
        ],
        R = A[Math.floor(r() * A.length)],
        I = ["neonSign", "brokenPillar", "glitchCrystal", "voidRift", "dataStream"],
        L = 3 + Math.floor(6 * r()),
        D = [];
      for (let e = 0; e < L; e++) D.push({
        x: 100 + Math.floor(r() * (t - 200)),
        y: 350 + Math.floor(150 * r()),
        type: I[Math.floor(r() * I.length)]
      });
      let W = ["none", "none", "rain", "snow", "glitch", "embers", "voidParticles"],
        O = W[Math.floor(r() * W.length)];
      return {
        id: e,
        name: R,
        chapter: `CH.${d}`,
        width: t,
        height: 600,
        playerSpawn: {
          x: 80 + Math.floor(Math.random() * 40),
          y: 460
        },
        platforms: x,
        waves: v,
        bossWave: l,
        background: j,
        introText: C,
        introColor: [n, c, i, h, s, m][Math.floor(6 * r())],
        missionType: P,
        gangMembersAvailable: [],
        isProcedural: !0,
        environmentalObjects: D,
        weatherType: O
      }
    }

    function V(e) {
      let t = 9301 * e + 49297;
      return () => (t = (9301 * t + 49297) % 233280) / 233280
    }
    let z = {
        "ch1-intro": {
          id: "ch1-intro",
          frames: [{
            scene: "cityPan",
            dialogue: "",
            speaker: "NARRATOR",
            speakerColor: c,
            duration: 180
          }, {
            scene: "kidnapping",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }, {
            scene: "blueWakes",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }]
        },
        "ch2-intro": {
          id: "ch2-intro",
          frames: [{
            scene: "warScene",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }, {
            scene: "shadowAppears",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }, {
            scene: "handshake",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }]
        },
        "ch2-blaze": {
          id: "ch2-blaze",
          frames: [{
            scene: "warScene",
            dialogue: "",
            speaker: "BLAZE",
            speakerColor: c,
            duration: 180
          }, {
            scene: "gangJoin",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 120
          }]
        },
        "ch3-intro": {
          id: "ch3-intro",
          frames: [{
            scene: "lunaCaptured",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 150
          }, {
            scene: "blueAngry",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }]
        },
        "ch3-rescue": {
          id: "ch3-rescue",
          frames: [{
            scene: "reunion",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 150
          }, {
            scene: "blueSeesLuna",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }]
        },
        "ch4-intro": {
          id: "ch4-intro",
          frames: [{
            scene: "motherThreat",
            dialogue: "",
            speaker: "VOLT",
            speakerColor: d,
            duration: 180
          }, {
            scene: "protectMother",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: f,
            duration: 150
          }]
        },
        "ch5-intro": {
          id: "ch5-intro",
          frames: [{
            scene: "warScene",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 180
          }, {
            scene: "gangForming",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 180
          }]
        },
        victory: {
          id: "victory",
          frames: [{
            scene: "bossDefeated",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 150
          }, {
            scene: "victoryCelebration",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }, {
            scene: "reunion",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 120
          }]
        },
        revive: {
          id: "revive",
          frames: [{
            scene: "blueWakes",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 120
          }]
        },
        "lv10-revelation": {
          id: "lv10-revelation",
          frames: [{
            scene: "darkRevelation",
            dialogue: "",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "flashback",
            dialogue: "",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "darkCorridor",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }, {
            scene: "redKingPlan",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }]
        },
        "lv20-luna": {
          id: "lv20-luna",
          frames: [{
            scene: "lunaVision",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 200
          }, {
            scene: "lunaVision",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 200
          }, {
            scene: "mysteryFigure",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }]
        },
        "lv30-shadow": {
          id: "lv30-shadow",
          frames: [{
            scene: "shadowPast",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 200
          }, {
            scene: "betrayal",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 200
          }, {
            scene: "darkRevelation",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }, {
            scene: "gangOath",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }]
        },
        "lv40-mother": {
          id: "lv40-mother",
          frames: [{
            scene: "motherSecret",
            dialogue: "",
            speaker: "NEON",
            speakerColor: "#44ddaa",
            duration: 200
          }, {
            scene: "flashback",
            dialogue: "Your father was the First Guardian. He built the Grid. And the Red King... was his partner.",
            speaker: "NEON",
            speakerColor: "#44ddaa",
            duration: 220
          }, {
            scene: "darkRevelation",
            dialogue: "",
            speaker: "NEON",
            speakerColor: "#44ddaa",
            duration: 200
          }, {
            scene: "blueAngry",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: f,
            duration: 180
          }]
        },
        "lv50-void": {
          id: "lv50-void",
          frames: [{
            scene: "voidRift",
            dialogue: "",
            speaker: "BLAZE",
            speakerColor: c,
            duration: 180
          }, {
            scene: "explosion",
            dialogue: "The Void... it's bleeding into our world. The Red King tore the fabric of the Grid!",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "mysteryFigure",
            dialogue: "",
            speaker: "ICE",
            speakerColor: "#44ddff",
            duration: 180
          }, {
            scene: "stormApproaching",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 200
          }]
        },
        "lv60-deal": {
          id: "lv60-deal",
          frames: [{
            scene: "hiddenBase",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 200
          }, {
            scene: "theDeal",
            dialogue: "I can enter the Void Rift. Merge with the Grid's core. But I might not come back.",
            speaker: "LUNA",
            speakerColor: x,
            duration: 200
          }, {
            scene: "silentPrayer",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }, {
            scene: "sacrifice",
            dialogue: "If it saves everyone... including you... I'll do it. With or without your permission.",
            speaker: "LUNA",
            speakerColor: x,
            duration: 200
          }]
        },
        "lv70-betrayal": {
          id: "lv70-betrayal",
          frames: [{
            scene: "darkCorridor",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 200
          }, {
            scene: "betrayal",
            dialogue: "",
            speaker: "???",
            speakerColor: c,
            duration: 200
          }, {
            scene: "lastStand",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: f,
            duration: 180
          }, {
            scene: "gangOath",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }]
        },
        "lv80-truth": {
          id: "lv80-truth",
          frames: [{
            scene: "truthRevealed",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 220
          }, {
            scene: "voidRift",
            dialogue: "",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "flashback",
            dialogue: "My father created the Grid as a sanctuary. For everyone. The Red King turned it into a prison.",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }, {
            scene: "gangOath",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 180
          }]
        },
        "lv90-final": {
          id: "lv90-final",
          frames: [{
            scene: "hiddenBase",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }, {
            scene: "gangForming",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 200
          }, {
            scene: "silentPrayer",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }, {
            scene: "newDawn",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 180
          }]
        },
        "lv100-turning": {
          id: "lv100-turning",
          frames: [{
            scene: "bossDefeated",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 200
          }, {
            scene: "voidRift",
            dialogue: "Something is coming THROUGH the rift. Something that makes the Red King look like nothing.",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "mysteryFigure",
            dialogue: "",
            speaker: "???",
            speakerColor: "#ff0044",
            duration: 220
          }, {
            scene: "stormApproaching",
            dialogue: "A new enemy. A bigger war. But the Blue Gang doesn't surrender. We just fight HARDER.",
            speaker: "BLUE",
            speakerColor: m,
            duration: 200
          }]
        },
        "boss-redking-intro": {
          id: "boss-redking-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "RED KING",
            speakerColor: f,
            duration: 180
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "RED KING",
            speakerColor: f,
            duration: 200
          }, {
            scene: "blueAngry",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "boss-dragon-intro": {
          id: "boss-dragon-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "NARRATOR",
            speakerColor: c,
            duration: 180
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }]
        },
        "boss-phoenix-intro": {
          id: "boss-phoenix-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "NARRATOR",
            speakerColor: c,
            duration: 180
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "boss-mechgolem-intro": {
          id: "boss-mechgolem-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "NARRATOR",
            speakerColor: c,
            duration: 180
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "boss-corrupted-intro": {
          id: "boss-corrupted-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "VOLT",
            speakerColor: d,
            duration: 200
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }]
        },
        "boss-father-intro": {
          id: "boss-father-intro",
          frames: [{
            scene: "darkCorridor",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "FATHER",
            speakerColor: "#44aaff",
            duration: 220
          }, {
            scene: "blueAngry",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: f,
            duration: 200
          }]
        },
        "boss-twin-intro": {
          id: "boss-twin-intro",
          frames: [{
            scene: "bossIntro",
            dialogue: "",
            speaker: "BLAZE",
            speakerColor: c,
            duration: 180
          }, {
            scene: "bossIntro",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "boss-generic-defeated": {
          id: "boss-generic-defeated",
          frames: [{
            scene: "bossDefeated",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }, {
            scene: "victoryCelebration",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 150
          }]
        },
        "boss-redking-defeated": {
          id: "boss-redking-defeated",
          frames: [{
            scene: "bossDefeated",
            dialogue: "",
            speaker: "RED KING",
            speakerColor: f,
            duration: 200
          }, {
            scene: "bossDefeated",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }, {
            scene: "victoryCelebration",
            dialogue: "",
            speaker: "BLAZE",
            speakerColor: c,
            duration: 180
          }]
        },
        "boss-father-defeated": {
          id: "boss-father-defeated",
          frames: [{
            scene: "bossDefeated",
            dialogue: "",
            speaker: "FATHER",
            speakerColor: "#44aaff",
            duration: 220
          }, {
            scene: "silentPrayer",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 200
          }, {
            scene: "bossDefeated",
            dialogue: "",
            speaker: "FATHER",
            speakerColor: "#44aaff",
            duration: 220
          }]
        },
        "rescue-luna": {
          id: "rescue-luna",
          frames: [{
            scene: "lunaCaptured",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 150
          }, {
            scene: "reunion",
            dialogue: "",
            speaker: "LUNA",
            speakerColor: x,
            duration: 180
          }, {
            scene: "reunion",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "rescue-mother": {
          id: "rescue-mother",
          frames: [{
            scene: "protectMother",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }, {
            scene: "protectMother",
            dialogue: "",
            speaker: "NEON",
            speakerColor: "#44ddaa",
            duration: 200
          }, {
            scene: "protectMother",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: n,
            duration: 180
          }]
        },
        "rescue-villagers": {
          id: "rescue-villagers",
          frames: [{
            scene: "walking",
            dialogue: "",
            speaker: "SHADOW",
            speakerColor: h,
            duration: 180
          }, {
            scene: "gangForming",
            dialogue: "",
            speaker: "BLUE",
            speakerColor: m,
            duration: 200
          }]
        }
      },
      _ = {
        kill: ["Deleted.", "Stay down.", "One less.", "Crashed.", "Lights out.", "Too slow.", "Dust.", "Erased."],
        damage: ["That all you got?", "Just a scratch.", "Not today.", "I've had worse.", "Tickles.",
          "Keep coming."],
        waveClear: ["Zone secured.", "Moving up.", "Area clear.", "Next.", "Too easy.", "Onward."],
        dash: ["Too fast.", "Can't touch this.", "Gone.", "Blurred."],
        shield: ["Blocked.", "Nope.", "Nice try.", "Not even close."],
        special: ["OVERLOAD!", "BURN IT DOWN!", "LIGHT 'EM UP!", "UNLEASH THE GRID!", "MAXIMUM POWER!"],
        gang: ["Gang, attack!", "Together!", "Blue Gang never quits!", "Crew assemble!"],
        rescue: ["Luna, I'm coming!", "Hold on!", "I'll find you!", "Hang in there!"],
        protect: ["Not touching her!", "Stay back from Mom!", "Over my dead body!", "Shield up!"],
        dramatic: ["Reinforcements have arrived!", "We will beat the Red King!", "Stay with me, partner!",
          "This ends NOW!", "They think they can break us?", "NOT TODAY!", "I am NOT done yet!",
          "For EVERYONE you hurt!", "The Grid fights with me!", "I AM the storm!"
        ],
        bossEnrage: ["You're only making me ANGRY!", "Is that ALL you've got?!", "NOW you'll see REAL power!",
          "You woke the WRONG stickman!"
        ],
        pet: ["Good boy!", "Get 'em!", "Atta boy!", "Nice shot, partner!"],
        dragon: ["A DRAGON! Bring it down!", "Fire can't stop me!", "Dragon slayer incoming!"],
        phoenix: ["It rises from the ashes?!", "Burn again, bird!", "Phoenix down!"],
        mechGolem: ["Tin can incoming!", "Dismantle it!", "Mech detected — engaging!"],
        shadowAssassin: ["I can barely see it!", "Show yourself!", "Shadows can't hide from me!"],
        voidBat: ["Bats from the void!", "Fast little nightmares!", "They come from the dark!"],
        stormEagle: ["Lightning bird incoming!", "That eagle's charged up!", "Storm wings above!"],
        emberWisp: ["Fire spirits! Watch out!", "Those wisps burn!", "Floating flames!"],
        frostWraith: ["Ice ghost detected!", "It's freezing in here!", "A cold wind rises!"],
        shadowDrake: ["Shadow dragon approaches!", "The darkness has teeth!", "That drake is not natural!"],
        plasmaSerpent: ["Energy serpent spotted!", "It's made of pure plasma!",
          "That snake electrifies everything!"],
        neonWyrm: ["THE WYRM! Look at the size of it!", "Neon wyrm! Stay clear!", "That thing is massive!"],
        crystalMoth: ["Crystal moths? Beautiful but deadly!", "Those wings are sharp!",
          "Don't let it shimmer close!"
        ]
      },
      K = "neonStickman_save_v4",
      q = !1;
    async function Y(t) {
      if (q) try {
        let {
          uploadSaveToCloud: o
        } = await e.A(66060);
        if (await o(t)) try {
          let {
            logAnalyticsEvent: o
          } = await e.A(76207);
          o("cloud_sync", {
            level: t.highestLevel,
            coins: t.totalCoins
          })
        } catch {}
      } catch {}
    }

    function J() {
      try {
        let e = localStorage.getItem(K);
        if (!e) return {
          ...B,
          rankingData: {
            ...D
          }
        };
        let t = JSON.parse(e),
          o = t.unlockedSkins || ["neon-green"];
        o.includes("neon-green") || o.push("neon-green");
        let a = "default" === t.currentSkin ? "neon-green" : t.currentSkin || "neon-green";
        return {
          ...B,
          ...t,
          unlockedSkins: o,
          currentSkin: a,
          rankingData: {
            ...D,
            ...t.rankingData || {}
          },
          unlockedPets: t.unlockedPets || ["neonWolf"],
          unlockedPetSkins: t.unlockedPetSkins || ["wolf-default"],
          username: t.username || B.username,
          avatar: t.avatar || B.avatar,
          about: t.about ?? B.about,
          nationality: t.nationality ?? B.nationality,
          unlockedSkills: t.unlockedSkills ?? B.unlockedSkills,
          equippedSkills: (t.equippedSkills ?? B.equippedSkills).slice(0, 3).concat(["", "", ""]).slice(0, 3),
          skillUpgrades: t.skillUpgrades ?? B.skillUpgrades,
          lastDailyRewardDay: t.lastDailyRewardDay ?? B.lastDailyRewardDay,
          dailyRewardStreak: t.dailyRewardStreak ?? B.dailyRewardStreak,
          levelStars: t.levelStars ?? B.levelStars,
          weaponUpgrades: t.weaponUpgrades ?? B.weaponUpgrades,
          hasSeenTapToStart: t.hasSeenTapToStart ?? B.hasSeenTapToStart,
          skinUpgrades: t.skinUpgrades ?? B.skinUpgrades,
          gangMembersUnlocked: t.gangMembersUnlocked ?? B.gangMembersUnlocked,
          missionsCompleted: t.missionsCompleted ?? B.missionsCompleted
        }
      } catch {
        return {
          ...B,
          rankingData: {
            ...D
          }
        }
      }
    }

    function Z(e) {
      try {
        e.lastSaveTime = Date.now(), localStorage.setItem(K, JSON.stringify(e)), Y(e)
      } catch {}
    }

    function X(e, t) {
      return {
        ...e,
        totalCoins: e.totalCoins + t
      }
    }

    function Q(e) {
      let t = new Date().toISOString().split("T")[0];
      return e.lastDailyRewardDay !== t
    }
    let ee = {
        masterVolume: .7,
        sfxVolume: .8,
        musicVolume: .5,
        musicEnabled: !0,
        sfxEnabled: !0
      },
      et = "neonStickman_sound_v1",
      eo = new class {
        ctx = null;
        masterGain = null;
        sfxGain = null;
        musicGain = null;
        musicPlaying = !1;
        bossMusicPlaying = !1;
        menuMusicPlaying = !1;
        musicInterval = null;
        bossMusicInterval = null;
        menuMusicInterval = null;
        noiseBuffer = null;
        shortNoiseBuffer = null;
        lastSfxTime = {};
        SFX_THROTTLE_MS = 50;
        activeNodeCount = 0;
        MAX_ACTIVE_NODES = 30;
        lastResumeTime = 0;
        RESUME_THROTTLE_MS = 500;
        masterVolume = .7;
        sfxVolume = .8;
        musicVolume = .5;
        musicEnabled = !0;
        sfxEnabled = !0;
        init() {
          if (!this.ctx) try {
            this.ctx = new AudioContext, this.masterGain = this.ctx.createGain(), this.masterGain.gain.value =
              this.masterVolume, this.masterGain.connect(this.ctx.destination), this.sfxGain = this.ctx
              .createGain(), this.sfxGain.gain.value = this.sfxVolume, this.sfxGain.connect(this.masterGain),
              this.musicGain = this.ctx.createGain(), this.musicGain.gain.value = this.musicVolume, this
              .musicGain.connect(this.masterGain), this.noiseBuffer = this.createNoiseBuffer(4410), this
              .shortNoiseBuffer = this.createNoiseBuffer(2205)
          } catch {}
        }
        createNoiseBuffer(e) {
          if (!this.ctx) return null;
          let t = this.ctx.createBuffer(1, e, this.ctx.sampleRate),
            o = t.getChannelData(0);
          for (let t = 0; t < e; t++) o[t] = 2 * Math.random() - 1;
          return t
        }
        ensureCtx() {
          if (this.ctx || this.init(), this.ctx?.state === "suspended") {
            let e = performance.now();
            e - this.lastResumeTime >= this.RESUME_THROTTLE_MS && (this.lastResumeTime = e, this.ctx.resume())
          }
        }
        canPlaySfx(e) {
          let t = performance.now();
          return !(t - (this.lastSfxTime[e] || 0) < this.SFX_THROTTLE_MS) && (this.lastSfxTime[e] = t, !0)
        }
        setMasterVolume(e) {
          this.masterVolume = e, this.masterGain && (this.masterGain.gain.value = e), this.saveSettings()
        }
        setSfxVolume(e) {
          this.sfxVolume = e, this.sfxGain && (this.sfxGain.gain.value = e), this.saveSettings()
        }
        setMusicVolume(e) {
          this.musicVolume = e, this.musicGain && (this.musicGain.gain.value = e), this.saveSettings()
        }
        setMusicEnabled(e) {
          this.musicEnabled = e, e ? this.ctx && this.startMusic() : this.stopMusic(), this.saveSettings()
        }
        setSfxEnabled(e) {
          this.sfxEnabled = e, this.saveSettings()
        }
        playTone(e, t, o = "square", a = .3, l) {
          if (this.sfxEnabled && this.ctx && this.sfxGain && !(this.activeNodeCount >= this.MAX_ACTIVE_NODES) && (
              this.ensureCtx(), "running" === this.ctx.state)) try {
            this.activeNodeCount++;
            let r = this.ctx.createOscillator(),
              n = this.ctx.createGain();
            r.type = o, r.frequency.setValueAtTime(e, this.ctx.currentTime), void 0 !== l && r.frequency
              .linearRampToValueAtTime(l, this.ctx.currentTime + t), n.gain.setValueAtTime(a, this.ctx
                .currentTime), n.gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime + t), r.connect(
              n), n.connect(this.sfxGain), r.start(this.ctx.currentTime), r.stop(this.ctx.currentTime + t), r
              .onended = () => {
                this.activeNodeCount = Math.max(0, this.activeNodeCount - 1)
              }
          } catch {
            this.activeNodeCount = Math.max(0, this.activeNodeCount - 1)
          }
        }
        playNoise(e, t = .3, o) {
          if (this.sfxEnabled && this.ctx && this.sfxGain && !(this.activeNodeCount >= this.MAX_ACTIVE_NODES) && (
              this.ensureCtx(), "running" === this.ctx.state)) try {
            this.activeNodeCount++;
            let a = this.ctx.createBufferSource(),
              l = this.noiseBuffer || this.shortNoiseBuffer;
            if (!l) {
              this.activeNodeCount = Math.max(0, this.activeNodeCount - 1);
              return
            }
            a.buffer = l;
            let r = this.ctx.createGain();
            if (r.gain.setValueAtTime(t, this.ctx.currentTime), r.gain.exponentialRampToValueAtTime(.001, this
                .ctx.currentTime + e), o) {
              let e = this.ctx.createBiquadFilter();
              e.type = "bandpass", e.frequency.value = o, e.Q.value = 2, a.connect(e), e.connect(r)
            } else a.connect(r);
            r.connect(this.sfxGain), a.start(this.ctx.currentTime), a.stop(this.ctx.currentTime + e), a
              .onended = () => {
                this.activeNodeCount = Math.max(0, this.activeNodeCount - 1)
              }
          } catch {
            this.activeNodeCount = Math.max(0, this.activeNodeCount - 1)
          }
        }
        playToneNoise(e, t, o = "sine", a = .2, l = .15, r) {
          this.playTone(e, t, o, a), this.playNoise(r ?? t, l)
        }
        playShoot() {
          this.canPlaySfx("shoot") && this.playTone(800, .15, "square", .15, 400)
        }
        playDash() {
          this.canPlaySfx("dash") && this.playNoise(.15, .2, 2e3)
        }
        playShield() {
          this.canPlaySfx("shield") && (this.playTone(220, .12, "sine", .12), this.playTone(330, .12, "sine", .1),
            setTimeout(() => {
              this.playTone(220, .1, "sine", .08), this.playTone(330, .1, "sine", .06)
            }, 120))
        }
        playSpecial() {
          this.playTone(200, .3, "square", .15, 800)
        }
        playHit() {
          this.canPlaySfx("hit") && this.playToneNoise(100, .08, "sine", .12, .15, .06)
        }
        playExplosion() {
          this.canPlaySfx("explosion") && (this.playNoise(.4, .25, 200), this.playTone(60, .4, "sine", .2, 20))
        }
        playJump() {
          this.canPlaySfx("jump") && this.playTone(300, .08, "sine", .12, 600)
        }
        playEnemyDeath() {
          this.canPlaySfx("enemyDeath") && this.playTone(600, .15, "square", .1, 100)
        }
        playBossHit() {
          this.canPlaySfx("bossHit") && (this.playTone(80, .2, "sawtooth", .15, 40), this.playNoise(.1, .15, 500))
        }
        playWaveComplete() {
          [440, 554, 659].forEach((e, t) => {
            setTimeout(() => this.playTone(e, .15, "sine", .15), 150 * t)
          })
        }
        playLevelComplete() {
          [440, 554, 659, 880].forEach((e, t) => {
            setTimeout(() => this.playTone(e, .2, "sine", .2), 150 * t)
          })
        }
        playVersusVictory() {
          [523, 659, 784].forEach((e, t) => {
            setTimeout(() => this.playTone(e, .3, "sine", .12), 200 * t)
          })
        }
        playGameOver() {
          this.playTone(300, .8, "sawtooth", .15, 50)
        }
        playMenuClick() {
          this.playTone(1e3, .04, "sine", .1)
        }
        playMenuHover() {
          this.playTone(600, .02, "sine", .06)
        }
        playCoinCollect() {
          this.canPlaySfx("coin") && (this.playTone(1200, .08, "sine", .1), setTimeout(() => this.playTone(1500,
            .08, "sine", .08), 40))
        }
        playAbilityReady() {
          this.playTone(800, .12, "sine", .1, 1e3)
        }
        playDamage() {
          this.canPlaySfx("damage") && (this.playNoise(.1, .15), this.playTone(80, .08, "sine", .12))
        }
        playPetShoot() {
          this.canPlaySfx("petShoot") && this.playTone(1400, .06, "square", .08, 900)
        }
        playPetDeath() {
          this.playTone(500, .4, "sine", .12, 100), setTimeout(() => this.playTone(350, .2, "sine", .08, 150),
            150)
        }
        playPetRespawn() {
          this.playTone(400, .12, "sine", .1, 800)
        }
        playDramaticMoment() {
          [220, 330, 440, 660].forEach((e, t) => {
            setTimeout(() => this.playTone(e, .25, "sine", .15), 80 * t)
          })
        }
        playReinforcement() {
          this.playTone(440, .12, "sine", .15), setTimeout(() => this.playTone(554, .12, "sine", .12), 80),
            setTimeout(() => this.playTone(880, .2, "sine", .18), 160)
        }
        playBossEnrage() {
          this.playTone(100, .4, "sawtooth", .2, 50), this.playNoise(.2, .15, 300)
        }
        playVictoryFanfare() {
          this.sfxEnabled && this.ctx && this.sfxGain && ([523, 659, 784, 1047, 1319].forEach((e, t) => {
            setTimeout(() => {
              this.playTone(e, .3, "sine", .18), t < 3 && this.playTone(1.5 * e, .25, "sine", .06)
            }, 180 * t)
          }), setTimeout(() => {
            this.playTone(523, .6, "sine", .12), this.playTone(659, .6, "sine", .1), this.playTone(784, .6,
              "sine", .1)
          }, 1e3))
        }
        startMusic() {
          if (!this.musicEnabled || this.musicPlaying || this.bossMusicPlaying || this.menuMusicPlaying || !this
            .ctx || !this.musicGain) return;
          this.ensureCtx(), this.musicPlaying = !0;
          let e = () => {
              if (!this.ctx || !this.musicGain) return;
              let e = this.ctx.createOscillator(),
                t = this.ctx.createGain();
              e.type = "sine", e.frequency.setValueAtTime(150, this.ctx.currentTime), e.frequency
                .exponentialRampToValueAtTime(30, this.ctx.currentTime + .12), t.gain.setValueAtTime(.4, this.ctx
                  .currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime + .15), e.connect(
                  t), t.connect(this.musicGain), e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .15)
            },
            t = () => {
              if (!this.ctx || !this.musicGain || !this.shortNoiseBuffer) return;
              let e = this.ctx.createBufferSource();
              e.buffer = this.shortNoiseBuffer;
              let t = this.ctx.createGain();
              t.gain.setValueAtTime(.08, this.ctx.currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx
                .currentTime + .04);
              let o = this.ctx.createBiquadFilter();
              o.type = "highpass", o.frequency.value = 8e3, e.connect(o), o.connect(t), t.connect(this.musicGain),
                e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .04)
            },
            o = () => {
              if (!this.ctx || !this.musicGain || !this.shortNoiseBuffer) return;
              let e = this.ctx.createBufferSource();
              e.buffer = this.shortNoiseBuffer;
              let t = this.ctx.createGain();
              t.gain.setValueAtTime(.12, this.ctx.currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx
                .currentTime + .1);
              let o = this.ctx.createBiquadFilter();
              o.type = "bandpass", o.frequency.value = 3e3, o.Q.value = 1, e.connect(o), o.connect(t), t.connect(
                this.musicGain), e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .1);
              let a = this.ctx.createOscillator(),
                l = this.ctx.createGain();
              a.type = "triangle", a.frequency.value = 180, l.gain.setValueAtTime(.1, this.ctx.currentTime), l
                .gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime + .06), a.connect(l), l.connect(this
                  .musicGain), a.start(this.ctx.currentTime), a.stop(this.ctx.currentTime + .06)
            },
            a = (e, t = .15) => {
              if (!this.ctx || !this.musicGain) return;
              let o = this.ctx.createOscillator(),
                a = this.ctx.createGain();
              o.type = "sawtooth", o.frequency.value = e, a.gain.setValueAtTime(.15, this.ctx.currentTime), a.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + t);
              let l = this.ctx.createBiquadFilter();
              l.type = "lowpass", l.frequency.setValueAtTime(400, this.ctx.currentTime), l.frequency
                .exponentialRampToValueAtTime(200, this.ctx.currentTime + t), l.Q.value = 5, o.connect(l), l
                .connect(a), a.connect(this.musicGain), o.start(this.ctx.currentTime), o.stop(this.ctx
                  .currentTime + t)
            },
            l = e => {
              if (!this.ctx || !this.musicGain) return;
              let t = this.ctx.createOscillator(),
                o = this.ctx.createGain();
              t.type = "square", t.frequency.value = e, o.gain.setValueAtTime(.04, this.ctx.currentTime), o.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + .1);
              let a = this.ctx.createBiquadFilter();
              a.type = "lowpass", a.frequency.value = 2500, a.Q.value = 2, t.connect(a), a.connect(o), o.connect(
                this.musicGain), t.start(this.ctx.currentTime), t.stop(this.ctx.currentTime + .1)
            },
            r = e => {
              if (!this.ctx || !this.musicGain) return;
              let t = this.ctx.createOscillator(),
                o = this.ctx.createGain();
              t.type = "sine", t.frequency.value = e, o.gain.setValueAtTime(.03, this.ctx.currentTime), o.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + .08), t.connect(o), o.connect(this
                  .musicGain), t.start(this.ctx.currentTime), t.stop(this.ctx.currentTime + .08)
            },
            n = [55, 55, 55, 65, 55, 55, 73, 55, 55, 55, 55, 65, 73, 73, 65, 55],
            i = [330, 0, 392, 0, 440, 0, 392, 330, 330, 0, 0, 392, 440, 0, 392, 0],
            s = [220, 277, 330, 277, 220, 277, 330, 370, 220, 277, 330, 277, 370, 330, 277, 220],
            c = 0;
          this.musicInterval = setInterval(() => {
            if (!this.musicPlaying) return;
            let d = c % 16;
            (0 === d || 4 === d || 8 === d || 12 === d) && e(), (4 === d || 12 === d) && o(), d % 2 == 0 &&
              t(), (d % 2 == 0 || 3 === d || 7 === d || 11 === d || 15 === d) && a(n[d], d % 4 == 0 ? .2 :
              .1), i[d] > 0 && d % 2 == 0 && l(i[d]), d % 2 == 0 && r(s[d]), c++
          }, .42857142857142855 * 1e3 / 2)
        }
        stopMusic() {
          this.musicPlaying = !1, this.musicInterval && (clearInterval(this.musicInterval), this.musicInterval =
            null)
        }
        startMenuMusic() {
          if (!this.musicEnabled || this.menuMusicPlaying || this.musicPlaying || this.bossMusicPlaying || !this
            .ctx || !this.musicGain) return;
          this.ensureCtx(), this.menuMusicPlaying = !0;
          let e = (e, t) => {
              if (!this.ctx || !this.musicGain) return;
              let o = this.ctx.createOscillator(),
                a = this.ctx.createGain();
              o.type = "sine", o.frequency.value = e, a.gain.setValueAtTime(.04, this.ctx.currentTime), a.gain
                .linearRampToValueAtTime(.06, this.ctx.currentTime + .3 * t), a.gain.exponentialRampToValueAtTime(
                  .001, this.ctx.currentTime + t);
              let l = this.ctx.createBiquadFilter();
              l.type = "lowpass", l.frequency.value = 800, l.Q.value = 1, o.connect(l), l.connect(a), a.connect(
                this.musicGain), o.start(this.ctx.currentTime), o.stop(this.ctx.currentTime + t)
            },
            t = e => {
              if (!this.ctx || !this.musicGain) return;
              let t = this.ctx.createOscillator(),
                o = this.ctx.createGain();
              t.type = "triangle", t.frequency.value = e, o.gain.setValueAtTime(.08, this.ctx.currentTime), o.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + .4);
              let a = this.ctx.createBiquadFilter();
              a.type = "lowpass", a.frequency.value = 250, t.connect(a), a.connect(o), o.connect(this.musicGain),
                t.start(this.ctx.currentTime), t.stop(this.ctx.currentTime + .4)
            },
            o = () => {
              if (!this.ctx || !this.musicGain) return;
              let e = this.ctx.createOscillator(),
                t = this.ctx.createGain();
              e.type = "sine", e.frequency.setValueAtTime(100, this.ctx.currentTime), e.frequency
                .exponentialRampToValueAtTime(25, this.ctx.currentTime + .15), t.gain.setValueAtTime(.2, this.ctx
                  .currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime + .15), e.connect(
                  t), t.connect(this.musicGain), e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .15)
            },
            a = [
              [110, 165, 220],
              [87, 131, 175],
              [65, 98, 131],
              [98, 147, 196]
            ],
            l = [55, 43, 65, 49],
            r = 0;
          this.menuMusicInterval = setInterval(() => {
            if (!this.menuMusicPlaying) return;
            let n = r % 16;
            if ((0 === n || 8 === n) && o(), (0 === n || 4 === n || 8 === n || 12 === n) && t(l[Math.floor(n /
                4)]), 0 === n)
              for (let t of a[Math.floor(r / 4) % 4]) e(t, 2.5);
            if (2 === n || 6 === n || 10 === n || 14 === n) {
              if (!this.ctx || !this.musicGain) return;
              let e = this.ctx.createOscillator(),
                t = this.ctx.createGain();
              e.type = "sine", e.frequency.value = 880 + 100 * Math.sin(.1 * r), t.gain.setValueAtTime(.02,
                  this.ctx.currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime +
                .15), e.connect(t), t.connect(this.musicGain), e.start(this.ctx.currentTime), e.stop(this.ctx
                  .currentTime + .15)
            }
            r++
          }, .6666666666666666 * 1e3)
        }
        stopMenuMusic() {
          this.menuMusicPlaying = !1, this.menuMusicInterval && (clearInterval(this.menuMusicInterval), this
            .menuMusicInterval = null)
        }
        startBossMusic() {
          if (!this.musicEnabled || this.bossMusicPlaying || !this.ctx || !this.musicGain) return;
          this.ensureCtx(), this.stopMusic(), this.stopMenuMusic(), this.bossMusicPlaying = !0;
          let e = () => {
              if (!this.ctx || !this.musicGain) return;
              let e = this.ctx.createOscillator(),
                t = this.ctx.createGain();
              e.type = "sine", e.frequency.setValueAtTime(200, this.ctx.currentTime), e.frequency
                .exponentialRampToValueAtTime(25, this.ctx.currentTime + .1), t.gain.setValueAtTime(.45, this.ctx
                  .currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx.currentTime + .12), e.connect(
                  t), t.connect(this.musicGain), e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .12)
            },
            t = () => {
              if (!this.ctx || !this.musicGain || !this.shortNoiseBuffer) return;
              let e = this.ctx.createBufferSource();
              e.buffer = this.shortNoiseBuffer;
              let t = this.ctx.createGain();
              t.gain.setValueAtTime(.1, this.ctx.currentTime), t.gain.exponentialRampToValueAtTime(.001, this.ctx
                .currentTime + .025);
              let o = this.ctx.createBiquadFilter();
              o.type = "highpass", o.frequency.value = 1e4, e.connect(o), o.connect(t), t.connect(this.musicGain),
                e.start(this.ctx.currentTime), e.stop(this.ctx.currentTime + .025)
            },
            o = e => {
              if (!this.ctx || !this.musicGain) return;
              let t = this.ctx.createOscillator(),
                o = this.ctx.createGain();
              t.type = "sawtooth", t.frequency.value = e, o.gain.setValueAtTime(.18, this.ctx.currentTime), o.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + .12);
              let a = this.ctx.createBiquadFilter();
              a.type = "lowpass", a.frequency.setValueAtTime(600, this.ctx.currentTime), a.frequency
                .exponentialRampToValueAtTime(300, this.ctx.currentTime + .12), a.Q.value = 4, t.connect(a), a
                .connect(o), o.connect(this.musicGain), t.start(this.ctx.currentTime), t.stop(this.ctx
                  .currentTime + .12)
            },
            a = e => {
              if (!this.ctx || !this.musicGain) return;
              let t = this.ctx.createOscillator(),
                o = this.ctx.createGain();
              t.type = "square", t.frequency.value = e, o.gain.setValueAtTime(.05, this.ctx.currentTime), o.gain
                .exponentialRampToValueAtTime(.001, this.ctx.currentTime + .08);
              let a = this.ctx.createBiquadFilter();
              a.type = "lowpass", a.frequency.value = 2e3, t.connect(a), a.connect(o), o.connect(this.musicGain),
                t.start(this.ctx.currentTime), t.stop(this.ctx.currentTime + .08)
            },
            l = [41, 41, 49, 41, 55, 55, 49, 41],
            r = [330, 0, 440, 0, 330, 0, 494, 440],
            n = 0;
          this.bossMusicInterval = setInterval(() => {
            if (!this.bossMusicPlaying) return;
            let i = n % 8;
            (0 === i || 2 === i || 4 === i || 6 === i) && e(), t(), i % 2 == 0 && o(l[i]), r[i] > 0 && i %
              2 == 0 && a(r[i]), n++
          }, .3333333333333333 * 1e3)
        }
        stopBossMusic() {
          this.bossMusicPlaying = !1, this.bossMusicInterval && (clearInterval(this.bossMusicInterval), this
            .bossMusicInterval = null)
        }
        isBossMusicPlaying() {
          return this.bossMusicPlaying
        }
        stopAll() {
          this.stopMusic(), this.stopBossMusic(), this.stopMenuMusic()
        }
        saveSettings() {
          try {
            let e = {
              masterVolume: this.masterVolume,
              sfxVolume: this.sfxVolume,
              musicVolume: this.musicVolume,
              musicEnabled: this.musicEnabled,
              sfxEnabled: this.sfxEnabled
            };
            localStorage.setItem(et, JSON.stringify(e))
          } catch {}
        }
        loadSettings() {
          try {
            let e = localStorage.getItem(et);
            if (!e) return {
              ...ee
            };
            let t = JSON.parse(e),
              o = {
                ...ee,
                ...t
              };
            return this.masterVolume = o.masterVolume, this.sfxVolume = o.sfxVolume, this.musicVolume = o
              .musicVolume, this.musicEnabled = o.musicEnabled, this.sfxEnabled = o.sfxEnabled, this.masterGain &&
              (this.masterGain.gain.value = this.masterVolume), this.sfxGain && (this.sfxGain.gain.value = this
                .sfxVolume), this.musicGain && (this.musicGain.gain.value = this.musicVolume), o
          } catch {
            return {
              ...ee
            }
          }
        }
      },
      ea = (t = (e, t) => ({
        gamePhase: "menu",
        gameMode: "single",
        currentLevel: 1,
        score: 0,
        totalScore: 0,
        currentWave: 0,
        totalWaves: 0,
        isBossLevel: !1,
        canRevive: !0,
        hasUsedRevive: !1,
        revivedWithFullPower: !1,
        currentStoryChapter: 1,
        currentCutscene: null,
        cutsceneFrameIndex: 0,
        cutsceneTextProgress: 0,
        voiceLine: null,
        dramaticMoment: null,
        introText: null,
        introColor: "#00ffff",
        introTimer: 0,
        saveData: J(),
        soundSettings: eo.loadSettings(),
        lastLevelStars: 0,
        lastLevelKills: 0,
        lastLevelMaxCombo: 0,
        lastLevelCoinsEarned: 0,
        lastLevelHealthPct: 0,
        lastLevelTotalEnemies: 0,
        versusP1Wins: 0,
        versusP2Wins: 0,
        versusCurrentRound: 1,
        versusTotalRounds: 3,
        versusRoundWinner: 0,
        versusMatchWinner: 0,
        dashCooldown: 0,
        shieldCooldown: 0,
        specialCooldown: 0,
        waitingForTap: !1,
        setGamePhase: t => e({
          gamePhase: t
        }),
        setGameMode: t => e({
          gameMode: t
        }),
        startVersus: () => {
          e({
            gameMode: "versus",
            gamePhase: "playing",
            currentLevel: -1,
            score: 0,
            currentWave: 0,
            totalWaves: 0,
            isBossLevel: !1,
            canRevive: !1,
            hasUsedRevive: !1,
            versusP1Wins: 0,
            versusP2Wins: 0,
            versusCurrentRound: 1,
            versusTotalRounds: 3,
            versusRoundWinner: 0,
            versusMatchWinner: 0,
            introText: "FIGHT!",
            introColor: "#ffd700",
            introTimer: 90,
            voiceLine: null,
            waitingForTap: !1
          })
        },
        versusRoundWin: o => {
          let a = t();
          if (3 === o) return void e({
            versusRoundWinner: 3,
            versusCurrentRound: a.versusCurrentRound + 1
          });
          let l = 1 === o ? a.versusP1Wins + 1 : a.versusP1Wins,
            r = 2 === o ? a.versusP2Wins + 1 : a.versusP2Wins,
            n = Math.ceil(a.versusTotalRounds / 2);
          l >= n ? e({
            versusP1Wins: l,
            versusP2Wins: r,
            versusRoundWinner: o,
            versusMatchWinner: 1
          }) : r >= n ? e({
            versusP1Wins: l,
            versusP2Wins: r,
            versusRoundWinner: o,
            versusMatchWinner: 2
          }) : e({
            versusP1Wins: l,
            versusP2Wins: r,
            versusRoundWinner: o,
            versusCurrentRound: a.versusCurrentRound + 1
          })
        },
        versusResetRound: () => {
          e({
            versusRoundWinner: 0,
            gamePhase: "playing",
            introText: `ROUND ${t().versusCurrentRound} — FIGHT!`,
            introColor: "#ffd700",
            introTimer: 90,
            waitingForTap: !1
          })
        },
        versusMatchEnd: t => {
          e({
            versusMatchWinner: t,
            gamePhase: "level-complete"
          })
        },
        startGame: () => {
          let e = t().saveData;
          e.highestLevel >= 1 ? t().startLevel(e.highestLevel) : t().startCutscene("ch1-intro")
        },
        startLevel: o => {
          let a = G.find(e => e.id === o) || U(o);
          if (!a) return;
          let l = a.waves.length + +!!a.bossWave,
            r = function(e) {
              if (1 !== e && e % 10 != 0) return null;
              if (F[e]) return F[e];
              if (e > 250 && e % 10 == 0) {
                let t = Math.floor((e - 1) / 100) + 6;
                return `ch${t}-zone`
              }
              return 1 === e ? "ch1-intro" : null
            }(o),
            n = 1 === o && !t().saveData.hasSeenTapToStart;
          r && z[r] ? (e({
            currentLevel: o,
            score: 0,
            currentWave: 0,
            totalWaves: l,
            isBossLevel: !1,
            canRevive: !0,
            hasUsedRevive: !1,
            voiceLine: null
          }), t().startCutscene(r)) : e({
            currentLevel: o,
            score: 0,
            currentWave: 0,
            totalWaves: l,
            isBossLevel: !1,
            canRevive: !0,
            hasUsedRevive: !1,
            gamePhase: "playing",
            voiceLine: null,
            introText: a.introText,
            introColor: a.introColor,
            introTimer: 60,
            waitingForTap: n
          })
        },
        showVoiceLine: (t, o, a = 90) => {
          e({
            voiceLine: {
              text: t,
              color: o,
              timer: a
            }
          })
        },
        triggerDramaticMoment: (t, o, a = 150) => {
          e({
            dramaticMoment: {
              text: t,
              color: o,
              timer: a
            }
          })
        },
        advanceWave: () => {
          let {
            currentWave: o,
            totalWaves: a,
            currentLevel: l
          } = t(), r = o + 1, n = G.find(e => e.id === l) || U(l);
          if (r >= a) {
            let e = t().score + 200;
            t().completeLevel(e);
            return
          }
          n?.bossWave && r === a - 1 && e({
            isBossLevel: !0
          }), e({
            currentWave: r
          })
        },
        completeLevel: o => {
          let {
            currentLevel: a,
            totalScore: l,
            saveData: r,
            lastLevelStars: n,
            lastLevelKills: i,
            lastLevelMaxCombo: s,
            lastLevelHealthPct: c,
            lastLevelTotalEnemies: d
          } = t(), h = l + o, f = Math.floor(o / 5), u = n;
          0 === u && d > 0 ? (u = 1, (c > 40 || i >= .5 * d) && (u = 2), c > 70 && i >= .8 * d && (u = 3)) :
            0 === u && (u = 1);
          let m = {
            ...r
          };
          (m = X(m = function(e, t) {
            let o = {
              ...e
            };
            for (let e of C) {
              var a, l;
              e.unlockLevel && e.unlockLevel <= t && !o.unlockedSkins.includes(e.id) && (a = o, l = e.id,
                o = a.unlockedSkins.includes(l) ? a : {
                  ...a,
                  unlockedSkins: [...a.unlockedSkins, l]
                })
            }
            for (let e of P) "level" === e.unlockMethod && e.unlockLevel && e.unlockLevel <= t && !o
              .unlockedSkills.includes(e.id) && (o.unlockedSkills = [...o.unlockedSkills, e.id]);
            return t > o.highestLevel && (o.highestLevel = t), o
          }(m, a), f)).totalScore = h, m.missionsCompleted.includes(String(a)) || (m.missionsCompleted = [...m
            .missionsCompleted, String(a)
          ]);
          let x = String(a);
          u > (m.levelStars?.[x] ?? 0) && (m.levelStars = {
            ...m.levelStars,
            [x]: u
          });
          let p = G.find(e => e.id === a) || U(a);
          if (p) {
            for (let e of p.gangMembersAvailable)
              if (!m.gangMembersUnlocked.includes(e)) {
                let t = k.find(t => t.id === e);
                t && t.joinChapter <= parseInt(p.chapter.replace("CH.", "")) && (m.gangMembersUnlocked = [...m
                  .gangMembersUnlocked, e
                ])
              }
          }
          if (a <= 2 ? m.currentChapter = 1 : a <= 4 ? m.currentChapter = 2 : a <= 6 ? m.currentChapter = 3 :
            a <= 7 ? m.currentChapter = 4 : m.currentChapter = 5, a >= m.highestLevel && (m.highestLevel = a +
              1), a > 8) {
            let o = Math.min(Math.floor((a - 1) / 100) + 6, 200);
            o > t().currentStoryChapter && e({
              currentStoryChapter: o
            })
          }
          Z(m), e({
            score: o,
            totalScore: h,
            saveData: m,
            gamePhase: "level-complete"
          })
        },
        gameOver: () => {
          let {
            saveData: o,
            hasUsedRevive: a
          } = t(), l = {
            ...o,
            totalDeaths: o.totalDeaths + 1
          };
          Z(l), eo.stopAll(), e({
            gamePhase: "game-over",
            saveData: l,
            canRevive: !a
          })
        },
        nextLevel: () => {
          let o = t().currentLevel + 1;
          o <= 100 ? t().startLevel(o) : e({
            gamePhase: "menu"
          })
        },
        retryLevel: () => {
          t().startLevel(t().currentLevel)
        },
        backToMenu: () => {
          eo.stopAll(), e({
            gamePhase: "menu",
            gameMode: "single",
            voiceLine: null,
            dramaticMoment: null,
            introText: null,
            introTimer: 0,
            currentCutscene: null,
            versusP1Wins: 0,
            versusP2Wins: 0,
            versusCurrentRound: 1,
            versusRoundWinner: 0,
            versusMatchWinner: 0,
            waitingForTap: !1
          })
        },
        revive: () => {
          let {
            hasUsedRevive: o,
            saveData: a
          } = t();
          o || (e({
            hasUsedRevive: !0,
            canRevive: !1,
            revivedWithFullPower: !0
          }), z.revive ? t().startCutscene("revive") : e({
            gamePhase: "playing",
            waitingForTap: !1
          }))
        },
        startCutscene: o => {
          let a = null;
          if (!a) {
            let o = t().currentLevel,
              a = G.find(e => e.id === o) || U(o);
            e({
              gamePhase: "playing",
              waitingForTap: !1,
              introText: a.introText || "GET READY!",
              introColor: a.introColor || n,
              introTimer: 60
            });
            return
          }
          e({
            currentCutscene: a,
            cutsceneFrameIndex: 0,
            cutsceneTextProgress: 0,
            gamePhase: "cutscene"
          })
        },
        advanceCutscene: () => {
          let {
            currentCutscene: o,
            cutsceneFrameIndex: a
          } = t();
          if (!o) return;
          let l = a + 1;
          if (l < o.frames.length) e({
            cutsceneFrameIndex: l,
            cutsceneTextProgress: 0
          });
          else {
            e({
              currentCutscene: null,
              cutsceneFrameIndex: 0,
              cutsceneTextProgress: 0
            });
            let o = t().currentLevel,
              a = G.find(e => e.id === o) || U(o);
            e({
              gamePhase: "playing",
              introText: a.introText,
              introColor: a.introColor,
              introTimer: 60,
              waitingForTap: !1
            })
          }
        },
        skipCutscene: () => {
          let {
            currentCutscene: o
          } = t();
          if (!o) return;
          e({
            currentCutscene: null,
            cutsceneFrameIndex: 0,
            cutsceneTextProgress: 0
          });
          let a = t().currentLevel,
            l = G.find(e => e.id === a) || U(a);
          l ? e({
            gamePhase: "playing",
            introText: l.introText,
            introColor: l.introColor,
            introTimer: 60,
            waitingForTap: !1
          }) : a >= 100 ? e({
            gamePhase: "victory"
          }) : e({
            gamePhase: "level-complete"
          })
        },
        saveGame: () => {
          Z(t().saveData)
        },
        loadGame: () => {
          e({
            saveData: J()
          })
        },
        buySkin: o => {
          let a, {
              saveData: l
            } = t(),
            r = !(a = C.find(e => e.id === o)) || l.unlockedSkins.includes(o) || l.totalCoins < a.price ?
            null : {
              ...l,
              totalCoins: l.totalCoins - a.price,
              unlockedSkins: [...l.unlockedSkins, o]
            };
          return !!r && (Z(r), e({
            saveData: r
          }), !0)
        },
        selectSkin: o => {
          let {
            saveData: a
          } = t(), l = a.unlockedSkins.includes(o) ? {
            ...a,
            currentSkin: o
          } : a;
          Z(l), e({
            saveData: l
          })
        },
        buyPet: o => {
          let a, {
              saveData: l
            } = t(),
            r = (a = v.find(e => e.id === o)) ? l.unlockedPets.includes(o) ? l : l.totalCoins < a.price ?
            null : {
              ...l,
              totalCoins: l.totalCoins - a.price,
              unlockedPets: [...l.unlockedPets, o]
            } : null;
          return !!r && (Z(r), e({
            saveData: r
          }), !0)
        },
        selectPet: o => {
          let {
            saveData: a
          } = t(), l = a.unlockedPets.includes(o) ? {
            ...a,
            currentPet: o
          } : a;
          Z(l), e({
            saveData: l
          })
        },
        buyPetSkin: o => {
          let a, {
              saveData: l
            } = t(),
            r = !(a = w.find(e => e.id === o)) || l.unlockedPetSkins.includes(o) || l.totalCoins < a.price ?
            null : {
              ...l,
              totalCoins: l.totalCoins - a.price,
              unlockedPetSkins: [...l.unlockedPetSkins, o]
            };
          return !!r && (Z(r), e({
            saveData: r
          }), !0)
        },
        selectPetSkin: o => {
          let {
            saveData: a
          } = t(), l = function(e, t) {
            if (!e.unlockedPetSkins.includes(t)) return e;
            let o = w.find(e => e.id === t);
            return o ? {
              ...e,
              currentPetSkin: t,
              currentPet: o.petId
            } : e
          }(a, o);
          Z(l), e({
            saveData: l
          })
        },
        addCoinsFromScore: o => {
          let a = Math.floor(o / 5),
            {
              saveData: l
            } = t();
          e({
            saveData: X(l, a)
          })
        },
        addCoinsReward: o => {
          let {
            saveData: a
          } = t(), l = X(a, o);
          Z(l), e({
            saveData: l
          })
        },
        setSoundSettings: o => {
          e({
              soundSettings: {
                ...t().soundSettings,
                ...o
              }
            }), void 0 !== o.masterVolume && eo.setMasterVolume(o.masterVolume), void 0 !== o.sfxVolume && eo
            .setSfxVolume(o.sfxVolume), void 0 !== o.musicVolume && eo.setMusicVolume(o.musicVolume),
            void 0 !== o.musicEnabled && eo.setMusicEnabled(o.musicEnabled), void 0 !== o.sfxEnabled && eo
            .setSfxEnabled(o.sfxEnabled)
        },
        updateProfile: o => {
          let {
            saveData: a
          } = t(), l = {
            ...a,
            ...o
          };
          Z(l), e({
            saveData: l
          })
        },
        updateRanking: o => {
          let {
            saveData: a
          } = t(), l = {
            ...a.rankingData
          };
          o ? (l.wins++, l.elo += 25) : (l.losses++, l.elo = Math.max(0, l.elo - 15));
          let r = {
            ...a,
            rankingData: l
          };
          Z(r), e({
            saveData: r
          })
        },
        buySkill: o => {
          let {
            saveData: a
          } = t(), l = P.find(e => e.id === o);
          if (!l || a.unlockedSkills.includes(o)) return !1;
          if ("ad" === l.unlockMethod || "purchase" === l.unlockMethod || "chest" === l.unlockMethod) {
            if (l.unlockCost > 0 && a.totalCoins < l.unlockCost) return !1;
            let t = {
              ...a,
              totalCoins: l.unlockCost > 0 ? a.totalCoins - l.unlockCost : a.totalCoins,
              unlockedSkills: [...a.unlockedSkills, o]
            };
            return Z(t), e({
              saveData: t
            }), !0
          }
          return !1
        },
        equipSkill: (o, a) => {
          let {
            saveData: l
          } = t();
          if (!l.unlockedSkills.includes(o) || a < 0 || a > 2) return;
          let r = [...l.equippedSkills],
            n = r.indexOf(o);
          for (n >= 0 && (r[n] = ""), r[a] = o; r.length > 3;) r.pop();
          for (; r.length < 3;) r.push("");
          let i = {
            ...l,
            equippedSkills: r
          };
          Z(i), e({
            saveData: i
          })
        },
        unequipSkill: o => {
          let {
            saveData: a
          } = t();
          if (o < 0 || o > 2) return;
          let l = [...a.equippedSkills];
          for (l[o] = ""; l.length > 3;) l.pop();
          for (; l.length < 3;) l.push("");
          let r = {
            ...a,
            equippedSkills: l
          };
          Z(r), e({
            saveData: r
          })
        },
        upgradeSkill: o => {
          let {
            saveData: a
          } = t(), l = function(e, t) {
            if (!e.unlockedSkills.includes(t)) return null;
            let o = e.skillUpgrades[t] ?? 1;
            if (o >= 5) return null;
            let a = M[o];
            if (a > 0 && e.totalCoins < a) return null;
            let l = {
              ...e.skillUpgrades,
              [t]: o + 1
            };
            return {
              ...e,
              totalCoins: a > 0 ? e.totalCoins - a : e.totalCoins,
              skillUpgrades: l
            }
          }(a, o);
          return !!l && (Z(l), e({
            saveData: l
          }), !0)
        },
        claimDailyReward: () => {
          let {
            saveData: o
          } = t(), a = function(e) {
            let t;
            if (!Q(e)) return null;
            let o = new Date().toISOString().split("T")[0],
              a = new Date(Date.now() - 864e5).toISOString().split("T")[0];
            if ("" === e.lastDailyRewardDay || e.lastDailyRewardDay === a) t = Math.min(e
              .dailyRewardStreak + 1, 7);
            else {
              if (e.lastDailyRewardDay === o) return null;
              t = 1
            }
            let l = Math.min(t - 1, N.length - 1),
              r = N[l];
            return {
              save: {
                ...e,
                totalCoins: e.totalCoins + r.coins,
                lastDailyRewardDay: o,
                dailyRewardStreak: t
              },
              coins: r.coins,
              day: t
            }
          }(o);
          return a ? (Z(a.save), e({
            saveData: a.save
          }), {
            coins: a.coins,
            day: a.day
          }) : null
        },
        canClaimDaily: () => {
          let {
            saveData: e
          } = t();
          return Q(e)
        },
        upgradeWeapon: o => {
          let {
            saveData: a
          } = t(), l = a.weaponUpgrades[o] ?? 0;
          if (l >= y[o].maxLevel) return !1;
          let r = b(o, l);
          if (false) return !1;
          let n = {
              ...a.weaponUpgrades,
              [o]: l + 1
            },
            i = {
              ...a,
              totalCoins: a.totalCoins - r,
              weaponUpgrades: n
            };
          return Z(i), e({
            saveData: i
          }), !0
        },
        upgradeWeaponByAd: o => {
          let {
            saveData: a
          } = t(), l = a.weaponUpgrades[o] ?? 0;
          if (l >= y[o].maxLevel) return;
          let r = {
              ...a.weaponUpgrades,
              [o]: l + 1
            },
            n = {
              ...a,
              weaponUpgrades: r
            };
          Z(n), e({
            saveData: n
          })
        },
        updateCooldowns: (t, o, a) => {
          e({
            dashCooldown: t,
            shieldCooldown: o,
            specialCooldown: a
          })
        },
        tapToStart: () => {
          let {
            saveData: o
          } = t(), a = {
            ...o,
            hasSeenTapToStart: !0
          };
          Z(a), e({
            waitingForTap: !1,
            saveData: a
          }), "u" > typeof navigator && navigator.vibrate && navigator.vibrate(30)
        },
        upgradeSkinPower: o => {
          let {
            saveData: a
          } = t(), l = C.find(e => e.id === o);
          if (!l || !a.unlockedSkins.includes(o)) return !1;
          let r = a.skinUpgrades?.[o] ?? 0,
            n = Math.floor((l.price > 0 ? l.price : 500) * Math.pow(2, r + 1));
          if (a.totalCoins < n) return !1;
          let i = {
              ...a.skinUpgrades,
              [o]: r + 1
            },
            s = {
              ...a,
              totalCoins: a.totalCoins - n,
              skinUpgrades: i
            };
          return Z(s), e({
            saveData: s
          }), !0
        },
        upgradeSkinPowerByAd: o => {
          let {
            saveData: a
          } = t();
          if (!C.find(e => e.id === o) || !a.unlockedSkins.includes(o)) return;
          let l = a.skinUpgrades?.[o] ?? 0,
            r = {
              ...a.skinUpgrades,
              [o]: l + 1
            },
            n = {
              ...a,
              skinUpgrades: r
            };
          Z(n), e({
            saveData: n
          })
        },
        setCloudSync: e => {
          q = e
        },
        loadCloudSave: o => {
          let a, l = t().saveData,
            r = l.totalScore,
            n = o.totalScore,
            i = l.highestLevel,
            s = o.highestLevel;
          Z(a = s > i || s === i && n > r ? {
            ...o,
            totalCoins: Math.max(l.totalCoins, o.totalCoins)
          } : l), e({
            saveData: a
          })
        },
        resetSave: () => {
          try {
            localStorage.removeItem(K), localStorage.removeItem("neonStickman_sound_v1")
          } catch {}
          e({
            saveData: {
              ...B,
              rankingData: {
                ...D
              }
            },
            soundSettings: {
              ...ee
            }
          })
        }
      })) ? r(t) : r,
      el = new Set,
      er = {
        user: null,
        loading: !0,
        error: null,
        isAnonymous: !1
      },
      en = !1;
    async function ei() {
      if (en) return;
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t(), {
        onAuthStateChanged: a
      } = await e.A(3975);
      en = !0, a(o, e => {
        er = {
          user: e,
          loading: !1,
          error: null,
          isAnonymous: e?.isAnonymous ?? !1
        }, el.forEach(e => e(er))
      })
    }

    function es(e) {
      return el.add(e), e(er), ei(), () => el.delete(e)
    }
    let ec = !1;
    async function ed() {
      if (ec) return er.user;
      ec = !0;
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t();
      if (o.currentUser) return o.currentUser;
      try {
        let {
          signInAnonymously: t
        } = await e.A(3975);
        return (await t(o)).user
      } catch (e) {
        return console.error("Auto anonymous sign-in failed:", e), ec = !1, null
      }
    }
    async function eh() {
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t(), {
        signInAnonymously: a
      } = await e.A(3975);
      try {
        return (await a(o)).user
      } catch (e) {
        return console.error("Anonymous sign-in failed:", e), null
      }
    }
    async function ef() {
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t(), {
        signInWithPopup: a,
        signInWithRedirect: l,
        GoogleAuthProvider: r
      } = await e.A(3975), n = new r;
      try {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window
          .matchMedia("(hover: none) and (pointer: coarse)").matches) return await l(o, n), null;
        return (await a(o, n)).user
      } catch (e) {
        if ("auth/popup-closed-by-user" === e.code) return null;
        return console.error("Google sign-in failed:", e), null
      }
    }
    async function eu() {
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t(), {
        getRedirectResult: a
      } = await e.A(3975);
      try {
        let e = await a(o);
        return e?.user ?? null
      } catch (e) {
        return console.error("Redirect sign-in failed:", e), null
      }
    }
    async function em() {
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = await t(), {
        signOut: a
      } = await e.A(3975);
      try {
        await a(o)
      } catch (e) {
        console.error("Sign out failed:", e)
      }
    }
    async function ex() {
      let {
        getFirebaseAuth: t
      } = await e.A(76207), o = (await t()).currentUser;
      return o ? {
        uid: o.uid,
        displayName: o.displayName || "NeonWarrior",
        email: o.email,
        photoURL: o.photoURL,
        isAnonymous: o.isAnonymous
      } : null
    }
    var ep = e.i(47053);

    function eg() {
      return !!window.Capacitor?.isNativePlatform?.()
    }
    class ey {
      static instance;
      levelsCompleted = 0;
      INTERSTITIAL_INTERVAL = 2;
      bannerVisible = !1;
      lastAdTime = 0;
      AD_COOLDOWN_MS = 3e3;
      adsWatchedCount = 0;
      lastInterstitialTime = 0;
      admobReady = !1;
      isTesting = !1;
      static getInstance() {
        return ey.instance || (ey.instance = new ey), ey.instance
      }
      async initialize() {
        if (!eg()) {
          console.log("[AdManager] Web mode - using simulated ads"), this.admobReady = !1;
          return
        }
        try {
          let {
            AdMob: t
          } = await e.A(31982);
          await t.initialize({
            initializeForTesting: this.isTesting
          }), this.admobReady = !0, console.log("[AdManager] Native AdMob initialized")
        } catch (e) {
          console.error("[AdManager] Native AdMob init failed; using fallback ads:", e), this.admobReady = !1
        }
      }
      onLevelComplete() {
        return this.levelsCompleted++, this.levelsCompleted % this.INTERSTITIAL_INTERVAL == 0
      }
      canShowInterstitial() {
        return Date.now() - this.lastInterstitialTime > 6e4
      }
      async showInterstitial(t) {
        if (!this.canShowInterstitial()) return !1;
        if (this.lastInterstitialTime = Date.now(), this.adsWatchedCount++, eg() && this.admobReady) try {
          let {
            AdMob: t
          } = await e.A(31982);
          return await t.prepareInterstitial({
            adId: "ca-app-pub-6439599735010649/8990244364",
            isTesting: this.isTesting
          }), await t.showInterstitial(), !0
        } catch (e) {
          return console.error("[AdManager] Interstitial failed:", e), !1
        }
        return new Promise(e => {
          let o = Date.now(),
            a = setInterval(() => {
              let l = Date.now() - o,
                r = Math.min(100, l / 2e3 * 100);
              t?.(r, l), l >= 2e3 && (clearInterval(a), e(!0))
            }, 50)
        })
      }
      async showRewardedAd(t) {
        if (Date.now() - this.lastAdTime < this.AD_COOLDOWN_MS) return {
          rewarded: !1,
          reason: "cooldown",
          durationMs: 0
        };
        if (this.lastAdTime = Date.now(), this.adsWatchedCount++, eg() && this.admobReady) try {
          let {
            AdMob: t
          } = await e.A(31982);
          await t.prepareRewardVideoAd({
            adId: "ca-app-pub-6439599735010649/4027131683",
            isTesting: this.isTesting
          });
          let o = await t.showRewardVideoAd();
          if ("earned" === o.type) return {
            rewarded: !0,
            durationMs: 0
          };
          return {
            rewarded: !1,
            reason: "closed_early",
            durationMs: 0
          }
        } catch (e) {
          return console.error("[AdManager] Rewarded ad failed:", e), {
            rewarded: !1,
            reason: "error",
            durationMs: 0
          }
        }
        let o = 3e3 + 2e3 * Math.random(),
          a = Date.now();
        return new Promise(e => {
          let l = setInterval(() => {
            let r = Date.now() - a,
              n = Math.min(100, r / o * 100);
            t?.(n, r), r >= o && (clearInterval(l), e({
              rewarded: !0,
              durationMs: r
            }))
          }, 50)
        })
      }
      async showRewardedAdWithCallbacks(e, t, o) {
        let a = await this.showRewardedAd(o);
        a.rewarded ? e() : t && a.reason && t(a.reason)
      }
      async showBannerAd() {
        if (this.bannerVisible = !0, eg() && this.admobReady) try {
          let {
            AdMob: t
          } = await e.A(31982);
          await t.prepareBanner({
            adId: "ca-app-pub-6439599735010649/7774805003",
            isTesting: this.isTesting,
            position: "BOTTOM_CENTER",
            adSize: "ADAPTIVE_BANNER"
          }), await t.showBanner()
        } catch (e) {
          console.error("[AdManager] Banner failed:", e)
        }
      }
      async hideBannerAd() {
        if (this.bannerVisible = !1, eg() && this.admobReady) try {
          let {
            AdMob: t
          } = await e.A(31982);
          await t.hideBanner()
        } catch (e) {
          console.error("[AdManager] Hide banner failed:", e)
        }
      }
      isBannerVisible() {
        return this.bannerVisible
      }
      getLevelsCompleted() {
        return this.levelsCompleted
      }
      getAdsWatched() {
        return this.adsWatchedCount
      }
      reset() {
        this.levelsCompleted = 0, this.adsWatchedCount = 0, this.lastInterstitialTime = 0
      }
    }
    let eb = ey.getInstance();
    async function ev() {
      try {
        let e = document.documentElement;
        e.requestFullscreen && await e.requestFullscreen()
      } catch {}
      try {
        let e = screen.orientation;
        e && e.lock && await e.lock("landscape")
      } catch {}
    }

    function ew() {
      return window.matchMedia("(hover: none) and (pointer: coarse)").matches ||
        /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    }
    let ek = () => () => {};

    function eC() {
      let e, t = (0, a.useSyncExternalStore)(ek, () => ew(), () => !1),
        l = (e = (0, a.useCallback)(e => {
          let t = () => e();
          return window.addEventListener("resize", t), window.addEventListener("orientationchange", t), () => {
            window.removeEventListener("resize", t), window.removeEventListener("orientationchange", t)
          }
        }, []), (0, a.useSyncExternalStore)(e, () => window.innerHeight > 1.4 * window.innerWidth && !
      function() {
          try {
            return screen.orientation.type.includes("landscape")
          } catch (e) {
            return !1
          }
        }(), () => !1));
      return ((0, a.useEffect)(() => {
        ew() && ev()
      }, []), !1) ? (0, o.jsxs)("div", {
        className: "fixed inset-0 z-[9999] bg-[#050510] flex flex-col items-center justify-center gap-6",
        children: [(0, o.jsxs)("div", {
          className: "relative w-20 h-32 border-2 border-cyan-400 rounded-lg rotate-90 transition-transform",
          style: {
            animation: "landscape-hint 2s ease-in-out infinite",
            boxShadow: "0 0 20px rgba(0, 255, 255, 0.4), inset 0 0 10px rgba(0, 255, 255, 0.1)"
          },
          children: [(0, o.jsx)("div", {
            className: "absolute inset-2 border border-cyan-400/40 rounded",
            style: {
              boxShadow: "0 0 8px rgba(0, 255, 255, 0.2)"
            },
            children: (0, o.jsx)("div", {
              className: "flex items-center justify-center h-full",
              children: (0, o.jsxs)("svg", {
                width: "16",
                height: "30",
                viewBox: "0 0 16 30",
                stroke: "#00ffff",
                strokeWidth: "1.5",
                fill: "none",
                children: [(0, o.jsx)("circle", {
                  cx: "8",
                  cy: "5",
                  r: "4"
                }), (0, o.jsx)("line", {
                  x1: "8",
                  y1: "9",
                  x2: "8",
                  y2: "20"
                }), (0, o.jsx)("line", {
                  x1: "8",
                  y1: "13",
                  x2: "3",
                  y2: "17"
                }), (0, o.jsx)("line", {
                  x1: "8",
                  y1: "13",
                  x2: "13",
                  y2: "17"
                }), (0, o.jsx)("line", {
                  x1: "8",
                  y1: "20",
                  x2: "4",
                  y2: "28"
                }), (0, o.jsx)("line", {
                  x1: "8",
                  y1: "20",
                  x2: "12",
                  y2: "28"
                })]
              })
            })
          }), (0, o.jsx)("div", {
            className: "absolute bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 rounded-full bg-cyan-400/30"
          })]
        }), (0, o.jsx)("div", {
          className: "absolute",
          style: {
            top: "50%",
            right: "20%",
            transform: "translateY(-50%)",
            animation: "arrow-bounce 1.5s ease-in-out infinite"
          },
          children: (0, o.jsxs)("svg", {
            width: "40",
            height: "40",
            viewBox: "0 0 40 40",
            stroke: "#00ffff",
            strokeWidth: "2",
            fill: "none",
            children: [(0, o.jsx)("path", {
              d: "M10 20 A10 10 0 0 1 30 20"
            }), (0, o.jsx)("path", {
              d: "M28 14 L30 20 L24 18",
              stroke: "#00ffff",
              strokeWidth: "2",
              fill: "none"
            })]
          })
        }), (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("p", {
            className: "text-cyan-400 text-lg font-bold tracking-wider",
            style: {
              textShadow: "0 0 10px rgba(0, 255, 255, 0.6)"
            },
            children: "ROTATE YOUR DEVICE"
          }), (0, o.jsx)("p", {
            className: "text-cyan-400/60 text-sm mt-2 tracking-wide",
            children: "Best played in landscape mode"
          })]
        }), (0, o.jsx)("div", {
          className: "absolute bottom-0 left-0 right-0 h-16 overflow-hidden opacity-20",
          children: (0, o.jsx)("div", {
            className: "w-full h-full",
            style: {
              backgroundImage: `
              linear-gradient(90deg, rgba(0,255,255,0.3) 1px, transparent 1px),
              linear-gradient(0deg, rgba(0,255,255,0.3) 1px, transparent 1px)
            `,
              backgroundSize: "40px 20px",
              transform: "perspective(200px) rotateX(60deg)",
              transformOrigin: "bottom"
            }
          })
        })]
      }) : null
    }
    let eS = {
        fire: "#ff4400",
        frost: "#88eeff",
        shadow: "#8800ff",
        summon: "#aa00ff",
        death: "#330033",
        lightning: "#ffff00",
        void: "#ff00ff",
        blood: "#cc0000"
      },
      eT = {
        fire: "FIRE",
        frost: "FROST",
        shadow: "SHADOW",
        summon: "SUMMON",
        death: "DEATH",
        lightning: "LIGHTNING",
        void: "VOID",
        blood: "BLOOD"
      },
      eM = {
        common: "#888888",
        rare: n,
        epic: i,
        legendary: m
      },
      ej = {
        common: "#888888",
        rare: n,
        epic: i,
        legendary: m
      };

    function eN({
      onComplete: e
    }) {
      let [t, l] = (0, a.useState)(0);
      return (0, a.useEffect)(() => {
        let e = setInterval(() => {
          l(t => t >= 100 ? (clearInterval(e), 100) : t + 2)
        }, 60);
        return () => clearInterval(e)
      }, []), (0, a.useEffect)(() => {
        if (t >= 100) {
          let t = setTimeout(e, 300);
          return () => clearTimeout(t)
        }
      }, [t, e]), (0, o.jsx)("div", {
        className: "fixed inset-0 z-50 flex flex-col items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.95)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("div", {
            className: "text-2xl font-bold font-mono mb-4",
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            children: "🎬 WATCHING AD"
          }), (0, o.jsx)("div", {
            className: "w-64 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${t}%`,
                backgroundColor: n,
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: t < 100 ? "Please wait..." : "✅ Reward unlocked!"
          })]
        })
      })
    }

    function eP() {
      let e = (0, a.useMemo)(() => Array.from({
        length: 30
      }, (e, t) => ({
        id: t,
        left: `${100*Math.random()}%`,
        size: 2 + 4 * Math.random(),
        duration: 6 + 10 * Math.random(),
        delay: 8 * Math.random(),
        color: [n, i, s, m, h][Math.floor(5 * Math.random())],
        drift: -20 + 40 * Math.random()
      })), []);
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 overflow-hidden pointer-events-none",
        "aria-hidden": "true",
        children: [e.map(e => (0, o.jsx)("div", {
          className: "absolute rounded-full",
          style: {
            left: e.left,
            bottom: "-10px",
            width: e.size,
            height: e.size,
            backgroundColor: e.color,
            boxShadow: `0 0 ${2*e.size}px ${e.color}, 0 0 ${4*e.size}px ${e.color}40`,
            animation: `particle-float ${e.duration}s linear ${e.delay}s infinite`,
            "--drift": `${e.drift}px`
          }
        }, e.id)), (0, o.jsx)("div", {
          className: "absolute bottom-0 left-0 right-0 h-20 opacity-15",
          children: (0, o.jsx)("div", {
            className: "w-full h-full",
            style: {
              backgroundImage: `
              linear-gradient(90deg, rgba(0,255,255,0.2) 1px, transparent 1px),
              linear-gradient(0deg, rgba(0,255,255,0.2) 1px, transparent 1px)
            `,
              backgroundSize: "30px 15px",
              transform: "perspective(150px) rotateX(60deg)",
              transformOrigin: "bottom"
            }
          })
        })]
      })
    }

    function eA({
      color: e,
      glowColor: t,
      width: a = 40,
      height: l = 64
    }) {
      return (0, o.jsxs)("svg", {
        width: a,
        height: l,
        viewBox: "0 0 40 64",
        style: {
          animation: "stickman-bob 2s ease-in-out infinite",
          filter: `drop-shadow(0 0 4px ${t})`
        },
        children: [(0, o.jsx)("circle", {
          cx: "20",
          cy: "10",
          r: "7",
          fill: "none",
          stroke: e,
          strokeWidth: "2.5"
        }), (0, o.jsx)("circle", {
          cx: "22",
          cy: "9",
          r: "1.5",
          fill: e
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "17",
          x2: "20",
          y2: "36",
          stroke: e,
          strokeWidth: "2.5"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "23",
          x2: "9",
          y2: "30",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "23",
          x2: "31",
          y2: "30",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "36",
          x2: "12",
          y2: "54",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "36",
          x2: "28",
          y2: "54",
          stroke: e,
          strokeWidth: "2"
        })]
      })
    }

    function eR({
      color: e,
      glowColor: t,
      size: a = 28
    }) {
      return (0, o.jsxs)("svg", {
        width: a,
        height: a,
        viewBox: "0 0 40 40",
        style: {
          filter: `drop-shadow(0 0 3px ${t})`
        },
        children: [(0, o.jsx)("circle", {
          cx: "20",
          cy: "15",
          r: "8",
          fill: "none",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("circle", {
          cx: "22",
          cy: "13",
          r: "2",
          fill: t
        }), (0, o.jsx)("ellipse", {
          cx: "20",
          cy: "30",
          rx: "10",
          ry: "6",
          fill: "none",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "12",
          y1: "34",
          x2: "8",
          y2: "39",
          stroke: e,
          strokeWidth: "1.5"
        }), (0, o.jsx)("line", {
          x1: "28",
          y1: "34",
          x2: "32",
          y2: "39",
          stroke: e,
          strokeWidth: "1.5"
        })]
      })
    }

    function eI() {
      let e, t, l = ea(e => e.startGame),
        r = ea(e => e.saveData),
        d = ea(e => e.setGamePhase),
        u = ea(e => e.setGameMode),
        x = ea(e => e.selectPet),
        p = ea(e => e.buyPet),
        g = ea(e => e.buySkin),
        y = ea(e => e.selectSkin),
        b = ea(e => e.buyPetSkin),
        k = ea(e => e.selectPetSkin),
        S = ea(e => e.buySkill),
        T = ea(e => e.equipSkill),
        M = ea(e => e.unequipSkill);
      ea(e => e.upgradeSkill);
      let j = ea(e => e.addCoinsReward),
        [N, A] = (0, a.useState)(!1),
        [R, I] = (0, a.useState)("skins"),
        [E, L] = (0, a.useState)(!1),
        [D, W] = (0, a.useState)(null),
        [B, G] = (0, a.useState)("all"),
        [$, F] = (0, a.useState)(""),
        H = (0, a.useMemo)(() => O(r.rankingData.elo), [r.rankingData.elo]),
        U = (0, a.useMemo)(() => C.find(e => e.id === r.currentSkin) || C[0], [r.currentSkin]),
        V = (0, a.useMemo)(() => v.find(e => e.id === r.currentPet) || v[0], [r.currentPet]),
        z = (0, a.useCallback)(e => {
          eo.init(), eo.playMenuClick(), e()
        }, []),
        _ = (0, a.useCallback)(e => {
          L(!0), W(() => e)
        }, []),
        K = (0, a.useCallback)(() => {
          L(!1), j(200), D && (D(), W(null))
        }, [D, j]),
        q = (0, a.useCallback)(() => {
          _(() => {
            eo.playCoinCollect()
          })
        }, [_]),
        Y = (0, a.useCallback)(() => {
          F("animate-slide-in-right"), z(() => A(!0))
        }, [z]),
        J = (0, a.useCallback)(() => {
          F("animate-slide-in-left"), z(() => A(!1))
        }, [z]),
        Z = (0, a.useMemo)(() => [{
          icon: "🔫",
          label: "",
          color: f,
          action: () => d("weapon-shop")
        }, {
          icon: "🗺️",
          label: "LEVEL MAP",
          color: c,
          action: () => d("level-map")
        }, {
          icon: "🎨",
          label: "",
          color: s,
          action: () => Y()
        }, {
          icon: "🌐",
          label: "",
          color: m,
          action: () => d("online-arena")
        }, {
          icon: "👤",
          label: "",
          color: h,
          action: () => d("profile")
        }, {
          icon: "⚙️",
          label: "",
          color: "#555",
          action: () => d("settings")
        }], [d, Y]);
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 z-20 flex flex-col pointer-events-none",
        style: {
          backgroundColor: "rgba(5,5,20,0.95)"
        },
        children: [E && (0, o.jsx)(eN, {
          onComplete: K
        }), (0, o.jsx)(eP, {}), N ? (0, o.jsxs)("div", {
          className: "flex-1 flex flex-col pointer-events-auto overflow-hidden",
          children: [(0, o.jsxs)("div", {
            className: "flex items-center justify-between px-4 py-2",
            style: {
              borderBottom: "1px solid rgba(0,255,255,0.1)",
              backgroundColor: "rgba(0,0,0,0.3)"
            },
            children: [(0, o.jsx)("button", {
              onClick: J,
              className: "neon-btn py-1.5 px-3 text-xs font-bold tracking-wider font-mono",
              style: {
                borderColor: "#555",
                color: "#888",
                minHeight: 36
              },
              children: "← BACK"
            }), (0, o.jsx)("h2", {
              className: "text-sm font-bold tracking-wider font-mono",
              style: {
                color: s,
                textShadow: "0 0 10px #00ff66"
              },
              children: "🎨 CUSTOMIZATION"
            }), (0, o.jsxs)("div", {
              className: "font-mono text-xs",
              style: {
                color: m,
                textShadow: "0 0 8px #ffd700"
              },
              children: ["🪙 ", r.totalCoins.toLocaleString()]
            })]
          }), (0, o.jsx)("div", {
            className: "flex gap-1 px-4 py-2",
            style: {
              backgroundColor: "rgba(0,0,0,0.2)"
            },
            children: [{
              id: "skins",
              label: "",
              color: n
            }, {
              id: "pets",
              label: "",
              color: s
            }, {
              id: "skills",
              label: "",
              color: c
            }].map(e => (0, o.jsx)("button", {
              onClick: () => z(() => I(e.id)),
              className: "flex-1 py-2 text-[10px] font-bold font-mono tracking-wider rounded",
              style: {
                backgroundColor: R === e.id ? `${e.color}20` : "rgba(0,0,0,0.3)",
                border: `1px solid ${R===e.id?e.color:"#333"}`,
                color: R === e.id ? e.color : "#666",
                textShadow: R === e.id ? `0 0 8px ${e.color}` : "none",
                minHeight: 36
              },
              children: e.label
            }, e.id))
          }), (0, o.jsxs)("div", {
            className: "flex-1 overflow-y-auto px-4 py-2 dark-scroll",
            style: {
              scrollbarWidth: "thin",
              WebkitOverflowScrolling: "touch"
            },
            children: ["skins" === R && (0, o.jsxs)("div", {
              className: "space-y-3",
              children: [(0, o.jsx)("div", {
                className: "text-[10px] font-mono font-bold mb-1",
                style: {
                  color: n,
                  textShadow: "0 0 5px rgba(0,255,255,0.3)"
                },
                children: "CHARACTER SKINS"
              }), (0, o.jsx)("div", {
                className: "grid grid-cols-3 gap-1.5",
                children: C.map(e => {
                  let t = r.unlockedSkins.includes(e.id),
                    a = r.currentSkin === e.id,
                    l = r.totalCoins >= e.price,
                    i = e.price >= 2e3;
                  return (0, o.jsxs)("div", {
                    className: "rounded-lg p-1.5 text-center",
                    style: {
                      backgroundColor: a ? `${e.color}15` : "rgba(0,0,0,0.3)",
                      border: `1px solid ${a?e.color:t?`${e.color}60`:"#333"}`,
                      boxShadow: a ?
                        `0 0 8px ${e.color}30, inset 0 0 8px ${e.color}10` :
                        "none"
                    },
                    children: [(0, o.jsxs)("div", {
                      className: "relative mx-auto mb-0.5 flex justify-center",
                      children: [(0, o.jsx)(eA, {
                        color: e.color,
                        glowColor: e.glowColor,
                        width: 20,
                        height: 32
                      }), (0, o.jsx)("div", {
                        className: "absolute -top-0.5 -right-0.5 text-[5px] font-bold font-mono px-0.5 rounded",
                        style: {
                          backgroundColor: ej[e.rarity],
                          color: "#000"
                        },
                        children: e.rarity.slice(0, 3).toUpperCase()
                      })]
                    }), (0, o.jsx)("div", {
                      className: "font-bold text-[8px] font-mono mb-0.5",
                      style: {
                        color: e.color
                      },
                      children: e.name
                    }), a ? (0, o.jsx)("div", {
                      className: "text-[7px] font-mono font-bold",
                      style: {
                        color: s,
                        textShadow: "0 0 5px rgba(0,255,102,0.4)"
                      },
                      children: "EQUIPPED"
                    }) : t ? (0, o.jsx)("button", {
                      onClick: () => z(() => y(e.id)),
                      className: "text-[7px] font-mono font-bold px-1.5 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: `${e.color}20`,
                        border: `1px solid ${e.color}60`,
                        color: e.color
                      },
                      children: "EQUIP"
                    }) : i ? (0, o.jsx)("button", {
                      onClick: () => l ? z(() => {
                        g(e.id), y(e.id), eo.playCoinCollect()
                      }) : _(() => {
                        z(() => {
                          g(e.id), y(e.id), eo.playCoinCollect()
                        })
                      }),
                      className: "text-[7px] font-mono font-bold px-1 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,255,255,0.1)",
                        border: `1px solid ${l?"#ffd700":n}`,
                        color: l ? "#ffd700" : n
                      },
                      children: l ? `${e.price} 🪙` : "🔒 WATCH AD"
                    }) : (0, o.jsxs)("button", {
                      onClick: () => l && z(() => {
                        g(e.id), y(e.id), eo.playCoinCollect()
                      }),
                      className: "text-[7px] font-mono font-bold px-1 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,0,0,0.3)",
                        border: `1px solid ${l?"#ffd700":"#333"}`,
                        color: l ? "#ffd700" : "#555"
                      },
                      children: [e.price, " 🪙"]
                    })]
                  }, e.id)
                })
              }), (0, o.jsxs)("div", {
                className: "text-[10px] font-mono font-bold mb-1 mt-3",
                style: {
                  color: s,
                  textShadow: "0 0 5px rgba(0,255,102,0.3)"
                },
                children: ["PET SKINS — ", V.name]
              }), (0, o.jsx)("div", {
                className: "grid grid-cols-3 gap-1.5",
                children: w.filter(e => e.petId === r.currentPet).map(e => {
                  let t = r.unlockedPetSkins.includes(e.id),
                    a = r.currentPetSkin === e.id,
                    l = r.totalCoins >= e.price,
                    i = e.price >= 800;
                  return (0, o.jsxs)("div", {
                    className: "rounded-lg p-1.5 text-center",
                    style: {
                      backgroundColor: a ? `${e.color}15` : "rgba(0,0,0,0.3)",
                      border: `1px solid ${a?e.color:t?`${e.color}60`:"#333"}`
                    },
                    children: [(0, o.jsxs)("div", {
                      className: "relative mx-auto mb-0.5 flex justify-center",
                      children: [(0, o.jsx)(eR, {
                        color: e.color,
                        glowColor: e.glowColor,
                        size: 22
                      }), (0, o.jsx)("div", {
                        className: "absolute -top-0.5 -right-0.5 text-[5px] font-bold font-mono px-0.5 rounded",
                        style: {
                          backgroundColor: ej[e.rarity],
                          color: "#000"
                        },
                        children: e.rarity.slice(0, 3).toUpperCase()
                      })]
                    }), (0, o.jsx)("div", {
                      className: "font-bold text-[8px] font-mono mb-0.5",
                      style: {
                        color: e.color
                      },
                      children: e.name
                    }), a ? (0, o.jsx)("div", {
                      className: "text-[7px] font-mono font-bold",
                      style: {
                        color: s
                      },
                      children: "EQUIPPED"
                    }) : t ? (0, o.jsx)("button", {
                      onClick: () => z(() => k(e.id)),
                      className: "text-[7px] font-mono font-bold px-1.5 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: `${e.color}20`,
                        border: `1px solid ${e.color}60`,
                        color: e.color
                      },
                      children: "EQUIP"
                    }) : i ? (0, o.jsx)("button", {
                      onClick: () => l ? z(() => {
                        b(e.id), k(e.id), eo.playCoinCollect()
                      }) : _(() => {
                        z(() => {
                          b(e.id), k(e.id), eo.playCoinCollect()
                        })
                      }),
                      className: "text-[7px] font-mono font-bold px-1 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,255,255,0.1)",
                        border: `1px solid ${l?"#ffd700":n}`,
                        color: l ? "#ffd700" : n
                      },
                      children: l ? `${e.price} 🪙` : "🔒 WATCH AD"
                    }) : (0, o.jsxs)("button", {
                      onClick: () => l && z(() => {
                        b(e.id), k(e.id), eo.playCoinCollect()
                      }),
                      className: "text-[7px] font-mono font-bold px-1 py-0.5 rounded min-h-[22px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,0,0,0.3)",
                        border: `1px solid ${l?"#ffd700":"#333"}`,
                        color: l ? "#ffd700" : "#555"
                      },
                      children: [e.price, " 🪙"]
                    })]
                  }, e.id)
                })
              })]
            }), "pets" === R && (0, o.jsx)("div", {
              className: "space-y-1.5",
              children: v.map(e => {
                let t = r.unlockedPets.includes(e.id),
                  a = r.currentPet === e.id,
                  l = r.totalCoins >= e.price,
                  i = e.price >= 1500;
                return (0, o.jsxs)("div", {
                  className: "flex items-center gap-2 p-2 rounded-lg",
                  style: {
                    backgroundColor: a ? `${e.color}15` : t ? `${e.color}08` :
                      "rgba(0,0,0,0.2)",
                    border: `1px solid ${a?e.color:t?`${e.color}40`:"#33333340"}`,
                    boxShadow: a ? `0 0 8px ${e.color}20` : "none"
                  },
                  children: [(0, o.jsx)("div", {
                    className: "flex-shrink-0",
                    children: (0, o.jsx)(eR, {
                      color: e.color,
                      glowColor: e.glowColor,
                      size: 32
                    })
                  }), (0, o.jsxs)("div", {
                    className: "flex-1 min-w-0",
                    children: [(0, o.jsx)("div", {
                      className: "font-bold text-[9px] font-mono",
                      style: {
                        color: t ? e.color : "#555"
                      },
                      children: e.name
                    }), (0, o.jsx)("div", {
                      className: "text-[8px] font-mono truncate",
                      style: {
                        color: t ? "#888" : "#444"
                      },
                      children: e.description
                    }), (0, o.jsxs)("div", {
                      className: "text-[7px] font-mono mt-0.5",
                      style: {
                        color: "#666"
                      },
                      children: ["DMG:", e.damage, " | SPD:", e
                        .shootRate > 0 ? (60 / e.shootRate).toFixed(1) :
                        "0", "/s"
                      ]
                    })]
                  }), (0, o.jsx)("div", {
                    className: "flex-shrink-0 min-w-[60px] text-right",
                    children: a ? (0, o.jsx)("span", {
                      className: "text-[8px] font-mono font-bold px-2 py-1 rounded inline-block",
                      style: {
                        color: s,
                        backgroundColor: "rgba(0,255,102,0.1)",
                        border: "1px solid rgba(0,255,102,0.3)"
                      },
                      children: "ACTIVE"
                    }) : t ? (0, o.jsx)("button", {
                      onClick: () => z(() => x(e.id)),
                      className: "text-[8px] font-mono font-bold px-2 py-1 rounded min-h-[28px]",
                      style: {
                        backgroundColor: `${e.color}20`,
                        border: `1px solid ${e.color}60`,
                        color: e.color
                      },
                      children: "SELECT"
                    }) : i ? (0, o.jsx)("button", {
                      onClick: () => l ? z(() => {
                        p(e.id), eo.playCoinCollect()
                      }) : _(() => {
                        z(() => {
                          p(e.id), eo.playCoinCollect()
                        })
                      }),
                      className: "text-[8px] font-mono font-bold px-1.5 py-1 rounded min-h-[28px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,255,255,0.1)",
                        border: `1px solid ${l?"#ffd700":n}`,
                        color: l ? "#ffd700" : n
                      },
                      children: l ? `${e.price} 🪙` : "🔒 WATCH AD"
                    }) : (0, o.jsxs)("button", {
                      onClick: () => l && z(() => {
                        p(e.id), eo.playCoinCollect()
                      }),
                      className: "text-[8px] font-mono font-bold px-1.5 py-1 rounded min-h-[28px]",
                      style: {
                        backgroundColor: l ? "rgba(255,215,0,0.15)" :
                          "rgba(0,0,0,0.3)",
                        border: `1px solid ${l?"#ffd700":"#333"}`,
                        color: l ? "#ffd700" : "#555"
                      },
                      children: [e.price, " 🪙"]
                    })
                  })]
                }, e.id)
              })
            }), "skills" === R && (e = "all" === B ? P : P.filter(e => e.element === B), t = r
              .equippedSkills, (0, o.jsxs)("div", {
                className: "space-y-2",
                children: [(0, o.jsxs)("div", {
                  className: "p-2 rounded-lg",
                  style: {
                    backgroundColor: "rgba(255,102,0,0.06)",
                    border: "1px solid #ff660020"
                  },
                  children: [(0, o.jsx)("div", {
                    className: "text-[8px] font-mono font-bold mb-1.5",
                    style: {
                      color: c,
                      textShadow: "0 0 5px rgba(255,102,0,0.3)"
                    },
                    children: "EQUIPPED SKILLS"
                  }), (0, o.jsx)("div", {
                    className: "flex gap-1.5",
                    children: [0, 1, 2].map(e => {
                      let a = t[e],
                        l = a ? P.find(e => e.id === a) : null,
                        n = a ? r.skillUpgrades[a] || 1 : 0;
                      return (0, o.jsx)("div", {
                        className: "flex-1 p-1.5 rounded text-center cursor-pointer min-h-[48px] flex flex-col items-center justify-center",
                        style: {
                          backgroundColor: l ? `${l.color}15` :
                            "rgba(0,0,0,0.3)",
                          border: `1px solid ${l?l.color+"60":"#33333340"}`
                        },
                        onClick: () => z(() => M(e)),
                        role: "button",
                        "aria-label": l ?
                          `Unequip ${l.name} from slot ${e+1}` :
                          `Empty skill slot ${e+1}`,
                        children: l ? (0, o.jsxs)(o.Fragment, {
                          children: [(0, o.jsx)("div", {
                            className: "text-[8px] font-mono font-bold",
                            style: {
                              color: l.color
                            },
                            children: l.name
                          }), (0, o.jsxs)("div", {
                            className: "text-[7px] font-mono",
                            style: {
                              color: "#666"
                            },
                            children: ["CD:", (l.cooldown / 60)
                              .toFixed(1), "s Lv.", n
                            ]
                          }), (0, o.jsx)("div", {
                            className: "w-full h-1 rounded-full mt-0.5",
                            style: {
                              backgroundColor: "#222"
                            },
                            children: (0, o.jsx)("div", {
                              className: "h-full rounded-full",
                              style: {
                                width: `${Math.min(100,l.cooldown/600*100)}%`,
                                backgroundColor: l.color,
                                opacity: .6
                              }
                            })
                          })]
                        }) : (0, o.jsx)("div", {
                          className: "text-[8px] font-mono",
                          style: {
                            color: "#555"
                          },
                          children: ["⚡", "🛡", "✨"][e]
                        })
                      }, e)
                    })
                  })]
                }), (0, o.jsxs)("div", {
                  className: "flex gap-0.5 flex-wrap",
                  children: [(0, o.jsx)("button", {
                    onClick: () => z(() => G("all")),
                    className: "px-1.5 py-0.5 rounded text-[7px] font-mono font-bold min-h-[22px]",
                    style: {
                      backgroundColor: "all" === B ? "rgba(255,255,255,0.12)" :
                        "rgba(0,0,0,0.3)",
                      border: `1px solid ${"all"===B?"#ffffff50":"#333"}`,
                      color: "all" === B ? "#fff" : "#666"
                    },
                    children: "ALL"
                  }), ["fire", "frost", "shadow", "summon", "death", "lightning",
                    "void", "blood"
                  ].map(e => (0, o.jsx)("button", {
                    onClick: () => z(() => G(e)),
                    className: "px-1.5 py-0.5 rounded text-[7px] font-mono font-bold min-h-[22px]",
                    style: {
                      backgroundColor: B === e ? `${eS[e]}25` :
                        "rgba(0,0,0,0.3)",
                      border: `1px solid ${B===e?eS[e]+"60":"#333"}`,
                      color: B === e ? eS[e] : "#666"
                    },
                    children: eT[e]
                  }, e))]
                }), (0, o.jsx)("div", {
                  className: "flex flex-col gap-1.5 max-h-[50vh] overflow-y-auto",
                  style: {
                    scrollbarWidth: "none"
                  },
                  children: e.map(e => {
                    let a = r.unlockedSkills.includes(e.id),
                      l = t.includes(e.id),
                      i = r.totalCoins >= e.unlockCost,
                      c = "ad" === e.unlockMethod,
                      d = r.skillUpgrades[e.id] || 1;
                    return (0, o.jsxs)("div", {
                      className: "p-1.5 rounded-lg flex gap-1.5 items-center",
                      style: {
                        backgroundColor: a ? `${e.color}08` : "rgba(0,0,0,0.2)",
                        border: `1px solid ${l?e.color:a?e.color+"40":"#33333330"}`,
                        boxShadow: l ? `0 0 6px ${e.color}15` : "none"
                      },
                      children: [(0, o.jsx)("div", {
                        className: "w-8 h-8 rounded flex items-center justify-center flex-shrink-0",
                        style: {
                          backgroundColor: `${e.color}15`,
                          border: `1px solid ${e.color}40`
                        },
                        children: (0, o.jsx)("div", {
                          className: "w-3.5 h-3.5 rounded-full",
                          style: {
                            backgroundColor: e.color,
                            boxShadow: `0 0 8px ${e.glowColor}`
                          }
                        })
                      }), (0, o.jsxs)("div", {
                        className: "flex-1 min-w-0",
                        children: [(0, o.jsxs)("div", {
                          className: "flex items-center gap-1",
                          children: [(0, o.jsx)("span", {
                            className: "font-bold text-[8px] font-mono",
                            style: {
                              color: a ? e.color : "#555"
                            },
                            children: e.name
                          }), (0, o.jsx)("span", {
                            className: "text-[6px] font-mono px-0.5 rounded",
                            style: {
                              backgroundColor: `${eM[e.rarity]}20`,
                              color: eM[e.rarity]
                            },
                            children: e.rarity.slice(0, 3)
                              .toUpperCase()
                          }), (0, o.jsx)("span", {
                            className: "text-[6px] font-mono px-0.5 rounded",
                            style: {
                              backgroundColor: `${eS[e.element]}15`,
                              color: eS[e.element]
                            },
                            children: eT[e.element]
                          }), a && d > 1 && (0, o.jsxs)(
                          "span", {
                            className: "text-[6px] font-mono font-bold",
                            style: {
                              color: m
                            },
                            children: ["★", d]
                          })]
                        }), (0, o.jsx)("div", {
                          className: "text-[7px] font-mono truncate",
                          style: {
                            color: a ? "#777" : "#444"
                          },
                          children: e.description
                        }), (0, o.jsxs)("div", {
                          className: "flex items-center gap-1 mt-0.5",
                          children: [(0, o.jsx)("div", {
                            className: "flex-1 h-1 rounded-full",
                            style: {
                              backgroundColor: "#222"
                            },
                            children: (0, o.jsx)("div", {
                              className: "h-full rounded-full",
                              style: {
                                width: `${Math.min(100,e.cooldown/600*100)}%`,
                                backgroundColor: e.color,
                                opacity: .6
                              }
                            })
                          }), (0, o.jsxs)("span", {
                            className: "text-[6px] font-mono flex-shrink-0",
                            style: {
                              color: "#666"
                            },
                            children: [(e.cooldown / 60)
                              .toFixed(1), "s"
                            ]
                          })]
                        })]
                      }), (0, o.jsx)("div", {
                        className: "flex-shrink-0",
                        children: a ? l ? (0, o.jsx)("span", {
                            className: "text-[8px] font-mono font-bold px-2 py-1 rounded inline-block",
                            style: {
                              color: s,
                              backgroundColor: "rgba(0,255,102,0.1)",
                              border: "1px solid rgba(0,255,102,0.3)"
                            },
                            children: "EQUIPPED"
                          }) : (0, o.jsx)("div", {
                            className: "flex gap-0.5",
                            children: [0, 1, 2].map(t => (0, o.jsx)(
                              "button", {
                                onClick: () => z(() => T(e.id, t)),
                                className: "text-[7px] font-mono font-bold px-1.5 py-0.5 rounded min-h-[24px]",
                                style: {
                                  backgroundColor: `${e.color}20`,
                                  border: `1px solid ${e.color}50`,
                                  color: e.color
                                },
                                children: ["1", "2", "3"][t]
                              }, t))
                          }) : c ? (0, o.jsx)("button", {
                            onClick: () => i ? z(() => {
                              S(e.id), eo.playCoinCollect()
                            }) : _(() => {
                              z(() => {
                                S(e.id), eo.playCoinCollect()
                              })
                            }),
                            className: "text-[7px] font-mono font-bold px-1.5 py-1 rounded min-h-[24px]",
                            style: {
                              backgroundColor: i ?
                                "rgba(255,215,0,0.15)" :
                                "rgba(0,255,255,0.1)",
                              border: `1px solid ${i?"#ffd700":n}`,
                              color: i ? "#ffd700" : n
                            },
                            children: i ? `${e.unlockCost} 🪙` :
                              "🔒 WATCH AD"
                          }) : "purchase" === e.unlockMethod ||
                          "chest" === e.unlockMethod ? (0, o.jsxs)(
                            "button", {
                              onClick: () => i && z(() => {
                                S(e.id), eo.playCoinCollect()
                              }),
                              className: "text-[7px] font-mono font-bold px-1.5 py-1 rounded min-h-[24px]",
                              style: {
                                backgroundColor: i ?
                                  "rgba(255,215,0,0.15)" :
                                  "rgba(0,0,0,0.3)",
                                border: `1px solid ${i?"#ffd700":"#333"}`,
                                color: i ? "#ffd700" : "#555"
                              },
                              children: [e.unlockCost, " 🪙"]
                            }) : (0, o.jsx)("span", {
                            className: "text-[6px] font-mono",
                            style: {
                              color: "#555"
                            },
                            children: function(e) {
                              switch (e.unlockMethod) {
                                case "level":
                                  return `Reach Lv.${e.unlockLevel}`;
                                case "boss":
                                  return `Defeat ${e.unlockBoss||"Boss"}`;
                                case "chest":
                                  return e.unlockCost > 0 ?
                                    `${e.unlockCost} Coins` :
                                    "Find in Chest";
                                case "purchase":
                                  return `${e.unlockCost} Coins`;
                                case "ad":
                                  return `🎬 Watch Ad — ${e.unlockCost} Coins`;
                                case "story":
                                  return "Story Unlock";
                                default:
                                  return "???"
                              }
                            }(e)
                          })
                      })]
                    }, e.id)
                  })
                })]
              }))]
          }), (0, o.jsx)("div", {
            className: "text-center py-1.5 text-[7px] font-mono",
            style: {
              color: "rgba(255,255,255,0.2)",
              borderTop: "1px solid rgba(255,255,255,0.05)"
            },
            children: "Watch ads to earn coins • Complete levels to unlock more"
          })]
        }) : (0, o.jsxs)("div", {
          className: "flex-1 flex pointer-events-auto",
          children: [(0, o.jsxs)("div", {
            className: "flex-1 flex flex-col items-center justify-center p-4 gap-2",
            children: [(0, o.jsxs)("div", {
              className: "flex items-center gap-3 mb-1",
              children: [(0, o.jsx)("div", {
                className: "hidden sm:block",
                children: (0, o.jsx)(eA, {
                  color: U.color,
                  glowColor: U.glowColor,
                  width: 44,
                  height: 70
                })
              }), (0, o.jsxs)("div", {
                children: [(0, o.jsx)("h1", {
                  className: "text-2xl sm:text-3xl md:text-4xl font-bold tracking-wider leading-tight font-mono",
                  style: {
                    color: n,
                    textShadow: "0 0 15px #00ffff, 0 0 30px #00ffff, 0 0 60px rgba(0,255,255,0.3)",
                    animation: "neon-pulse 3s ease-in-out infinite"
                  },
                  children: "NEON STICKMAN"
                }), (0, o.jsx)("p", {
                  className: "text-sm sm:text-lg md:text-xl tracking-widest leading-tight font-mono",
                  style: {
                    color: i,
                    textShadow: "0 0 10px #ff00ff, 0 0 25px #ff00ff, 0 0 50px rgba(255,0,255,0.3)",
                    animation: "neon-pulse 3s ease-in-out infinite 0.5s"
                  },
                  children: "STICK WAR"
                })]
              })]
            }), (0, o.jsx)("div", {
              className: "sm:hidden",
              children: (0, o.jsx)(eA, {
                color: U.color,
                glowColor: U.glowColor,
                width: 32,
                height: 50
              })
            }), (0, o.jsxs)("div", {
              className: "flex items-center justify-center gap-3 font-mono text-xs px-3 py-1.5 rounded-lg",
              style: {
                backgroundColor: "rgba(0,0,0,0.4)",
                border: "1px solid rgba(255,215,0,0.15)"
              },
              children: [(0, o.jsxs)("span", {
                style: {
                  color: m,
                  textShadow: "0 0 8px #ffd700"
                },
                children: ["🪙 ", r.totalCoins.toLocaleString()]
              }), (0, o.jsx)("span", {
                style: {
                  color: "#444"
                },
                children: "│"
              }), (0, o.jsxs)("span", {
                style: {
                  color: c,
                  textShadow: "0 0 5px #ff6600"
                },
                children: [H.icon, " ", H.rank]
              }), (0, o.jsx)("span", {
                style: {
                  color: "#444"
                },
                children: "│"
              }), (0, o.jsxs)("span", {
                style: {
                  color: "rgba(255,255,255,0.5)"
                },
                children: ["LV ", r.highestLevel, "/", 100]
              })]
            }), (0, o.jsx)("div", {
              className: "w-full max-w-[260px]",
              children: (0, o.jsx)("div", {
                className: "h-1.5 rounded-full",
                style: {
                  backgroundColor: "rgba(0,0,0,0.4)",
                  border: "1px solid #222"
                },
                children: (0, o.jsx)("div", {
                  className: "h-full rounded-full transition-all duration-500",
                  style: {
                    width: `${Math.min(100,r.highestLevel)}%`,
                    backgroundColor: n,
                    boxShadow: "0 0 6px #00ffff"
                  }
                })
              })
            }), (0, o.jsx)("button", {
              onClick: () => z(() => {
                ev(), u("single"), l()
              }),
              className: "neon-btn w-full max-w-[280px] py-3 px-6 text-lg font-bold tracking-wider font-mono",
              style: {
                borderColor: r.highestLevel > 0 ? s : n,
                color: r.highestLevel > 0 ? s : n,
                textShadow: r.highestLevel > 0 ? "0 0 15px #00ff66, 0 0 30px #00ff66" :
                  "0 0 15px #00ffff, 0 0 30px #00ffff",
                animation: "continue-pulse 2s ease-in-out infinite",
                minHeight: 56
              },
              children: r.highestLevel > 0 ? "▶ CONTINUE" : "⚔️ PLAY"
            }), (0, o.jsx)("button", {
              onClick: () => z(q),
              className: "neon-btn w-full max-w-[280px] py-2 px-4 text-sm font-bold tracking-wider font-mono",
              style: {
                borderColor: m,
                color: m,
                textShadow: "0 0 8px #ffd700",
                backgroundImage: "linear-gradient(90deg, transparent, rgba(255,215,0,0.06), transparent)",
                backgroundSize: "200% 100%",
                animation: "ad-shimmer 3s linear infinite",
                minHeight: 44
              },
              children: "🎬 WATCH AD +200 🪙"
            })]
          }), (0, o.jsx)("div", {
            className: "flex-1 flex items-center justify-center p-4",
            children: (0, o.jsxs)("div", {
              className: "w-full max-w-[320px] rounded-xl p-3",
              style: {
                border: "1px solid rgba(0,255,255,0.15)",
                animation: "neon-border-glow 4s ease-in-out infinite",
                backgroundColor: "rgba(0,0,0,0.3)"
              },
              children: [(0, o.jsx)("div", {
                className: "grid grid-cols-2 gap-2",
                children: Z.map(e => (0, o.jsxs)("button", {
                  onClick: () => z(e.action),
                  className: "neon-btn py-2.5 px-3 text-xs font-bold tracking-wider font-mono flex items-center justify-center gap-1.5",
                  style: {
                    borderColor: e.color,
                    color: e.color,
                    textShadow: `0 0 8px ${e.color}`,
                    minHeight: 48
                  },
                  children: [(0, o.jsx)("span", {
                    className: "text-base",
                    children: e.icon
                  }), (0, o.jsx)("span", {
                    children: e.label
                  })]
                }, e.label))
              }), (0, o.jsxs)("div", {
                className: "mt-2 text-center text-[8px] font-mono",
                style: {
                  color: "rgba(255,255,255,0.25)"
                },
                children: [H.icon, " ELO ", r.rankingData.elo, " • ", r.rankingData.wins,
                  "W/", r.rankingData.losses, "L"
                ]
              })]
            })
          })]
        })]
      })
    }

    function eE(e, t, o, a, l, r, n, i, s = 1, c = "neutral", d = !1, h = !1, f = 0, u = "") {
      let m = Math.abs(f) > 6,
        x = Math.min(Math.abs(f) / 10, 1.5),
        p = m ? .45 : .3;
      if (h) {
        e.save(), e.translate(t, o), e.globalAlpha = .3 + .2 * Math.sin(.1 * r), e.shadowBlur = 20, e.shadowColor =
          l, e.strokeStyle = l, e.lineWidth = 2 * s;
        let a = .5 * r;
        e.beginPath(), e.arc(Math.sin(.3 * r) * a, -38 * s + Math.cos(.2 * r) * a, 8 * s, 0, 2 * Math.PI), e
        .stroke(), e.beginPath(), e.moveTo(Math.sin(.4 * r) * a * .5, -30 * s), e.lineTo(Math.cos(.3 * r) * a *
          .5, -10 * s), e.stroke(), e.restore();
        return
      }
      e.save(), e.translate(t, o), e.shadowBlur = 15, e.shadowColor = l;
      let g = d && i ? 3 * Math.abs(Math.sin(r * p)) * s * x : Math.sin(.06 * r) * s;
      e.beginPath(), e.arc(0, -38 * s - g, 9 * s, 0, 2 * Math.PI), e.strokeStyle = l, e.lineWidth = 2.5 * s, e
        .globalAlpha = 1, e.stroke(),
        function(e, t, o, a, l) {
          switch (e.shadowBlur = 8, e.shadowColor = a, e.lineWidth = 1.5 * o, l) {
            case "angry":
              e.strokeStyle = a, e.beginPath(), e.moveTo(-5 * t * o, -43 * o), e.lineTo(t * o, -41 * o), e.stroke(),
                e.beginPath(), e.moveTo(5 * t * o, -43 * o), e.lineTo(t * o, -41 * o), e.stroke(), e.fillStyle =
                "#ffffff", e.beginPath(), e.arc(3 * t * o, -39 * o, 2 * o, 0, 2 * Math.PI), e.fill(), e.fillStyle =
                a, e.beginPath(), e.arc(3 * t * o, -39 * o, 1.2 * o, 0, 2 * Math.PI), e.fill();
              break;
            case "smirk":
              e.strokeStyle = a, e.beginPath(), e.moveTo(-5 * t * o, -42 * o), e.lineTo(t * o, -43 * o), e.stroke(),
                e.fillStyle = "#ffffff", e.beginPath(), e.arc(3 * t * o, -39 * o, 2 * o, 0, 2 * Math.PI), e.fill(),
                e.fillStyle = a, e.beginPath(), e.arc(3.5 * t * o, -39 * o, +o, 0, 2 * Math.PI), e.fill(), e
                .strokeStyle = a, e.beginPath(), e.moveTo(-2 * t * o, -35 * o), e.lineTo(4 * t * o, -35.5 * o), e
                .lineTo(5 * t * o, -36.5 * o), e.stroke();
              break;
            case "determined":
              e.strokeStyle = a, e.beginPath(), e.moveTo(-4 * t * o, -42 * o), e.lineTo(5 * t * o, -42 * o), e
                .stroke(), e.fillStyle = "#ffffff", e.beginPath(), e.arc(3 * t * o, -39 * o, 2 * o, 0, 2 * Math.PI),
                e.fill(), e.fillStyle = a, e.beginPath(), e.arc(3 * t * o, -39 * o, 1.2 * o, 0, 2 * Math.PI), e
                .fill(), e.strokeStyle = a, e.lineWidth = 1.5 * o, e.beginPath(), e.moveTo(-2 * t * o, -35 * o), e
                .lineTo(3 * t * o, -35 * o), e.stroke();
              break;
            case "hurt": {
              e.strokeStyle = a;
              let l = 3 * t * o,
                r = -39 * o;
              e.beginPath(), e.moveTo(l - 2 * o, r - 2 * o), e.lineTo(l + 2 * o, r + 2 * o), e.stroke(), e
                .beginPath(), e.moveTo(l + 2 * o, r - 2 * o), e.lineTo(l - 2 * o, r + 2 * o), e.stroke(), e
                .beginPath(), e.moveTo(-2 * t * o, -35 * o), e.lineTo(0 * t * o, -34 * o), e.lineTo(3 * t * o, -
                  35.5 * o), e.stroke();
              break
            }
            case "victory":
              e.fillStyle = "#ffffff", e.beginPath(), e.arc(t * o, -39 * o, 2 * o, 0, 2 * Math.PI), e.fill(), e
                .beginPath(), e.arc(5 * t * o, -39 * o, 2 * o, 0, 2 * Math.PI), e.fill(), e.strokeStyle = a, e
                .lineWidth = 1.5 * o, e.beginPath(), e.arc(3 * t * o, -37 * o, 5 * o, .1, Math.PI - .1), e.stroke();
              break;
            default:
              e.fillStyle = a, e.globalAlpha = .8, e.beginPath(), e.arc(3 * t * o, -39.5 * o, 2 * o, 0, 2 * Math
                .PI), e.fill(), e.globalAlpha = .5, e.strokeStyle = a, e.lineWidth = +o, e.beginPath(), e.moveTo(0 *
                  t * o, -35 * o), e.lineTo(3 * t * o, -35.2 * o), e.stroke()
          }
          e.globalAlpha = 1
        }(e, a, s, l, c);
      let y = d ? a * (m ? 5 * s : 2 * s) * Math.min(x + .5, 1.2) : 0;
      e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(y, -29 * s - .5 * g), e.lineTo(0, -10 * s), e
        .stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(y, -29 * s - .5 * g), e.lineTo(
          0, -10 * s), e.stroke(), e.globalAlpha = .4 + .2 * Math.sin(.08 * r), e.fillStyle = l, e.shadowBlur = 12,
        e.beginPath(), e.arc(.5 * y, -22 * s - .3 * g, 3 * s, 0, 2 * Math.PI), e.fill(), e.globalAlpha = 1;
      let b = -25 * s - .5 * g;
      if (n) {
        let t = 3 * Math.sin(.8 * r) * s;
        e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(y - .3 * t, b), e.lineTo(-(15 * s * a), b +
            5 * s), e.stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(y - .3 * t, b), e
          .lineTo(-(15 * s * a), b + 5 * s), e.stroke(), e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e
          .moveTo(y - .3 * t, b), e.lineTo(25 * s * a - t * a * .5, b - 3 * s), e.stroke(), e.globalAlpha = 1, e
          .lineWidth = 2.5 * s, e.beginPath(), e.moveTo(y - .3 * t, b), e.lineTo(25 * s * a - t * a * .5, b - 3 *
          s), e.stroke(), e.globalAlpha = .9, e.fillStyle = "#ffffff", e.shadowColor = "#ffffff", e.shadowBlur = 30,
          e.beginPath(), e.arc(28 * a * s, b - 3 * s, 5 * s, 0, 2 * Math.PI), e.fill(), e.globalAlpha = .5, e
          .fillStyle = l, e.shadowColor = l, e.shadowBlur = 25, e.beginPath(), e.arc(28 * a * s, b - 3 * s, 9 * s,
            0, 2 * Math.PI), e.fill(), e.globalAlpha = .7, e.fillStyle = "#ffffff";
        for (let t = 0; t < 4; t++) {
          let t = (a > 0 ? 0 : Math.PI) + (Math.random() - .5) * 1.2,
            o = 10 + 10 * Math.random();
          e.beginPath(), e.arc(28 * a * s + Math.cos(t) * o * s, b - 3 * s + Math.sin(t) * o * s, (1 + 1.5 * Math
            .random()) * s, 0, 2 * Math.PI), e.fill()
        }
        e.globalAlpha = 1
      } else {
        let t = m ? 22 * s : d ? 16 * s : 3 * s,
          o = i ? Math.sin(r * p) * t * x : -8 * s,
          l = m ? 15 * s : 12 * s;
        e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(y, b), e.lineTo(-a * l, b + o), e.stroke(),
          e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(y, b), e.lineTo(-a * l, b + o), e
          .stroke(), !d && i ? (e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(y, b), e.lineTo(8 *
              s * a, b + 12 * s + 2 * Math.sin(.05 * r) * s), e.stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s,
            e.beginPath(), e.moveTo(y, b), e.lineTo(8 * s * a, b + 12 * s + 2 * Math.sin(.05 * r) * s)) : (e
            .globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(y, b), e.lineTo(a * l, b - o), e
            .stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(y, b), e.lineTo(a * l, b -
              o)), e.stroke()
      }
      if (i)
        if (d) {
          let t = Math.sin(r * p) * (m ? 20 * s : 14 * s) * Math.max(x, .6),
            o = m ? 12 * s : 8 * s;
          e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(-(.5 * o) + .3 * t,
              -10 * s + 12 * s), e.lineTo(-o + .5 * t, -10 * s + 22 * s + .6 * t), e.stroke(), e.beginPath(), e
            .moveTo(0, -10 * s), e.lineTo(.5 * o - .3 * t, -10 * s + 12 * s), e.lineTo(o - .5 * t, -10 * s + 22 *
              s - .6 * t), e.stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(0, -10 *
            s), e.lineTo(-(.5 * o) + .3 * t, -10 * s + 12 * s), e.lineTo(-o + .5 * t, -10 * s + 22 * s + .6 * t), e
            .stroke(), e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(.5 * o - .3 * t, -10 * s + 12 * s), e.lineTo(
              o - .5 * t, -10 * s + 22 * s - .6 * t), e.stroke()
        } else {
          let t = 1.5 * Math.sin(.06 * r) * s;
          e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(-9 * s, -10 * s +
              20 * s + t), e.stroke(), e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(9 * s, -10 * s + 20 * s + t), e
            .stroke(), e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(-9 *
              s, -10 * s + 20 * s + t), e.stroke(), e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(9 * s, -10 * s +
              20 * s + t), e.stroke()
        }
      else e.globalAlpha = .3, e.lineWidth = 5 * s, e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(-10 * s, -10 * s +
          14 * s), e.stroke(), e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(10 * s, -10 * s + 14 * s), e.stroke(),
        e.globalAlpha = 1, e.lineWidth = 2.5 * s, e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(-10 * s, -10 * s +
          14 * s), e.stroke(), e.beginPath(), e.moveTo(0, -10 * s), e.lineTo(10 * s, -10 * s + 14 * s), e.stroke();
      if (d && i) {
        let t = m ? 5 : 3,
          o = m ? 10 * s : 8 * s;
        e.strokeStyle = l, e.lineWidth = m ? 2 * s : 1.5 * s;
        for (let l = 1; l <= t; l++) {
          let t = -a * l * o;
          e.globalAlpha = Math.max(.15 - .03 * l, .02), e.beginPath(), e.moveTo(t, -38 * s - g), e.lineTo(t + y, -
            29 * s - .5 * g), e.lineTo(t, -10 * s), e.stroke()
        }
        if (m) {
          e.lineWidth = +s;
          for (let t = 0; t < 3; t++) {
            let o = -32 * s + 10 * t * s,
              l = (8 + 12 * Math.random()) * s;
            e.globalAlpha = .1 + .1 * Math.random(), e.beginPath(), e.moveTo(-a * (15 + 5 * t) * s, o), e.lineTo(-
              a * (15 + 5 * t + l / s) * s, o), e.stroke()
          }
        }
      }
      if (e.shadowBlur = 0, e.globalAlpha = 1, u && !h) {
        switch (e.save(), u) {
          case "rainbow": {
            let t = 3 * r % 360,
              o = `hsl(${t}, 100%, 60%)`;
            e.globalAlpha = .15 + .08 * Math.sin(.08 * r), e.shadowBlur = 25, e.shadowColor = o, e.fillStyle = o, e
              .beginPath(), e.arc(0, -20 * s, 35 * s, 0, 2 * Math.PI), e.fill(), e.globalAlpha = .6;
            for (let o = 0; o < 5; o++) {
              let a = o / 5 * Math.PI * 2 + .05 * r,
                l = 30 * s + 8 * Math.sin(.06 * r + o) * s,
                n = (t + 72 * o) % 360;
              e.fillStyle = `hsl(${n}, 100%, 70%)`, e.beginPath(), e.arc(Math.cos(a) * l, -20 * s + Math.sin(a) *
                l * .5, 1.5 * s, 0, 2 * Math.PI), e.fill()
            }
            break
          }
          case "sparkle":
            if (r % 8 < 2) {
              e.globalAlpha = .4, e.fillStyle = "#ffffff", e.shadowBlur = 20, e.shadowColor = "#ffffff";
              let t = 15 * Math.sin(.7 * r) * s,
                o = (-20 + 15 * Math.cos(.5 * r)) * s;
              e.beginPath(), e.arc(t, o, 3 * s, 0, 2 * Math.PI), e.fill()
            }
            e.globalAlpha = .08 + .05 * Math.sin(.1 * r), e.fillStyle = "#ffffff", e.shadowBlur = 15, e
              .shadowColor = "#88ffff", e.beginPath(), e.arc(0, -20 * s, 30 * s, 0, 2 * Math.PI), e.fill();
            break;
          case "shadow":
            e.globalAlpha = .3, e.strokeStyle = "#333344", e.lineWidth = 2 * s;
            for (let t = 1; t <= 3; t++) e.globalAlpha = Math.max(.2 - .06 * t, .02), e.beginPath(), e.arc(-a * t *
              10 * s, -38 * s, 8 * s, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e.moveTo(-a * t * 10 * s, -29 *
              s), e.lineTo(-a * t * 10 * s, -10 * s), e.stroke();
            e.globalAlpha = .1 + .05 * Math.sin(.07 * r), e.fillStyle = "#222233", e.shadowBlur = 20, e
              .shadowColor = "#444466", e.beginPath(), e.arc(0, -20 * s, 25 * s, 0, 2 * Math.PI), e.fill();
            break;
          case "plasma":
            e.globalAlpha = .2 + .1 * Math.sin(.12 * r), e.fillStyle = "#ff44ff", e.shadowBlur = 20, e.shadowColor =
              "#ff88ff", e.beginPath(), e.arc(0, -20 * s, 28 * s + 5 * Math.sin(.1 * r) * s, 0, 2 * Math.PI), e
              .fill(), e.strokeStyle = "#ff88ff", e.lineWidth = 1.5 * s, e.globalAlpha = .5;
            for (let t = 0; t < 3; t++) {
              let o = .1 * r + 2 * t;
              e.beginPath(), e.moveTo(10 * Math.cos(o) * s, -20 * s + 10 * Math.sin(o) * s), e.lineTo(25 * Math.cos(
                o + .5) * s, -20 * s + 25 * Math.sin(o + .5) * s), e.stroke()
            }
            break;
          case "holy":
            e.globalAlpha = .15 + .08 * Math.sin(.06 * r), e.fillStyle = "#ffdd44", e.shadowBlur = 30, e
              .shadowColor = "#ffdd44", e.beginPath(), e.arc(0, -20 * s, 35 * s, 0, 2 * Math.PI), e.fill(), e
              .globalAlpha = .1, e.strokeStyle = "#ffdd44", e.lineWidth = 1.5 * s;
            for (let t = 0; t < 6; t++) {
              let o = t / 6 * Math.PI * 2 + .01 * r;
              e.beginPath(), e.moveTo(20 * Math.cos(o) * s, -20 * s + 20 * Math.sin(o) * s), e.lineTo(45 * Math.cos(
                o) * s, -20 * s + 45 * Math.sin(o) * s), e.stroke()
            }
            e.globalAlpha = .3, e.strokeStyle = "#ffdd44", e.lineWidth = 1.5 * s, e.beginPath(), e.ellipse(0, -50 *
              s, 10 * s, 3 * s, 0, 0, 2 * Math.PI), e.stroke();
            break;
          case "abyss":
            e.globalAlpha = .15 + .08 * Math.sin(.08 * r), e.fillStyle = "#220044", e.shadowBlur = 25, e
              .shadowColor = "#440088", e.beginPath(), e.arc(0, -20 * s, 32 * s, 0, 2 * Math.PI), e.fill(), e
              .globalAlpha = .3, e.strokeStyle = "#6600aa", e.lineWidth = 1.5 * s;
            for (let t = 0; t < 4; t++) {
              let o = t / 4 * Math.PI * 2 + .03 * r;
              e.beginPath(), e.moveTo(12 * Math.cos(o) * s, -20 * s + 12 * Math.sin(o) * s);
              let a = 22 * Math.cos(o + .3) * s,
                l = -20 * s + 22 * Math.sin(o + .3) * s,
                n = 30 * Math.cos(o + .5) * s,
                i = -20 * s + 30 * Math.sin(o + .5) * s;
              e.quadraticCurveTo(a, l, n, i), e.stroke()
            }
            break;
          case "glitch": {
            e.globalAlpha = .15, e.strokeStyle = "#ff0000", e.lineWidth = 2 * s;
            let t = 3 * Math.sin(.5 * r) * s;
            e.beginPath(), e.arc(t, -38 * s, 9 * s, 0, 2 * Math.PI), e.stroke(), e.strokeStyle = "#00ff00", e
              .beginPath(), e.arc(-t, -38 * s, 9 * s, 0, 2 * Math.PI), e.stroke(), r % 20 < 3 && (e.globalAlpha =
                .4, e.fillStyle = "#00ffaa", e.fillRect(-20 * s, -45 * s + 40 * Math.random() * s, 40 * s, 2 * s)),
              e.globalAlpha = .06, e.fillStyle = "#00ffaa";
            e.fillRect(-20 * s, 2 * r % 60 * s - 30 * s, 40 * s, 2 * s)
          }
        }
        e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
      }
      e.restore()
    }
    let eL = [];

    function eD(e, t, o, a, l) {
      let r = e.createLinearGradient(0, 0, 0, o);
      r.addColorStop(0, "#030310"), r.addColorStop(.5, "#050520"), r.addColorStop(1, "#030310"), e.fillStyle = r, e
        .fillRect(0, 0, t, o), e.globalAlpha = .06, e.strokeStyle = n, e.lineWidth = 1;
      let i = .3 * a % 80;
      for (let a = i; a < t; a += 80) e.beginPath(), e.moveTo(a, 0), e.lineTo(a, o), e.stroke();
      for (let a = 0; a < o; a += 80) e.beginPath(), e.moveTo(0, a), e.lineTo(t, a), e.stroke();
      for (let a of (e.globalAlpha = 1, l)) a.x += a.vx, a.y += a.vy, a.y < -10 && (a.y = o + 10, a.x = Math
        .random() * t), a.x < -10 && (a.x = t + 10), a.x > t + 10 && (a.x = -10), e.globalAlpha = .5, e.shadowBlur =
        5, e.shadowColor = a.color, e.fillStyle = a.color, e.beginPath(), e.arc(a.x, a.y, a.size, 0, 2 * Math.PI), e
        .fill();
      e.shadowBlur = 0, e.globalAlpha = 1
    }

    function eW(e, t, o, a) {
      e.fillStyle = "#050505", e.fillRect(0, 0, t, o), e.globalAlpha = .04, e.fillStyle = f;
      for (let l = 0; l < 8; l++) {
        let r = (1.5 * a + 97 * l) % o;
        e.fillRect(0, r, t, 3 + 5 * Math.random())
      }
      e.globalAlpha = 1
    }

    function eO(e, t, o, a, l, r, n, i) {
      return e < l + n && e + o > l && t < r + i && t + a > r
    }

    function eB() {
      return !!window.Capacitor?.isNativePlatform?.() || window.matchMedia("(hover: none) and (pointer: coarse)")
        .matches || /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    }
    let eG = eB(),
      e$ = eG ? .4 : 1,
      eF = eG ? 20 : 100,
      eH = 1e3 / (eG ? 30 : 60);

    function eU(e, t, o, a, l) {
      let r = eG ? Math.min(Math.ceil(a * e$), 3) : a;
      for (let a = 0; a < r; a++) e.push({
        x: t,
        y: o,
        vx: (Math.random() - .5) * 5,
        vy: (Math.random() - .5) * 5 - 1.5,
        life: 18 + 18 * Math.random(),
        maxLife: 36,
        color: l,
        size: 2 + 2 * Math.random()
      });
      e.length > eF && e.splice(0, e.length - eF)
    }

    function eV(e) {
      return {
        px: "moving" === e.type && "x" === e.moveAxis && e.moveRange && e.moveSpeed ? e.x + Math.sin(e.moveOffset ||
          0) * e.moveRange : e.x,
        py: "moving" === e.type && "y" === e.moveAxis && e.moveRange && e.moveSpeed ? e.y + Math.sin(e.moveOffset ||
          0) * e.moveRange : e.y
      }
    }

    function ez(e) {
      return "boss" === e || "bossRedKing" === e || "bossTitan" === e || "bossDragon" === e || "bossPhoenix" ===
        e || "bossMechGolem" === e || "bossCorrupted" === e || "bossFather" === e || "bossTwin" === e || "giant" ===
        e ? 80 : "voidGuardian" === e ? 30 : "dragon" === e || "phoenix" === e ? 50 : "mechGolem" === e ||
        "heavyWalker" === e || "zombie" === e ? 55 : "shadowAssassin" === e || "eliteDrone" === e ||
        "necromancer" === e ? 50 : "bomber" === e ? 45 : "voidBat" === e ? 30 : "stormEagle" === e ? 45 :
        "emberWisp" === e ? 30 : "frostWraith" === e ? 45 : "shadowDrake" === e ? 55 : "plasmaSerpent" === e ? 50 :
        "neonWyrm" === e ? 60 : "crystalMoth" === e ? 35 : 50
    }

    function e_(e) {
      let t = _[e];
      return t && 0 !== t.length ? t[Math.floor(Math.random() * t.length)] : ""
    }
    let eK = (e, t, o, a, l, r = 20) => {
        let n = t + 5;
        for (let t of [e + 35 * o, e + 35 * o + (o > 0 ? r : -r) * .5, e + (o > 0 ? r : 0) + 5 * o]) {
          let e = !1;
          for (let o of a) {
            let {
              px: a,
              py: l
            } = eV(o);
            if (t >= a && t <= a + o.width && n >= l - 5 && n <= l + o.height + 20) {
              e = !0;
              break
            }
          }
          if (!e) return !1
        }
        return !(e + 35 * o < 0) && !(e + 35 * o > l.width - 20)
      },
      eq = (0, a.forwardRef)(function(e, t) {
        let l = (0, a.useRef)(null),
          r = (0, a.useRef)(0),
          x = (0, a.useRef)({
            left: !1,
            right: !1,
            up: !1,
            shoot: !1
          }),
          g = (0, a.useRef)({
            left: !1,
            right: !1,
            up: !1,
            shoot: !1,
            dash: !1,
            shield: !1,
            special: !1
          }),
          b = (0, a.useRef)({
            active: !1,
            dx: 0,
            dy: 0
          }),
          M = (0, a.useRef)({
            active: !1,
            dx: 0,
            dy: 0
          }),
          j = (0, a.useRef)(null),
          N = (0, a.useRef)(null),
          I = (0, a.useRef)([]),
          D = (0, a.useRef)([]),
          W = (0, a.useRef)([]),
          O = (0, a.useRef)([]),
          B = (0, a.useRef)(null),
          $ = (0, a.useRef)(0),
          F = (0, a.useRef)(0),
          z = (0, a.useRef)(0),
          _ = (0, a.useRef)(!1),
          K = (0, a.useRef)(!1),
          q = (0, a.useRef)(1),
          Y = (0, a.useRef)([]),
          J = (0, a.useRef)(null),
          X = (0, a.useRef)(0),
          Q = (0, a.useRef)([]),
          ee = (0, a.useRef)(!1),
          et = (0, a.useRef)(0),
          el = (0, a.useRef)(""),
          er = (0, a.useRef)(n),
          en = (0, a.useRef)(0),
          ei = (0, a.useRef)(0),
          es = (0, a.useRef)([]),
          ec = (0, a.useRef)(null),
          ed = (0, a.useRef)("menu"),
          eh = (0, a.useRef)(!1),
          ef = (0, a.useRef)(0),
          eu = (0, a.useRef)(""),
          em = (0, a.useRef)(n),
          ex = (0, a.useRef)(0),
          ep = (0, a.useRef)(""),
          eg = (0, a.useRef)(n),
          ey = (0, a.useRef)(0),
          eb = (0, a.useRef)(0),
          ev = (0, a.useRef)(!1),
          ew = (0, a.useRef)(1),
          ek = (0, a.useRef)([]),
          eC = (0, a.useRef)(0),
          eS = (0, a.useRef)({
            x: 0,
            y: 0,
            active: !1
          }),
          eT = (0, a.useRef)(0),
          eM = (0, a.useRef)(0),
          ej = (0, a.useRef)(null),
          eN = (0, a.useRef)(0),
          eP = (0, a.useRef)(!1),
          eA = (0, a.useRef)(1),
          eR = (0, a.useRef)([]),
          eI = (0, a.useRef)(0),
          e$ = (0, a.useRef)(0),
          eq = (0, a.useRef)(0),
          eY = (0, a.useRef)(0),
          eJ = (0, a.useRef)(0),
          eZ = () => {
            eh.current || (eo.init(), eh.current = !0)
          },
          eX = (0, a.useCallback)(e => {
            let t = [],
              o = eG ? 30 : 80;
            for (let a = 0; a < o; a++) t.push({
              x: Math.random() * e,
              y: 600 * Math.random(),
              size: .5 + 2 * Math.random(),
              speed: .1 + .3 * Math.random()
            });
            Y.current = t
          }, []),
          eQ = (0, a.useCallback)((e, t) => {
            let o = [],
              a = eG ? 15 : 40;
            for (let l = 0; l < a; l++) o.push({
              x: Math.random() * e,
              y: Math.random() * t,
              vx: (Math.random() - .5) * .5,
              vy: -(.5 * Math.random()) - .2,
              color: [n, i, s, h][Math.floor(4 * Math.random())],
              size: 1 + 3 * Math.random()
            });
            Q.current = o
          }, []),
          e0 = (0, a.useCallback)((e, t, o) => {
            let a = C.find(e => e.id === o) || C[0],
              l = ea.getState().saveData;
            return {
              x: e,
              y: t,
              width: 20,
              height: 50,
              vx: 0,
              vy: 0,
              health: 100,
              maxHealth: 100,
              facing: 1,
              grounded: !1,
              shootCooldown: 0,
              animFrame: 0,
              animTimer: 0,
              invincible: 0,
              expression: "determined",
              isMoving: !1,
              isShooting: !1,
              shootTimer: 0,
              dashCooldown: 0,
              dashTimer: 0,
              isDashing: !1,
              shieldCooldown: 0,
              shieldTimer: 0,
              isShielding: !1,
              specialCooldown: 0,
              specialTimer: 0,
              isUsingSpecial: !1,
              jumpCount: 0,
              maxJumps: 2,
              kills: 0,
              combo: 0,
              comboTimer: 0,
              skinColor: a.color,
              skinGlow: a.glowColor,
              skinTrail: a.trailColor,
              skinEffect: a.effect,
              equippedSkills: l.equippedSkills.slice(0, 3),
              skillStates: l.equippedSkills.slice(0, 3).filter(e => e).map(e => ({
                id: e,
                cooldownTimer: 0,
                activeTimer: 0,
                isActive: !1
              }))
            }
          }, []),
          e1 = (0, a.useRef)([]),
          e2 = (0, a.useRef)([]),
          e5 = (e, t) => {
            let o, a = (o = 11 * (5 * e + 13) + 37, () => (o = (9301 * o + 49297) % 233280) / 233280),
              l = 2 + Math.floor(3 * a()),
              r = [];
            for (let e = 0; e < l; e++) {
              let e = Math.floor(a() * t.length),
                o = t[e];
              r.push({
                x: o.x + 20 + Math.floor(a() * (o.width - 40)),
                y: o.y - 25,
                opened: !1,
                reward: a() > .8 ? "skill" : "coins",
                value: a() > .5 ? 25 : 10
              })
            }
            e2.current = r
          },
          e3 = (0, a.useCallback)(e => {
            let t, o, a = ea.getState().gameMode,
              l = "versus" === a,
              r = l ? L : G.find(t => t.id === e) || U(e);
            if (!r) return;
            B.current = r, J.current = R(A(e));
            let i = ea.getState().saveData;
            l ? (j.current = e0(100, 460, i.currentSkin), N.current = e0(r.width - 120, 460, "default"), N
              .current.skinColor = c, N.current.skinGlow = f, N.current.skinTrail = c, N.current.facing = -1,
              ec.current = null, es.current = []) : (j.current = e0(r.playerSpawn.x, r.playerSpawn.y, i
              .currentSkin), "coop" === a ? (N.current = e0(r.playerSpawn.x + 40, r.playerSpawn.y,
                "default"), N.current.skinColor = c, N.current.skinGlow = f, N.current.skinTrail = c, N
              .current.facing = 1) : N.current = null);
            let s = i.gangMembersUnlocked;
            es.current = r.gangMembersAvailable.filter(e => s.includes(e)).map(e => ({
                ...k.find(t => t.id === e),
                active: !0,
                x: r.playerSpawn.x - 40 - 30 * Math.random(),
                y: r.playerSpawn.y,
                vx: 0,
                vy: 0,
                facing: 1,
                animFrame: 0,
                shootCooldown: 60 + Math.floor(40 * Math.random()),
                grounded: !1,
                invincible: 0,
                expression: "determined"
              })), I.current = [], D.current = [], W.current = [], O.current = r.platforms.map(e => ({
                ...e,
                moveOffset: e.moveOffset || 0
              })), $.current = 0, F.current = 0, z.current = 0, ee.current = !1, X.current = 0, en.current = 0,
              ei.current = 0, et.current = 0, ef.current = 0, eu.current = "", em.current = n, ex.current = 0,
              ep.current = "", eg.current = n, ey.current = 0;
            let d = v.find(e => e.id === i.currentPet) || v[0],
              h = w.find(e => e.id === i.currentPetSkin) || w[0];
            ec.current = {
              x: r.playerSpawn.x + 30,
              y: r.playerSpawn.y - 20,
              vx: 0,
              vy: 0,
              health: 50,
              maxHealth: 50,
              type: d.id,
              skinColor: h.color,
              skinGlow: h.glowColor,
              shootCooldown: d.shootRate,
              animFrame: 0,
              grounded: !1,
              facing: 1,
              invincible: 0,
              expression: "neutral",
              active: !0,
              respawnTimer: 0
            };
            let u = (o = 7 * (3 * e + 7) + 13, () => (o = (9301 * o + 49297) % 233280) / 233280),
              m = Math.min(15 + Math.floor(.6 * e), 40),
              x = [],
              p = () => e <= 20 ? 3 + Math.floor(6 * u()) : e <= 60 ? 5 + Math.floor(8 * u()) : 8 + Math.floor(
                8 * u());
            for (let e = 150; e < r.width - 150; e += 200 + Math.floor(100 * u())) x.push({
              x: e,
              y: 490,
              collected: !1,
              animFrame: Math.floor(100 * u()),
              value: p()
            });
            for (let e = 0; e < m; e++) {
              let e, t, o = u();
              if (o < .4) {
                let o = Math.floor(u() * r.platforms.length),
                  a = r.platforms[o];
                e = a.x + 20 + Math.floor(u() * (a.width - 40)), t = a.y - 30 - Math.floor(60 * u())
              } else o < .75 ? (e = 100 + Math.floor(u() * (r.width - 200)), t = 490) : (e = 100 + Math.floor(
              u() * (r.width - 200)), t = 200 + Math.floor(200 * u()));
              let a = p();
              x.push({
                x: e,
                y: t,
                collected: !1,
                animFrame: Math.floor(100 * u()),
                value: a
              })
            }
            let g = 2 + Math.floor(3 * u());
            for (let e = 0; e < g; e++) {
              let e = 200 + Math.floor(u() * (r.width - 600)),
                t = 250 + Math.floor(150 * u()),
                o = 4 + Math.floor(4 * u());
              for (let a = 0; a < o; a++) {
                let l = a / (o - 1),
                  r = e + 50 * a,
                  n = t - 60 * Math.sin(l * Math.PI);
                x.push({
                  x: r,
                  y: n,
                  collected: !1,
                  animFrame: Math.floor(100 * u()),
                  value: p()
                })
              }
            }
            let y = r.waves.length;
            for (let e = 0; e < y - 1; e++) {
              let e = 3 + Math.floor(2 * u());
              for (let t = 0; t < e; t++) {
                let e = 200 + Math.floor(u() * (r.width - 400)),
                  t = u() > .5 ? 490 : 250 + Math.floor(180 * u()),
                  o = p();
                x.push({
                  x: e,
                  y: t,
                  collected: !1,
                  animFrame: Math.floor(100 * u()),
                  value: o
                })
              }
            }
            ek.current = x, eC.current = 0, t = e <= 5 ? .8 + .01 * e : e <= 20 ? .85 + (e - 5) * .00333 : e <=
              50 ? .9 + (e - 20) * .00167 : .93 + Math.min((e - 50) * .001, .04), eS.current = {
                x: Math.floor(r.width * t),
                y: 480,
                active: !1
              }, eT.current = 0, ej.current = null, eN.current = 0, eP.current = !1, eA.current = e <= 3 ? .5 :
              e <= 50 ? .6 + (e - 3) * .01 : 1.07 + (e - 50) * .002, eR.current = [], eI.current = 0, e$
              .current = 0, eq.current = 0, eY.current = 0, eJ.current = 0, e1.current = i.equippedSkills
              .filter(e => e).map(e => ({
                id: e,
                cooldownTimer: 0,
                activeTimer: 0,
                isActive: !1
              })), e5(e, r.platforms);
            let b = 0;
            for (let e of r.waves) b += e.enemies.length;
            r.bossWave && (b += r.bossWave.enemies.length), eM.current = b, eX(r.width)
          }, [eX, e0, ea, e5]);
        (0, a.useImperativeHandle)(t, () => ({
          moveLeft: () => {
            x.current.left = !0
          },
          moveRight: () => {
            x.current.right = !0
          },
          stopMove: () => {
            x.current.left = !1, x.current.right = !1, x.current.up = !1, x.current.shoot = !1
          },
          jump: () => {
            let e = j.current;
            e && e.jumpCount < e.maxJumps && (e.vy = -12, e.grounded = !1, e.jumpCount++, eU(W.current, e
              .x + e.width / 2, e.y, 5, n), eZ(), eo.playJump())
          },
          shoot: () => {
            x.current.shoot = !0
          },
          stopShoot: () => {
            x.current.shoot = !1
          },
          dash: () => {
            let e = j.current;
            !e || e.dashCooldown > 0 || e.isDashing || (e.isDashing = !0, e.dashTimer = 8, e.dashCooldown =
              90, e.invincible = Math.max(e.invincible, 8), e4(e_("dash"), n), eU(W.current, e.x + e
                .width / 2, e.y - 25, 8, n), eZ(), eo.playDash())
          },
          shield: () => {
            let e = j.current;
            !e || e.shieldCooldown > 0 || e.isShielding || (e.isShielding = !0, e.shieldTimer = 120, e
              .shieldCooldown = 300, e4(e_("shield"), s), eZ(), eo.playShield())
          },
          special: () => {
            let e = j.current;
            if (!e || e.specialCooldown > 0 || e.isUsingSpecial) return;
            e.isUsingSpecial = !0, e.specialTimer = 30, e.specialCooldown = 360, X.current = 10, e4(e_(
              "special"), c);
            let t = e.x + e.width / 2,
              o = e.y - 25;
            for (let a = -.5; a <= .51; a += .1) {
              let l = Math.cos(a),
                r = Math.sin(a),
                n = 10 * e.facing;
              D.current.push({
                x: t,
                y: o,
                vx: n * l - 0 * r,
                vy: n * r + 0 * l,
                fromPlayer: !0,
                damage: 30,
                active: !0,
                color: c,
                radius: 5,
                isSpecial: !0
              })
            }
            eU(W.current, t, o, 20, c), eZ(), eo.playSpecial()
          },
          setJoystick: e => {
            b.current = e
          },
          setP2Joystick: e => {
            M.current = e
          },
          executeSkill: e => {
            e8(e)
          },
          pause: () => {
            "playing" === ea.getState().gamePhase && ea.getState().setGamePhase("settings")
          }
        }));
        let e4 = (e, t) => {
            el.current = e, er.current = t, et.current = 90
          },
          e6 = (e, t) => {
            eu.current = e, em.current = t, ex.current = 120
          },
          e8 = e => {
            let t = j.current;
            if (!t || t.health <= 0) return;
            let o = P.find(t => t.id === e);
            if (!o) return;
            let a = e1.current.find(t => t.id === e);
            if (a || (a = {
                id: e,
                cooldownTimer: 0,
                activeTimer: 0,
                isActive: !1
              }, e1.current.push(a)), a.cooldownTimer > 0 || a.isActive) return;
            if ("blood" === o.element && "bloodStrike" === o.id) {
              if (t.health <= 10) return;
              t.health -= 10, t.invulnFlash = 10
            }
            let l = I.current,
              r = D.current,
              n = W.current,
              i = t.x + t.width / 2,
              s = t.y - 25,
              c = ea.getState().saveData.skillUpgrades[e] ?? 1,
              d = S[Math.min(c - 1, S.length - 1)],
              h = T[Math.min(c - 1, T.length - 1)];
            switch (o.effectType) {
              case "projectile": {
                let e = o.projectileCount || 1;
                for (let a = 0; a < e; a++) {
                  let l = e > 1 ? (a / (e - 1) - .5) * .6 : 0;
                  r.push({
                    x: i,
                    y: s,
                    vx: 15 * t.facing * Math.cos(l),
                    vy: 15 * Math.sin(l),
                    fromPlayer: !0,
                    damage: Math.round(o.damage * d),
                    active: !0,
                    color: o.color,
                    radius: 6,
                    isSpecial: !0
                  })
                }
                eU(n, i, s, 15, o.color), X.current = 5;
                break
              }
              case "aoe": {
                let e = o.effectRadius || 200;
                for (let t of l) {
                  if (!t.active) continue;
                  let a = t.x + t.width / 2 - i,
                    l = t.y - 25 - s;
                  if (Math.sqrt(a * a + l * l) < e) {
                    let e = t.type.startsWith("boss"),
                      a = 999 !== o.damage || e ? o.damage : t.health,
                      l = 999 !== o.damage || e ? Math.round(a * d) : a;
                    t.health -= l, t.isHit = !0, t.hitTimer = 10
                  }
                }
                for (let t = 0; t < 2 * Math.PI; t += .15)
                  for (let a = 30; a < e; a += 60) n.push({
                    x: i + Math.cos(t) * a,
                    y: s + Math.sin(t) * a * .5,
                    vx: 2 * Math.cos(t),
                    vy: 2 * Math.sin(t) - 1,
                    life: 30,
                    maxLife: 30,
                    color: o.glowColor,
                    size: 3
                  });
                if (X.current = 15, "soulHarvest" === o.id) {
                  let o = l.filter(t => t.active && Math.sqrt((t.x + t.width / 2 - i) ** 2 + (t.y - 25 - s) **
                    2) < e).length;
                  t.health = Math.min(t.maxHealth, t.health + 5 * o)
                }
                break
              }
              case "buff":
                if ("shadowStep" === o.id) {
                  let e = l.filter(e => e.active).sort((e, o) => Math.abs(e.x - t.x) - Math.abs(o.x - t.x))[0];
                  e && (t.x = e.x + (e.x > t.x ? -40 : 40), t.facing = e.x > t.x ? 1 : -1, t.invincible = Math
                    .max(t.invincible, o.duration), e.health -= Math.round(o.damage * d), e.isHit = !0, e
                    .hitTimer = 10), eU(n, i, s, 20, o.color)
                } else "voidWalk" === o.id ? (t.invincible = Math.max(t.invincible, o.duration), eU(n, i, s, 25, o
                  .color)) : "bloodFury" === o.id && eU(n, i, s, 20, o.color);
                break;
              case "summon": {
                let e = o.summonCount || 1;
                for (let a = 0; a < e; a++) {
                  let l = a / e * Math.PI * .6 - .3 * Math.PI;
                  for (let e = 0; e < 3; e++) r.push({
                    x: i,
                    y: s,
                    vx: 10 * t.facing * Math.cos(l) + (Math.random() - .5) * 2,
                    vy: 10 * Math.sin(l) * .5 - 2 + .5 * e,
                    fromPlayer: !0,
                    damage: Math.round(o.damage * d),
                    active: !0,
                    color: o.glowColor,
                    radius: 5,
                    isSpecial: !0
                  })
                }
                eU(n, i, s, 20, o.color), X.current = 8;
                break
              }
              case "beam":
                for (let e = 0; e < 8; e++) r.push({
                  x: i + t.facing * e * 15,
                  y: s + (Math.random() - .5) * 10,
                  vx: 20 * t.facing,
                  vy: (Math.random() - .5) * 1,
                  fromPlayer: !0,
                  damage: Math.round(o.damage / 4 * d),
                  active: !0,
                  color: o.glowColor,
                  radius: 7,
                  isSpecial: !0
                });
                eU(n, i, s, 25, o.color), X.current = 12;
                break;
              case "wave":
                for (let e = 0; e < 2 * Math.PI; e += Math.PI / 6) r.push({
                  x: i,
                  y: s,
                  vx: 10 * Math.cos(e),
                  vy: 10 * Math.sin(e) * .6,
                  fromPlayer: !0,
                  damage: Math.round(o.damage * d),
                  active: !0,
                  color: o.color,
                  radius: 5,
                  isSpecial: !0
                });
                eU(n, i, s, 30, o.glowColor), X.current = 10
            }
            a.cooldownTimer = Math.round(o.cooldown * h), a.activeTimer = o.duration, a.isActive = !0, e4(o.name +
              "!", o.color), eZ(), eo.playSpecial()
          };
        (0, a.useEffect)(() => {}, []), (0, a.useEffect)(() => (window.__neonWarriorControls = {
          moveLeft: () => {
            x.current.left = !0
          },
          moveRight: () => {
            x.current.right = !0
          },
          stopMove: () => {
            x.current.left = !1, x.current.right = !1, x.current.up = !1, x.current.shoot = !1
          },
          jump: () => {
            let e = j.current;
            e && e.jumpCount < e.maxJumps && (e.vy = -12, e.grounded = !1, e.jumpCount++, eU(W.current, e
              .x + e.width / 2, e.y, 5, n), eZ(), eo.playJump())
          },
          shoot: () => {
            x.current.shoot = !0
          },
          stopShoot: () => {
            x.current.shoot = !1
          },
          dash: () => {
            let e = j.current;
            !e || e.dashCooldown > 0 || e.isDashing || (e.isDashing = !0, e.dashTimer = 8, e.dashCooldown =
              90, e.invincible = Math.max(e.invincible, 8), e4(e_("dash"), n), eU(W.current, e.x + e
                .width / 2, e.y - 25, 8, n), eZ(), eo.playDash())
          },
          shield: () => {
            let e = j.current;
            !e || e.shieldCooldown > 0 || e.isShielding || (e.isShielding = !0, e.shieldTimer = 120, e
              .shieldCooldown = 300, e4(e_("shield"), s), eZ(), eo.playShield())
          },
          special: () => {
            let e = j.current;
            if (!e || e.specialCooldown > 0 || e.isUsingSpecial) return;
            e.isUsingSpecial = !0, e.specialTimer = 30, e.specialCooldown = 360, X.current = 10, e4(e_(
              "special"), c);
            let t = e.x + e.width / 2,
              o = e.y - 25;
            for (let a = -.5; a <= .51; a += .1) {
              let l = Math.cos(a),
                r = Math.sin(a),
                n = 10 * e.facing;
              D.current.push({
                x: t,
                y: o,
                vx: n * l - 0 * r,
                vy: n * r + 0 * l,
                fromPlayer: !0,
                damage: 30,
                active: !0,
                color: c,
                radius: 5,
                isSpecial: !0
              })
            }
            eU(W.current, t, o, 20, c), eZ(), eo.playSpecial()
          },
          setJoystick: e => {
            b.current = e
          },
          setP2Joystick: e => {
            M.current = e
          },
          p2Jump: () => {
            let e = N.current;
            e && e.jumpCount < e.maxJumps && (e.vy = -12, e.grounded = !1, e.jumpCount++, eU(W.current, e
              .x + e.width / 2, e.y, 5, c), eZ(), eo.playJump())
          },
          p2Shoot: () => {
            g.current.shoot = !0
          },
          p2StopShoot: () => {
            g.current.shoot = !1
          },
          p2Dash: () => {
            let e = N.current;
            !e || e.dashCooldown > 0 || e.isDashing || (e.isDashing = !0, e.dashTimer = 8, e.dashCooldown =
              90, e.invincible = Math.max(e.invincible, 8), eU(W.current, e.x + e.width / 2, e.y - 25, 8,
                c), eZ(), eo.playDash())
          },
          p2Shield: () => {
            let e = N.current;
            !e || e.shieldCooldown > 0 || e.isShielding || (e.isShielding = !0, e.shieldTimer = 120, e
              .shieldCooldown = 300, eZ(), eo.playShield())
          },
          p2Special: () => {
            let e = N.current;
            if (!e || e.specialCooldown > 0 || e.isUsingSpecial) return;
            e.isUsingSpecial = !0, e.specialTimer = 30, e.specialCooldown = 360, X.current = 10;
            let t = e.x + e.width / 2,
              o = e.y - 25;
            for (let a = -.5; a <= .51; a += .1) {
              let l = Math.cos(a),
                r = Math.sin(a),
                n = 10 * e.facing;
              D.current.push({
                x: t,
                y: o,
                vx: n * l,
                vy: n * r,
                fromPlayer: !0,
                damage: 30,
                active: !0,
                color: c,
                radius: 5,
                isSpecial: !0,
                fromPlayerId: 2
              })
            }
            eU(W.current, t, o, 20, c), eZ(), eo.playSpecial()
          },
          executeSkill: e => {
            e8(e)
          },
          pause: () => {
            "playing" === ea.getState().gamePhase && ea.getState().setGamePhase("settings")
          }
        }, () => {
          delete window.__neonWarriorControls
        }), []);
        let e9 = (e, t, o, a, l, r, n, i, s) => {
          let c = 0;
          if (o?.active ? e.facing = (c = o.dx) > .05 ? 1 : c < -.05 ? -1 : e.facing : (t.left && (c = -1, e
              .facing = -1), t.right && (c = 1, e.facing = 1)), e.isDashing ? (e.dashTimer -= (eG ? 2 : 1), e
              .vx = 18 * e.facing, e.dashTimer <= 0 && (e.isDashing = !1), F.current % 2 == 0 && eU(r, e.x + e
                .width / 2, e.y - 25, 2, e.skinColor)) : e.vx = (e.grounded ? 5 : 3.5) * c, e.isMoving = Math
            .abs(c) > .1 || e.isDashing, e.isShielding && (e.shieldTimer -= (eG ? 2 : 1), e.shieldTimer <= 0 &&
              (e.isShielding = !1)), e.isUsingSpecial && (e.specialTimer -= (eG ? 2 : 1), e.specialTimer <= 0 &&
              (e.isUsingSpecial = !1)), e.shootCooldown > 0 && (e.shootCooldown -= (eG ? 2 : 1)), e
            .isShooting && e.shootTimer--, t.shoot && e.shootCooldown <= 0 && !e.isDashing) {
            let t = ea.getState().saveData.weaponUpgrades,
              o = t.damage ?? 0,
              a = t.fireRate ?? 0,
              n = t.bulletSpeed ?? 0,
              i = t.bulletSize ?? 0,
              c = t.criticalChance ?? 0,
              d = 1 + o * y.damage.effectPerLevel,
              h = 1 - Math.min(a * y.fireRate.effectPerLevel, .8),
              f = 1 + n * y.bulletSpeed.effectPerLevel,
              u = 1 + i * y.bulletSize.effectPerLevel,
              x = Math.random() < c * y.criticalChance.effectPerLevel;
            l.push({
              x: e.x + e.width / 2 + 15 * e.facing,
              y: e.y - 25,
              vx: 10 * e.facing * f,
              vy: 0,
              fromPlayer: !0,
              damage: Math.round(10 * d * (x ? 2 : 1)),
              active: !0,
              color: x ? m : e.skinColor,
              radius: Math.round(4 * u),
              fromPlayerId: s
            }), e.shootCooldown = Math.max(2, Math.round(8 * h)), e.isShooting = !0, e.shootTimer = 6, eU(r, e
              .x + e.width / 2 + 20 * e.facing, e.y - 25, x ? 8 : 3, x ? m : e.skinColor), eZ(), eo
            .playShoot()
          }
          if (e.shootTimer <= 0 && (e.isShooting = !1), e.dashCooldown > 0 && e.dashCooldown--, e
            .shieldCooldown > 0 && e.shieldCooldown--, e.specialCooldown > 0 && e.specialCooldown--, F.current %
            6 == 0 && ea.getState().updateCooldowns(e.dashCooldown, e.shieldCooldown, e.specialCooldown), e
            .isDashing) e.expression = "determined";
          else if (e.isUsingSpecial) e.expression = "angry";
          else if (e.isShielding) e.expression = "smirk";
          else if (e.invincible > 0 && e.health < 30) e.expression = "hurt";
          else if (e.isShooting) e.expression = "determined";
          else if (e.isMoving) {
            let t = a.some(t => t.active && 300 > Math.abs(t.x - e.x));
            e.expression = t ? "angry" : "determined"
          } else e.expression = "smirk";
          let d = ew.current;
          for (let t of (e.vy += .5 * d, e.vy > 10 * d && (e.vy = 10 * d), e.x += e.vx * d, e.y += e.vy * d, e
              .grounded = !1, n)) {
            let {
              px: o,
              py: a
            } = eV(t);
            e.x + e.width > o + 4 && e.x < o + t.width - 4 && e.y >= a - 4 && e.y - e.vy * d <= a + Math.max(10,
              Math.abs(e.vy) * d + 8) && (e.y = a, e.vy = 0, e.grounded = !0, e.jumpCount = 0)
          }
          e.x < 0 && (e.x = 0), e.x + e.width > i.width && (e.x = i.width - e.width), e.y > i.height - 5 && (e
            .grounded || (e.grounded = !0), e.jumpCount = 0), e.y > i.height + 100 && (e.y = 460, e.vy = 0, e
            .vx = 0, e.x = 80), (0 !== e.vx || !e.grounded) && (e.animTimer++, e.animTimer >= 3 && (e
            .animTimer = 0, e.animFrame++)), e.invincible > 0 && (e.invincible -= (eG ? 2 : 1))
        };
        return (0, a.useEffect)(() => {
          let e = l.current;
          if (!e) return;
          let t = e.getContext("2d", {
            alpha: !1,
            willReadFrequently: !1
          });
          if (!t) return;
          let o = () => {
            let t = window.visualViewport || {
                width: window.innerWidth,
                height: window.innerHeight
              },
              o = Math.min(window.devicePixelRatio || 1, 1.5);
            q.current = o, e.width = Math.floor(t.width * o), e.height = Math.floor(t.height * o), e.style
              .width = t.width + "px", e.style.height = t.height + "px", _.current = eB(), K.current = _
              .current
          };
          o(), window.addEventListener("resize", o), document.addEventListener("visibilitychange", () => {
            document.hidden && ea.getState().gamePhase === "playing" && ea.getState().setGamePhase(
              "settings")
          }), window.visualViewport && window.visualViewport.addEventListener("resize", o);
          let a = () => {
            setTimeout(o, 100)
          };
          window.addEventListener("orientationchange", a);
          let y = 0,
            w = ea.getState().gamePhase,
            k = 0,
            C = ea.subscribe(e => {
              if ("playing" === e.gamePhase && e.currentLevel !== y && (y = e.currentLevel, e3(e
                    .currentLevel), ee.current = !1, eZ(), eo.stopMenuMusic(), eo.startMusic(), e
                  .introText && (ep.current = e.introText, eg.current = e.introColor, ey.current = e
                    .introTimer)), "playing" === e.gamePhase && "playing" !== w && e.currentLevel === y && e
                .waitingForTap && (e.introText && (ep.current = e.introText, eg.current = e.introColor, ey
                  .current = e.introTimer), B.current && B.current.id === e.currentLevel || (e3(e
                  .currentLevel), ee.current = !1, eZ(), eo.stopMenuMusic(), eo.startMusic())), "versus" ===
                e.gameMode && "playing" === e.gamePhase && 0 === e.versusRoundWinner && 0 !== k) {
                let t = B.current || L;
                j.current = e0(100, 460, ea.getState().saveData.currentSkin), N.current = e0(t.width - 120,
                    460, "default"), N.current.skinColor = c, N.current.skinGlow = f, N.current.skinTrail =
                  c, N.current.facing = -1, D.current = [], W.current = [], ek.current = [], I.current = [],
                  e.introText && (ep.current = e.introText, eg.current = e.introColor, ey.current = e
                    .introTimer)
              }
              if (k = e.versusRoundWinner, "playing" === e.gamePhase && "game-over" === w && e
                .revivedWithFullPower) {
                let e = j.current;
                e && (e.health = e.maxHealth, e.dashCooldown = 0, e.shieldCooldown = 0, e.specialCooldown =
                  0, e.invincible = 120)
              }
              "playing" === w && "playing" !== e.gamePhase && ("settings" === e.gamePhase ? (eo.stopMusic(),
                  eo.stopBossMusic()) : (eo.stopMusic(), eo.stopBossMusic(), ("level-complete" === e
                    .gamePhase || "victory" === e.gamePhase) && eo.playVictoryFanfare(), "menu" === e
                  .gamePhase && eo.startMenuMusic())), "settings" === w && "playing" === e.gamePhase && (
                eZ(), e.isBossLevel ? eo.startBossMusic() : eo.startMusic()), "menu" !== w && "menu" === e
                .gamePhase && "playing" !== w && (eo.stopMenuMusic(), eo.startMenuMusic()), e
                .dramaticMoment && (eu.current = e.dramaticMoment.text, em.current = e.dramaticMoment.color,
                  ex.current = e.dramaticMoment.timer), ("menu" === e.gamePhase || "game-over" === e
                  .gamePhase || "level-complete" === e.gamePhase || "victory" === e.gamePhase) && (y = 0),
                w = e.gamePhase
            }),
            S = ea.getState();
          "playing" === S.gamePhase && S.currentLevel !== y && (y = S.currentLevel, e3(S.currentLevel));
          let T = q.current || 1;
          eQ(e.width / T, e.height / T);
          let A = o => {
              r.current = requestAnimationFrame(A), 0 === eb.current && (eb.current = o);
              let a = o - eb.current,
                l = _.current ? eH : 1e3 / 60;
              if (a < l) return;
              eb.current = o - a % l, _.current && a > 40 && !ev.current && (ev.current = !0), F.current++, ew
                .current = _.current ? 2 : 1;
              let c = ea.getState().gamePhase,
                h = q.current,
                f = e.width / h,
                u = e.height / h,
                m = u / 600,
                x = Math.ceil(f / m);
              _.current && (W.current.length > eF && W.current.splice(0, W.current.length - eF), D.current
                .length > 20 && (D.current = D.current.filter(e => e.active)), I.current.length > 15 && (I
                  .current = I.current.filter(e => e.active)));
              let p = 0,
                g = 0;
              switch (X.current > 0 && (p = (Math.random() - .5) * X.current, g = (Math.random() - .5) * X
                  .current, X.current *= .9, X.current < .5 && (X.current = 0)), t.save(), t.setTransform(h,
                  0, 0, h, 0, 0), t.translate(p, g), t.imageSmoothingEnabled = !1, c) {
                case "menu": {
                  eD(t, f, u, F.current, Q.current), t.save();
                  let e = 5 * Math.sin(.03 * F.current);
                  t.globalAlpha = .04, t.fillStyle = n, t.beginPath(), t.arc(f / 2, u / 2 + 40 + e, 40 + 8 *
                      Math.sin(.04 * F.current), 0, 2 * Math.PI), t.fill(), t.globalAlpha = .12, eE(t, f / 2,
                      u / 2 + 40 + e, 1, n, F.current, !1, !0, 1.2, "smirk", !1, !1, 0, ""), t.globalAlpha =
                    .35;
                  for (let o = 0; o < 8; o++) {
                    let a = o / 8 * Math.PI * 2 + .02 * F.current,
                      l = 55 + 10 * Math.sin(.04 * F.current + o),
                      r = f / 2 + Math.cos(a) * l,
                      i = u / 2 + 40 + e + Math.sin(a) * l * .5;
                    t.shadowBlur = 5, t.shadowColor = o % 2 == 0 ? n : s, t.fillStyle = o % 2 == 0 ? n : s, t
                      .beginPath(), t.arc(r, i, 2, 0, 2 * Math.PI), t.fill()
                  }
                  t.shadowBlur = 0, t.globalAlpha = 1, t.restore(), "menu" !== ed.current && (ed.current =
                    "menu", eZ(), eo.stopMusic(), eo.stopBossMusic(), eo.startMenuMusic());
                  break
                }
                case "playing":
                  ea.getState().waitingForTap || ("versus" !== ea.getState().gameMode && R(), e8(x, 600)), t
                    .save(), t.scale(m, m), e7(t, x, 600), t.restore(), te(t, f, u), eh(t, f, u), U(t, f, u),
                    eX(t, f, u), eG(t, f, u), e5(t, f, u);
                  break;
                case "settings":
                  B.current && j.current ? (t.save(), t.scale(m, m), e7(t, x, 600), t.restore(), te(t, f, u),
                    t.fillStyle = "rgba(0,0,0,0.4)", t.fillRect(0, 0, f, u)) : eW(t, f, u, F.current);
                  break;
                case "cutscene":
                default:
                  eD(t, f, u, F.current, Q.current);
                  break;
                case "game-over":
                case "skin-shop":
                  eW(t, f, u, F.current);
                  break;
                case "level-complete":
                case "victory":
                  ! function(e, t, o, a) {
                    let l = e.createLinearGradient(0, 0, 0, o);
                    l.addColorStop(0, "#000510"), l.addColorStop(.5, "#001020"), l.addColorStop(1, "#000510"),
                      e.fillStyle = l, e.fillRect(0, 0, t, o), e.globalAlpha = .5;
                    for (let l = 0; l < 30; l++) {
                      let r = (73.7 * l + .5 * a) % t,
                        c = o - (47.7 * l + .8 * a) % o,
                        h = [n, s, i, d][l % 4];
                      e.shadowBlur = 5, e.shadowColor = h, e.fillStyle = h, e.beginPath(), e.arc(r, c, 2, 0,
                        2 * Math.PI), e.fill()
                    }
                    e.shadowBlur = 0, e.globalAlpha = 1
                  }(t, f, u, F.current)
              }
              t.restore()
            },
            R = () => {
              if (ee.current && 0 === eR.current.length) return;
              let e = B.current,
                t = j.current;
              if (!e || !t) return;
              if (eR.current.length > 0) {
                if (eI.current--, eI.current <= 0) {
                  let e = Math.min(eR.current.length, 2);
                  for (let t = 0; t < e; t++) {
                    let e = eR.current.shift();
                    e.x += Math.floor(Math.random() * 100 - 50), e.active = !0, I.current.push(e), eJ
                      .current++
                  }
                  eI.current = e$.current, 0 === eR.current.length && (ee.current = !0)
                }
                return
              }
              if (ee.current) return;
              let o = ea.getState(),
                a = o.currentWave,
                l = o.totalWaves,
                r = e.bossWave && a === l - 1,
                s = r ? e.bossWave : e.waves[a];
              if (!s) {
                z.current += 200, ea.getState().completeLevel(z.current);
                return
              }
              let d = s.enemies.map((e, t) => {
                let o, a, l, r = "boss" === e.type || "bossRedKing" === e.type || "bossTitan" === e
                  .type || "bossDragon" === e.type || "bossPhoenix" === e.type || "bossMechGolem" === e
                  .type || "bossCorrupted" === e.type || "bossFather" === e.type || "bossTwin" === e.type,
                  n = "voidGuardian" === e.type,
                  i = "eliteDrone" === e.type,
                  s = "heavyWalker" === e.type,
                  c = "dragon" === e.type,
                  d = "phoenix" === e.type,
                  h = "mechGolem" === e.type,
                  f = "shadowAssassin" === e.type,
                  u = "bossTitan" === e.type ? 500 : "bossRedKing" === e.type ? 400 : "boss" === e.type ?
                  300 : "bossDragon" === e.type ? 600 : "bossPhoenix" === e.type ? 450 :
                  "bossMechGolem" === e.type ? 550 : "bossCorrupted" === e.type ? 480 : "bossFather" === e
                  .type ? 550 : "bossTwin" === e.type ? 700 : 150,
                  m = 20,
                  x = 50,
                  p = 20;
                r ? (m = 60, x = 80, p = u) : n ? (m = 30, x = 30, p = 25) : i ? (m = 20, x = 50, p =
                  30) : s ? (m = 25, x = 55, p = 40) : c ? (m = 35, x = 40, p = 45) : d ? (m = 25, x = 40,
                    p = 35) : h ? (m = 30, x = 55, p = 60) : f ? (m = 18, x = 50, p = 25) : "drone" === e
                  .type ? p = 20 : "glitchWalker" === e.type ? p = 25 : "voidBat" === e.type ? (m = 16,
                    x = 30, p = 15) : "stormEagle" === e.type ? (m = 24, x = 45, p = 30) : "emberWisp" ===
                  e.type ? (m = 16, x = 30, p = 18) : "frostWraith" === e.type ? (m = 22, x = 45, p =
                  35) : "shadowDrake" === e.type ? (m = 30, x = 55, p = 40) : "plasmaSerpent" === e.type ?
                  (m = 26, x = 50, p = 35) : "neonWyrm" === e.type ? (m = 32, x = 60, p = 50) :
                  "crystalMoth" === e.type ? (m = 18, x = 35, p = 20) : "zombie" === e.type ? (m = 22, x =
                    55, p = 55) : "giant" === e.type ? (m = 55, x = 80, p = 150) : "necromancer" === e
                  .type ? (m = 20, x = 50, p = 40) : "bomber" === e.type && (m = 18, x = 45, p = 25);
                let g = ea.getState().currentLevel;
                return o = g <= 3 ? .4 : g <= 50 ? .6 + .2 * Math.log(1 + (g - 3) / 80) : g <= 200 ? 1 +
                  .25 * Math.log(1 + (g - 50) / 50) : 1.35 + .3 * Math.log(1 + (g - 200) / 100), a = g <=
                  3 ? .5 : g <= 50 ? .7 + .15 * Math.log(1 + (g - 3) / 100) : Math.min(1 + .2 * Math.log(
                    1 + g / 100), 1.8), l = g <= 50 ? .7 : g <= 200 ? 1 + .2 * Math.log(1 + (g - 50) /
                    100) : 1.2 + .3 * Math.log(1 + (g - 200) / 100), p = r ? Math.floor(p * l) : Math
                  .floor(p * o), {
                    x: e.x,
                    y: e.y,
                    width: m,
                    height: x,
                    vx: 0,
                    vy: 0,
                    type: e.type,
                    health: p,
                    maxHealth: p,
                    facing: -1,
                    shootCooldown: Math.floor((70 + Math.floor(30 * Math.random())) / a),
                    animFrame: 10 * t,
                    animTimer: 0,
                    active: !1,
                    grounded: !E(e.type),
                    patternTimer: 0,
                    invincible: 0,
                    isHit: !1,
                    hitTimer: 0,
                    bossName: e.bossName,
                    bossColor: e.bossColor
                  }
              });
              if (r || d.length <= 2) {
                for (let e of d) e.active = !0;
                I.current = [...I.current, ...d], ee.current = !0, eJ.current += d.length
              } else {
                eR.current = d, e$.current = 25 + Math.floor(20 * Math.random()), eI.current = 0;
                let e = Math.min(d.length, 2);
                for (let t = 0; t < e; t++) {
                  let e = eR.current.shift();
                  e.x += Math.floor(Math.random() * 100 - 50), e.active = !0, I.current.push(e), eJ.current++
                }
              }
              if (r) {
                eZ(), eo.stopMusic(), eo.startBossMusic();
                let e = s.enemies.find(e => e.bossName);
                e && (e6(`⚠ ${e.bossName} ⚠`, e.bossColor || f), X.current = 10)
              }
              if (s.voiceLine) e4(s.voiceLine, r ? i : n);
              else {
                let e = s.enemies.filter(e => ["dragon", "phoenix", "mechGolem", "shadowAssassin"].includes(e
                  .type));
                e.length > 0 && !r && e4(e_("dragon" === e[0].type ? "dragon" : "phoenix" === e[0].type ?
                  "phoenix" : "mechGolem" === e[0].type ? "mechGolem" : "shadowAssassin"), c)
              }
            },
            U = (e, t, o) => {
              if (ex.current <= 0) return;
              ex.current--;
              let a = ex.current;
              if (a <= 0) {
                eu.current = "";
                return
              }
              e.save(), e.globalAlpha = .8 * (a > 100 ? 1 : a / 100), e.fillStyle = "rgba(0,0,0,0.6)", e
                .fillRect(0, o / 2 - 35, t, 70), e.shadowBlur = 20, e.shadowColor = em.current, e.fillStyle =
                em.current, e.font = "bold 24px monospace", e.textAlign = "center", e.fillText(eu.current, t /
                  2, o / 2 + 8), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
            },
            eh = (e, t, o) => {
              if (et.current <= 0) return;
              et.current--;
              let a = et.current > 60 ? 1 : et.current / 60;
              e.save(), e.globalAlpha = .9 * a, e.shadowBlur = 10, e.shadowColor = er.current, e.fillStyle =
                er.current, e.font = "bold 16px monospace", e.textAlign = "center", e.fillText(el.current, t /
                  2, o - 100), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
            },
            eG = (e, t, o) => {
              if (ey.current <= 0 && ea.getState().introTimer > 0 && ea.getState().introText && (ep.current =
                  ea.getState().introText || "", eg.current = ea.getState().introColor, ey.current = ea
                  .getState().introTimer), !ep.current || ey.current <= 0) return;
              ey.current--;
              let a = ey.current;
              ey.current <= 0 && ea.setState({
                introTimer: 0
              });
              let l = a > 120 ? Math.min(1, (180 - a + 1) / 60) : a < 40 ? a / 40 : 1;
              e.save(), e.globalAlpha = .6 * l, e.fillStyle = "#000000", e.fillRect(0, o / 2 - 50, t, 100), e
                .globalAlpha = l, e.shadowBlur = 15, e.shadowColor = eg.current, e.fillStyle = eg.current, e
                .font = "bold 20px monospace", e.textAlign = "center", e.fillText(ep.current, t / 2, o / 2 +
                  5), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
            },
            eX = (e, t, o) => {
              if (!ej.current || eN.current <= 0) return;
              eN.current--;
              let a = ej.current,
                l = Math.min(1, eN.current / 30),
                r = 1 + .05 * Math.sin(.15 * eN.current);
              if (e.save(), e.globalAlpha = l, eN.current > a.duration - 10) {
                let r = (a.duration - eN.current + 1) / 10 * .3;
                e.fillStyle = a.color, e.globalAlpha = r, e.fillRect(0, 0, t, o), e.globalAlpha = l
              }
              e.textAlign = "center", e.font = `bold ${Math.floor(24*r)}px monospace`, e.fillStyle = a.color,
                e.shadowBlur = 20, e.shadowColor = a.color, e.fillText(a.text, t / 2, .3 * o), e.font =
                "bold 12px monospace", e.fillStyle = "#ffffff", e.shadowBlur = 5, e.shadowColor = "#ffffff", e
                .fillText(`[ ${a.type.toUpperCase()} ]`, t / 2, .35 * o), e.restore(), eN.current <= 0 && (ej
                  .current = null)
            },
            e5 = (e, t, o) => {
              if (ey.current > 0 || !B.current) return;
              let a = F.current;
              if (a > 300) return;
              let l = .7 * Math.max(0, 1 - a / 300);
              e.save(), e.globalAlpha = l;
              let r = o - 80;
              e.fillStyle = "rgba(0,0,0,0.5)", e.fillRect(t / 2 - 180, r - 10, 360, 30), e.strokeStyle = n, e
                .lineWidth = 1, e.strokeRect(t / 2 - 180, r - 10, 360, 30), e.fillStyle = n, e.font =
                "11px monospace", e.textAlign = "center", e.fillText(
                  "Joystick: Move | Buttons: Jump, Shoot, Skills", t / 2, r + 10), e.globalAlpha = 1, e
                .restore()
            },
            e8 = (e, t) => {
              let o, a = j.current,
                l = B.current;
              if (!a || !l) return;
              let r = x.current,
                u = g.current,
                w = b.current,
                k = I.current,
                C = D.current,
                S = W.current,
                T = O.current;
              for (let e of T) "moving" === e.type && e.moveSpeed && (e.moveOffset = (e.moveOffset || 0) +
                .02 * e.moveSpeed);
              let A = ea.getState().gameMode,
                R = "versus" === A,
                L = ea.getState().currentLevel;
              e9(a, r, w, k, C, S, T, l, R ? 1 : void 0), ei.current > 0 && (ei.current--, ei.current <= 0 &&
                (en.current = 0));
              let G = N.current,
                U = M.current;
              for (let e of (G && G.health > 0 && e9(G, u, U.active ? U : null, k, C, S, T, l, R ? 2 :
                  void 0), k)) {
                if (!e.active) continue;
                let t = Math.abs(e.x - a.x);
                switch (e.invincible > 0 && e.invincible--, e.isHit && (e.hitTimer--, e.hitTimer <= 0 && (e
                    .isHit = !1)), e.type) {
                  case "drone":
                    for (let o of (t < 500 ? (e.vx = e.x > a.x ? -1.5 : 1.5, e.facing = e.vx > 0 ? 1 : -1) : e
                        .vx = +e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e.width) && (e
                          .vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy = 10), e.x += e
                        .vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }(e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.animFrame++;
                    break;
                  case "glitchWalker":
                    if (t < 600) {
                      let t = 2.5 + .5 * Math.sin(.1 * e.animFrame);
                      e.vx = e.x > a.x ? -t : t, e.facing = e.vx > 0 ? 1 : -1
                    } else e.vx = 1.5 * e.facing;
                    for (let t of (e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e.width) && (e.vx = 0,
                          e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy = 10), e.x += e.vx, e
                        .y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if ((e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.shootCooldown -= (
                        eG ? 2 : 1), e.shootCooldown <= 0 && t < 500) {
                      let t = a.x - e.x,
                        o = a.y - 25 - (e.y - 25),
                        l = Math.sqrt(t * t + o * o);
                      l > 0 && C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 25,
                        vx: t / l * 5.5,
                        vy: o / l * 5.5,
                        fromPlayer: !1,
                        damage: 10,
                        active: !0,
                        color: h,
                        radius: 3
                      }), e.shootCooldown = 49
                    }
                    e.animFrame++;
                    break;
                  case "voidGuardian":
                    if (e.facing = e.x > a.x ? -1 : 1, e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <=
                      0 && t < 500) {
                      let t = a.x - e.x,
                        o = a.y - 25 - (e.y - 15),
                        l = Math.sqrt(t * t + o * o);
                      if (l > 0)
                        for (let a = -.2; a <= .21; a += .2) {
                          let r = Math.cos(a),
                            n = Math.sin(a);
                          C.push({
                            x: e.x + e.width / 2,
                            y: e.y - 15,
                            vx: (t / l * r - o / l * n) * 4.5,
                            vy: (t / l * n + o / l * r) * 4.5,
                            fromPlayer: !1,
                            damage: 10,
                            active: !0,
                            color: c,
                            radius: 3
                          })
                        }
                      e.shootCooldown = 80
                    }
                    e.animFrame++;
                    break;
                  case "boss":
                  case "bossRedKing":
                  case "bossTitan":
                  case "bossDragon":
                  case "bossPhoenix":
                  case "bossMechGolem": {
                    e.facing = e.x > a.x ? -1 : 1, e.patternTimer++;
                    let o = Math.min(.5 + (eA.current - 1) * .15, .75);
                    e.health < e.maxHealth * o && !e.enraged && (e.enraged = !0, X.current = 15, eU(S, e.x + e
                      .width / 2, e.y - 40, 30, f), eZ(), eo.playBossEnrage(), e4(e_("bossEnrage"), f));
                    let r = e.enraged ? 1.5 : 1;
                    for (let t of (e.vy += .5, e.vy > 10 && (e.vy = 10), e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    let n = e.patternTimer % 360,
                      h = 0;
                    if (n < 120 ? (h = a.x > e.x ? 1 : -1, e.vx = 2.5 * h * r) : e.vx = 0, e.grounded && 0 !==
                      h && !eK(e.x, e.y, h, T, l, e.width) && (e.vx = 0, e.facing = -1 * e.facing), e.x += e
                      .vx, n >= 120 && n < 240) {
                      if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0) {
                        let t = a.x - e.x,
                          o = a.y - 25 - (e.y - 40),
                          l = Math.sqrt(t * t + o * o);
                        if (l > 0)
                          for (let a = -.3; a <= .31; a += .15) {
                            let r = Math.cos(a),
                              n = Math.sin(a),
                              h = "bossDragon" === e.type ? c : "bossPhoenix" === e.type ? d :
                              "bossMechGolem" === e.type ? s : i;
                            C.push({
                              x: e.x + e.width / 2,
                              y: e.y - 40,
                              vx: (t / l * r - o / l * n) * 5.5,
                              vy: (t / l * n + o / l * r) * 5.5,
                              fromPlayer: !1,
                              damage: 10,
                              active: !0,
                              color: h,
                              radius: 4
                            })
                          }
                        e.shootCooldown = 25 / r
                      }
                    } else if (n >= 240 && (240 === n && e.grounded && (e.vy = -14), 300 === n && e
                        .grounded && t < 130)) {
                      a.invincible <= 0 && !a.isShielding && (a.health -= 15, a.invincible = 40, a
                        .expression = "hurt", eU(S, a.x + a.width / 2, a.y - 25, 10, f), X.current = 12,
                        eZ(), eo.playHit());
                      for (let t = 0; t < 20; t++) S.push({
                        x: e.x + e.width / 2 + (Math.random() - .5) * 150,
                        y: e.y,
                        vx: (Math.random() - .5) * 4,
                        vy: -(5 * Math.random()),
                        life: 30,
                        maxLife: 30,
                        color: c,
                        size: 3
                      })
                    }
                    e.y += e.vy, e.animFrame++;
                    break
                  }
                  case "dragon":
                    if (e.vy += .15, e.vy > 3 && (e.vy = 3), t < 500 ? (e.vx = (a.x > e.x ? 1 : -1) * 2, e
                        .facing = e.vx > 0 ? 1 : -1, e.y - 25 > a.y - 40 && (e.vy -= .5), e.y - 25 < a.y -
                        60 && (e.vy += .3)) : (e.vx = +e.facing, e.vy += .3 * Math.sin(.05 * e.animFrame)), e
                      .x += e.vx, e.y += e.vy, e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t <
                      400) {
                      for (let t = -.15; t <= .16; t += .15) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 20,
                        vx: 5.5 * e.facing * Math.cos(t),
                        vy: 2 * Math.sin(t) - 1,
                        fromPlayer: !1,
                        damage: 10,
                        active: !0,
                        color: c,
                        radius: 4
                      });
                      e.shootCooldown = 50
                    }
                    e.animFrame++;
                    break;
                  case "phoenix":
                    e.vy += .125, e.vy > 3 && (e.vy = 3), t < 500 ? (e.vx = (a.x > e.x ? 1 : -1) * 2.5, e
                        .facing = e.vx > 0 ? 1 : -1, e.y - 25 > a.y - 30 && (e.vy -= .6), e.y - 25 < a.y -
                        70 && (e.vy += .4)) : (e.vx = 1.5 * e.facing, e.vy += .4 * Math.sin(.06 * e
                        .animFrame)), e.x += e.vx, e.y += e.vy, e.shootCooldown -= (eG ? 2 : 1), e
                      .shootCooldown <= 0 && t < 450 && (C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 15,
                        vx: 6.5 * e.facing,
                        vy: 1,
                        fromPlayer: !1,
                        damage: 8,
                        active: !0,
                        color: d,
                        radius: 3
                      }), e.shootCooldown = 35), e.animFrame++;
                    break;
                  case "mechGolem":
                    for (let o of (t < 500 ? (e.vx = (a.x > e.x ? 1 : -1) * 1.2, e.facing = e.vx > 0 ? 1 : -
                        1) : e.vx = .8 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                          .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 450) {
                      for (let t = -.1; t <= .11; t += .2) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 30,
                        vx: 5.5 * e.facing * Math.cos(t),
                        vy: -2 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 12,
                        active: !0,
                        color: s,
                        radius: 4
                      });
                      e.shootCooldown = 60
                    }
                    e.animFrame++;
                    break;
                  case "shadowAssassin":
                    if (t < 500) {
                      let t = 3.5 + +Math.sin(.15 * e.animFrame);
                      e.vx = (a.x > e.x ? 1 : -1) * t, e.facing = e.vx > 0 ? 1 : -1
                    } else e.vx = 2 * e.facing;
                    for (let t of (e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e.width) && (e.vx = 0,
                          e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy = 10), e.x += e.vx, e
                        .y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 200 && (C.push({
                      x: e.x + e.width / 2,
                      y: e.y - 25,
                      vx: 8.5 * e.facing,
                      vy: 0,
                      fromPlayer: !1,
                      damage: 14,
                      active: !0,
                      color: h,
                      radius: 3
                    }), e.shootCooldown = 25), e.animFrame++;
                    break;
                  case "eliteDrone":
                    for (let o of (t < 600 ? (e.vx = e.x > a.x ? -2 : 2, e.facing = e.vx > 0 ? 1 : -1) : e
                        .vx = 1.2 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                        .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 500) {
                      let t = a.x - e.x,
                        o = a.y - 25 - (e.y - 25),
                        l = Math.sqrt(t * t + o * o);
                      l > 0 && C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 25,
                        vx: t / l * 6,
                        vy: o / l * 6,
                        fromPlayer: !1,
                        damage: 12,
                        active: !0,
                        color: f,
                        radius: 3
                      }), e.shootCooldown = 35
                    }(e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.animFrame++;
                    break;
                  case "heavyWalker":
                    for (let o of (t < 500 ? (e.vx = (a.x > e.x ? 1 : -1) * 1, e.facing = e.vx > 0 ? 1 : -1) :
                        e.vx = .6 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                        .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 450) {
                      for (let t = -.15; t <= .16; t += .15) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 30,
                        vx: 4.5 * e.facing * Math.cos(t),
                        vy: -1.5 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 14,
                        active: !0,
                        color: c,
                        radius: 4
                      });
                      e.shootCooldown = 70
                    }(e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.animFrame++;
                    break;
                  case "bossCorrupted": {
                    e.facing = e.x > a.x ? -1 : 1, e.patternTimer++;
                    let t = Math.min(.5 + (eA.current - 1) * .15, .75);
                    e.health < e.maxHealth * t && !e.enraged && (e.enraged = !0, X.current = 15, eU(S, e.x + e
                      .width / 2, e.y - 40, 30, h), eZ(), eo.playBossEnrage());
                    let o = e.enraged ? 1.5 : 1;
                    for (let t of (e.vy += .5, e.vy > 10 && (e.vy = 10), e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    let r = e.patternTimer % 300,
                      n = 0;
                    if (r < 100 ? (n = a.x > e.x ? 1 : -1, e.vx = 2 * n * o) : e.vx = 0, e.grounded && 0 !==
                      n && !eK(e.x, e.y, n, T, l, e.width) && (e.vx = 0, e.facing = -1 * e.facing), e.x += e
                      .vx, r >= 100 && r < 200) {
                      if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0) {
                        for (let t = -.4; t <= .41; t += .2) C.push({
                          x: e.x + e.width / 2,
                          y: e.y - 40,
                          vx: 5 * e.facing * Math.cos(t),
                          vy: 3 * Math.sin(t),
                          fromPlayer: !1,
                          damage: 10,
                          active: !0,
                          color: h,
                          radius: 4
                        });
                        e.shootCooldown = 25 / o
                      }
                    } else r >= 200 && 200 === r && e.grounded && (e.vy = -13);
                    e.y += e.vy, e.animFrame++;
                    break
                  }
                  case "bossFather": {
                    e.facing = e.x > a.x ? -1 : 1, e.patternTimer++;
                    let t = Math.min(.4 + (eA.current - 1) * .15, .7);
                    e.health < e.maxHealth * t && !e.enraged && (e.enraged = !0, X.current = 15, eU(S, e.x + e
                      .width / 2, e.y - 40, 30, n), eZ(), eo.playBossEnrage());
                    let o = e.enraged ? 1.6 : 1;
                    for (let t of (e.vy += .5, e.vy > 10 && (e.vy = 10), e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    let r = e.patternTimer % 360,
                      i = 0;
                    if (r < 80) i = a.x > e.x ? 1 : -1, e.vx = 2.5 * i * o;
                    else if (r >= 80 && r < 120) 80 === r && eU(S, e.x + e.width / 2, e.y - 25, 10, n), i = a
                      .x > e.x ? 1 : -1, e.vx = 8 * i * o, F.current % 3 == 0 && eU(S, e.x + e.width / 2, e
                        .y - 25, 2, n);
                    else if (r >= 120 && r < 220) {
                      if (e.vx = 0, e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0) {
                        for (let t = -.6; t <= .61; t += .15) C.push({
                          x: e.x + e.width / 2,
                          y: e.y - 30,
                          vx: 6 * e.facing * Math.cos(t) * o,
                          vy: 4 * Math.sin(t),
                          fromPlayer: !1,
                          damage: 8,
                          active: !0,
                          color: n,
                          radius: 4
                        });
                        e.shootCooldown = 50 / o
                      }
                    } else {
                      if (220 === r && e.grounded && (e.vy = -14, eU(S, e.x + e.width / 2, e.y, 15, n)), r >
                        240 && e.grounded) {
                        X.current = 12;
                        for (let t = -3; t <= 3; t++) C.push({
                          x: e.x + e.width / 2 + 20 * t,
                          y: e.y - 5,
                          vx: 2.5 * t,
                          vy: -2,
                          fromPlayer: !1,
                          damage: 12,
                          active: !0,
                          color: n,
                          radius: 5
                        });
                        eU(S, e.x + e.width / 2, e.y, 20, n)
                      }
                      e.vx = a.x > e.x ? 1.5 : -1.5
                    }
                    e.grounded && 0 !== i && !eK(e.x, e.y, i, T, l, e.width) && (e.vx = 0, e.facing = -1 * e
                        .facing), e.x += e.vx, e.y += e.vy, e.x < 10 && (e.x = 10), e.x + e.width > l.width &&
                      (e.x = l.width - e.width), e.animFrame++;
                    break
                  }
                  case "bossTwin": {
                    e.facing = e.x > a.x ? -1 : 1, e.patternTimer++;
                    let t = Math.min(.4 + (eA.current - 1) * .15, .7);
                    e.health < e.maxHealth * t && !e.enraged && (e.enraged = !0, X.current = 15, eU(S, e.x + e
                      .width / 2, e.y - 40, 30, p), eZ(), eo.playBossEnrage());
                    let o = e.enraged ? 1.8 : 1;
                    for (let t of (e.vy += .5, e.vy > 10 && (e.vy = 10), e.grounded = !1, T)) {
                      let {
                        px: o,
                        py: a
                      } = eV(t);
                      e.x + e.width > o && e.x < o + t.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    let r = e.patternTimer % 400,
                      n = 0;
                    if (r < 60) n = a.x > e.x ? 1 : -1, e.vx = 10 * n * o, F.current % 2 == 0 && eU(S, e.x + e
                      .width / 2, e.y - 25, 2, p);
                    else if (r >= 60 && r < 180) {
                      if (e.vx = 0, e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0) {
                        for (let t = -.5; t <= .51; t += .12) C.push({
                          x: e.x + e.width / 2,
                          y: e.y - 30,
                          vx: 7 * e.facing * Math.cos(t) * o,
                          vy: 3 * Math.sin(t),
                          fromPlayer: !1,
                          damage: 7,
                          active: !0,
                          color: p,
                          radius: 4
                        });
                        e.shootCooldown = Math.floor(62.5 / o)
                      }
                    } else if (r >= 180 && r < 260) e.vx = 0, 180 === r && eU(S, e.x + e.width / 2, e.y - 25,
                      15, "#4488ff"), F.current % 4 == 0 && eU(S, e.x + e.width / 2, e.y - 25, 1, "#88bbff");
                    else {
                      if (260 === r && e.grounded && (e.vy = -15, eU(S, e.x + e.width / 2, e.y, 15, p)), e
                        .vx = a.x > e.x ? 2 : -2, !e.grounded && F.current % 12 == 0)
                        for (let t = -.3; t <= .31; t += .15) C.push({
                          x: e.x + e.width / 2,
                          y: e.y - 30,
                          vx: 6 * e.facing * Math.cos(t),
                          vy: 4 * Math.sin(t),
                          fromPlayer: !1,
                          damage: 6,
                          active: !0,
                          color: "#88bbff",
                          radius: 3
                        });
                      if (r > 300 && e.grounded) {
                        X.current = 10;
                        for (let t = -4; t <= 4; t++) C.push({
                          x: e.x + e.width / 2 + 15 * t,
                          y: e.y - 5,
                          vx: 2 * t,
                          vy: -3,
                          fromPlayer: !1,
                          damage: 10,
                          active: !0,
                          color: p,
                          radius: 4
                        });
                        eU(S, e.x + e.width / 2, e.y, 25, p)
                      }
                    }
                    e.grounded && 0 !== n && !eK(e.x, e.y, n, T, l, e.width) && (e.vx = 0, e.facing = -1 * e
                        .facing), e.x += e.vx, e.y += e.vy, e.x < 10 && (e.x = 10), e.x + e.width > l.width &&
                      (e.x = l.width - e.width), e.animFrame++;
                    break
                  }
                  case "voidBat":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 3;
                      let t = a.y - 60;
                      e.vy += (t - e.y) * .02
                    } else e.vx = 2 * e.facing, e.vy = 1.5 * Math.sin(.08 * e.animFrame);
                    e.vy += .3 * Math.sin(.12 * e.animFrame), e.vy > 4 && (e.vy = 4), e.vy < -4 && (e.vy = -
                      4), e.x += e.vx, e.y += e.vy, e.y < 40 && (e.y = 40), e.y > l.height - 50 && (e.y = l
                        .height - 50), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 400 && (C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 10,
                        vx: 5 * e.facing,
                        vy: .5,
                        fromPlayer: !1,
                        damage: 5,
                        active: !0,
                        color: i,
                        radius: 2
                      }), e.shootCooldown = 40), e.animFrame++;
                    break;
                  case "stormEagle":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2;
                      let t = a.y - 80;
                      e.vy += (t - e.y) * .015
                    } else e.vx = 1.5 * e.facing, e.vy = 1.2 * Math.sin(.06 * e.animFrame);
                    if (e.vy += .2 * Math.sin(.1 * e.animFrame), e.vy > 3 && (e.vy = 3), e.vy < -3 && (e
                        .vy = -3), e.x += e.vx, e.y += e.vy, e.y < 50 && (e.y = 50), e.y > l.height - 60 && (e
                        .y = l.height - 60), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 450) {
                      let t = a.x - e.x,
                        o = a.y - 25 - (e.y - 20),
                        l = Math.sqrt(t * t + o * o);
                      l > 0 && C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 20,
                        vx: t / l * 8,
                        vy: o / l * 8,
                        fromPlayer: !1,
                        damage: 10,
                        active: !0,
                        color: d,
                        radius: 4
                      }), e.shootCooldown = 60
                    }
                    e.animFrame++;
                    break;
                  case "emberWisp":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2.5;
                      let t = a.y - 50 + 30 * Math.sin(.1 * e.animFrame);
                      e.vy += (t - e.y) * .02
                    } else e.vx = 1.5 * e.facing, e.vy = 1.5 * Math.sin(.1 * e.animFrame);
                    e.vy += .4 * Math.sin(.15 * e.animFrame), e.vy > 4 && (e.vy = 4), e.vy < -4 && (e.vy = -
                      4), e.x += e.vx, e.y += e.vy, e.y < 30 && (e.y = 30), e.y > l.height - 50 && (e.y = l
                        .height - 50), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 400 && (C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 8,
                        vx: 5 * e.facing,
                        vy: 1,
                        fromPlayer: !1,
                        damage: 7,
                        active: !0,
                        color: c,
                        radius: 3
                      }), e.shootCooldown = 35), e.animFrame++;
                    break;
                  case "frostWraith":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 1.8;
                      let t = a.y - 70;
                      e.vy += (t - e.y) * .012
                    } else e.vx = +e.facing, e.vy = +Math.sin(.07 * e.animFrame);
                    if (e.vy += .3 * Math.sin(.09 * e.animFrame), e.vy > 3 && (e.vy = 3), e.vy < -3 && (e
                        .vy = -3), e.x += e.vx, e.y += e.vy, e.y < 40 && (e.y = 40), e.y > l.height - 60 && (e
                        .y = l.height - 60), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 450) {
                      for (let t = -.2; t <= .21; t += .2) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 20,
                        vx: 4 * e.facing * Math.cos(t),
                        vy: 2 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 8,
                        active: !0,
                        color: "#88eeff",
                        radius: 3
                      });
                      e.shootCooldown = 65
                    }
                    e.animFrame++;
                    break;
                  case "shadowDrake":
                    if (e.facing = e.x > a.x ? -1 : 1, e.vy += .1, e.vy > 3 && (e.vy = 3), t < 600) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2.5;
                      let t = a.y - 80;
                      e.vy += (t - e.y) * .015
                    } else e.vx = 1.5 * e.facing, e.vy += .4 * Math.sin(.07 * e.animFrame);
                    if (e.x += e.vx, e.y += e.vy, e.y < 30 && (e.y = 30), e.y > l.height - 60 && (e.y = l
                        .height - 60), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 400) {
                      for (let t = -.15; t <= .16; t += .15) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 20,
                        vx: 5 * e.facing * Math.cos(t),
                        vy: 1.5 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 9,
                        active: !0,
                        color: h,
                        radius: 3
                      });
                      e.shootCooldown = 50
                    }
                    e.animFrame++;
                    break;
                  case "plasmaSerpent":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2.2;
                      let t = a.y - 65;
                      e.vy += (t - e.y) * .018
                    } else e.vx = 1.5 * e.facing, e.vy = 1.5 * Math.sin(.08 * e.animFrame);
                    if (e.vy += .5 * Math.sin(.12 * e.animFrame), e.vy > 4 && (e.vy = 4), e.vy < -4 && (e
                        .vy = -4), e.x += e.vx, e.y += e.vy, e.y < 30 && (e.y = 30), e.y > l.height - 60 && (e
                        .y = l.height - 60), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 450) {
                      let t = a.x - e.x,
                        o = a.y - 25 - (e.y - 20),
                        l = Math.sqrt(t * t + o * o);
                      l > 0 && C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 15,
                        vx: t / l * 6,
                        vy: o / l * 6,
                        fromPlayer: !1,
                        damage: 10,
                        active: !0,
                        color: i,
                        radius: 4
                      }), e.shootCooldown = 55
                    }
                    e.animFrame++;
                    break;
                  case "neonWyrm":
                    if (e.facing = e.x > a.x ? -1 : 1, e.vy += .075, e.vy > 3 && (e.vy = 3), t < 600) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2;
                      let t = a.y - 90;
                      e.vy += (t - e.y) * .01
                    } else e.vx = +e.facing, e.vy += .5 * Math.sin(.06 * e.animFrame);
                    if (e.x += e.vx, e.y += e.vy, e.y < 40 && (e.y = 40), e.y > l.height - 70 && (e.y = l
                        .height - 70), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 500) {
                      for (let t = -.3; t <= .31; t += .15) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 25,
                        vx: 5 * e.facing * Math.cos(t),
                        vy: 2 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 12,
                        active: !0,
                        color: n,
                        radius: 4
                      });
                      e.shootCooldown = 70
                    }
                    e.animFrame++;
                    break;
                  case "crystalMoth":
                    if (e.facing = e.x > a.x ? -1 : 1, t < 500) {
                      e.vx = (a.x > e.x ? 1 : -1) * 2;
                      let t = a.y - 55 + 25 * Math.sin(.08 * e.animFrame);
                      e.vy += (t - e.y) * .02
                    } else e.vx = +e.facing, e.vy = +Math.sin(.1 * e.animFrame);
                    if (e.vy += .3 * Math.sin(.13 * e.animFrame), e.vy > 3 && (e.vy = 3), e.vy < -3 && (e
                        .vy = -3), e.x += e.vx, e.y += e.vy, e.y < 30 && (e.y = 30), e.y > l.height - 50 && (e
                        .y = l.height - 50), (e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e
                      .shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0 && t < 400) {
                      for (let t = -.25; t <= .26; t += .25) C.push({
                        x: e.x + e.width / 2,
                        y: e.y - 12,
                        vx: 4.5 * e.facing * Math.cos(t),
                        vy: 1.5 * Math.sin(t),
                        fromPlayer: !1,
                        damage: 6,
                        active: !0,
                        color: s,
                        radius: 3
                      });
                      e.shootCooldown = 50
                    }
                    e.animFrame++;
                    break;
                  case "zombie":
                    for (let o of (t < 600 ? (e.vx = a.x > e.x ? 1.2 : -1.2, e.facing = e.vx > 0 ? 1 : -1) : e
                        .vx = .8 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                        .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }(e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.shootCooldown -= (eG ?
                      2 : 1), e.shootCooldown <= 0 && t < 80 && (C.push({
                      x: e.x + e.width / 2,
                      y: e.y - 25,
                      vx: 3 * e.facing,
                      vy: 0,
                      fromPlayer: !1,
                      damage: 8,
                      active: !0,
                      color: "#44aa44",
                      radius: 4
                    }), e.shootCooldown = 50), e.animFrame++;
                    break;
                  case "bomber":
                    for (let o of (t < 500 ? (e.vx = a.x > e.x ? 2.5 : -2.5, e.facing = e.vx > 0 ? 1 : -1) : e
                        .vx = 1.5 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                        .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if ((e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), t < 60 && e.active) {
                      if (eU(S, e.x + e.width / 2, e.y - 20, 20, c), eU(S, e.x + e.width / 2, e.y - 20, 15,
                        f), X.current = 8, a.invincible <= 0) {
                        let e = L <= 3 ? 3 : L <= 50 ? 8 : 12;
                        a.health -= e, a.invincible = 40
                      }
                      e.active = !1, e.health = 0
                    }
                    e.animFrame++;
                    break;
                  case "necromancer":
                    for (let o of (e.facing = e.x > a.x ? -1 : 1, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -
                          1, T, l, e.width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy >
                        10 && (e.vy = 10), t < 400 ? e.vx = (a.x > e.x ? 1 : -1) * .5 : e.vx = .3 * e
                        .facing, e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if ((e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.shootCooldown -= (
                        eG ? 2 : 1), e.shootCooldown <= 0 && t < 500) {
                      let t = .5 * e.animFrame;
                      for (let o = 0; o < 3; o++) {
                        let a = t + o / 3 * Math.PI * 2;
                        C.push({
                          x: e.x + e.width / 2,
                          y: e.y - 25,
                          vx: 4 * Math.cos(a),
                          vy: 3 * Math.sin(a),
                          fromPlayer: !1,
                          damage: 7,
                          active: !0,
                          color: h,
                          radius: 3
                        })
                      }
                      e.shootCooldown = 55
                    }
                    e.animFrame++;
                    break;
                  case "giant":
                    for (let o of (t < 500 ? (e.vx = a.x > e.x ? .8 : -.8, e.facing = e.vx > 0 ? 1 : -1) : e
                        .vx = .5 * e.facing, e.grounded && !eK(e.x, e.y, e.vx > 0 ? 1 : -1, T, l, e
                        .width) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e.vy =
                          10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                      let {
                        px: t,
                        py: a
                      } = eV(o);
                      e.x + e.width > t && e.x < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                        Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                    }
                    if ((e.x < 10 || e.x > l.width - 30) && (e.facing = -1 * e.facing), e.shootCooldown -= (
                        eG ? 2 : 1), e.shootCooldown <= 0 && t < 300) {
                      for (let t = -2; t <= 2; t++) C.push({
                        x: e.x + e.width / 2 + 15 * t,
                        y: e.y - 5,
                        vx: 2 * t,
                        vy: -2,
                        fromPlayer: !1,
                        damage: 12,
                        active: !0,
                        color: c,
                        radius: 5
                      });
                      eU(S, e.x + e.width / 2, e.y, 15, c), X.current = 8, e.shootCooldown = 80
                    }
                    e.animFrame++
                }
                if (e.y > l.height + 100)
                  if ("boss" === e.type || "bossRedKing" === e.type || "bossTitan" === e.type ||
                    "bossDragon" === e.type || "bossPhoenix" === e.type || "bossMechGolem" === e.type ||
                    "bossCorrupted" === e.type || "bossFather" === e.type || "bossTwin" === e.type) {
                    let t = T[0],
                      o = 1 / 0;
                    for (let e of T) {
                      let {
                        px: l,
                        py: r
                      } = eV(e), n = Math.abs(l + e.width / 2 - a.x);
                      n < o && r < 530 && (o = n, t = e)
                    }
                    let {
                      px: l,
                      py: r
                    } = eV(t);
                    e.x = l + t.width / 2 - e.width / 2, e.y = r, e.vy = 0, e.grounded = !1, e.invincible = 60
                  } else e.active = !1;
                if (a.invincible <= 0 && !a.isShielding && e.active) {
                  let t = ez(e.type);
                  if (eO(a.x, a.y - a.height, a.width, a.height, e.x, e.y - t, e.width, t)) {
                    let t = L <= 3 ? 2 : L <= 50 ? "boss" === e.type ? 8 : 5 : "boss" === e.type ? 15 : 10;
                    a.health -= t, a.invincible = 40, a.expression = "hurt", eU(S, a.x + a.width / 2, a.y -
                        25, 8, f), X.current = L <= 3 ? 2 : 5, a.vx += a.x < e.x ? -6 : 6, eZ(), eo
                      .playDamage()
                  }
                }
                if (G && G.health > 0 && G.invincible <= 0 && !G.isShielding && e.active) {
                  let t = ez(e.type);
                  eO(G.x, G.y - G.height, G.width, G.height, e.x, e.y - t, e.width, t) && (G.health -=
                    "boss" === e.type ? 15 : 10, G.invincible = 40, G.expression = "hurt", eU(S, G.x + G
                      .width / 2, G.y - 25, 8, f), X.current = 5, G.vx += G.x < e.x ? -6 : 6, eZ(), eo
                    .playDamage())
                }
              }
              for (let e of es.current) {
                if (!e.active) continue;
                let t = Math.abs(e.x - a.x);
                for (let o of (t > 60 ? (e.vx = (a.x > e.x ? 1 : -1) * 4, e.facing = e.vx > 0 ? 1 : -1) : (e
                    .vx = 0, e.facing = a.facing), e.grounded && 0 !== e.vx && !eK(e.x, e.y, e.vx > 0 ?
                    1 : -1, T, l, 30) && (e.vx = 0, e.facing = -1 * e.facing), e.vy += .5, e.vy > 10 && (e
                    .vy = 10), e.x += e.vx, e.y += e.vy, e.grounded = !1, T)) {
                  let {
                    px: t,
                    py: a
                  } = eV(o);
                  e.x + 15 > t && e.x - 15 < t + o.width && e.y >= a - 4 && e.y - e.vy <= a + Math.max(10,
                    Math.abs(e.vy) + 8) && (e.y = a, e.vy = 0, e.grounded = !0)
                }
                if (e.y > l.height + 50 && (e.x = a.x - 40, e.y = a.y, e.vy = 0, e.grounded = !1, e
                    .invincible = 30), e.grounded && (!a.grounded || e.x < 10 || e.x > l.width - 30)) {
                  let t = a.x > e.x ? 1 : -1;
                  eK(e.x, e.y, t, T, l, 30) ? (e.vy = -10.2, e.grounded = !1) : a.y < e.y - 60 && (e.vy = -
                    10.2, e.grounded = !1)
                }
                if (e.shootCooldown -= (eG ? 2 : 1), e.shootCooldown <= 0) {
                  let t = k.find(t => t.active && 400 > Math.abs(t.x - e.x));
                  if (t) {
                    let o = t.x - e.x,
                      a = t.y - 25 - (e.y - 25),
                      l = Math.sqrt(o * o + a * a);
                    l > 0 && (C.push({
                        x: e.x,
                        y: e.y - 25,
                        vx: o / l * 7,
                        vy: a / l * 7,
                        fromPlayer: !0,
                        damage: 8,
                        active: !0,
                        color: e.color,
                        radius: 3,
                        fromGangMember: e.id
                      }), eU(S, e.x + 15 * e.facing, e.y - 25, 2, e.color)), e.shootCooldown = 50 + Math
                      .floor(30 * Math.random())
                  }
                }
                for (let t of (e.animFrame++, e.invincible > 0 && (e.invincible -= (eG ? 2 : 1)), k)) t
                  .active && e.invincible <= 0 && eO(e.x - 10, e.y - 45, 20, 45, t.x, t.y - ez(t.type), t
                    .width, ez(t.type)) && (e.health -= 10, e.invincible = 40, e.expression = "hurt", eU(S, e
                    .x, e.y - 25, 5, e.color));
                e.health <= 0 && (e.active = !1, eU(S, e.x, e.y - 25, 15, e.color)), e.expression = e
                  .shootCooldown < 20 ? "angry" : t < 200 ? "determined" : "neutral"
              }
              let _ = ec.current;
              if (_ && _.active) {
                let e = Math.abs(_.x - a.x),
                  t = a.y - _.y,
                  o = a.x - 30 * a.facing,
                  r = o > _.x ? 1 : o < _.x ? -1 : 0,
                  i = !1;
                for (let n of (_.grounded && 0 !== r && (i = !eK(_.x, _.y, r, T, l, 20)), i ? _.grounded &&
                    e > 60 && (_.vy = -10.8, _.grounded = !1) : (_.x += (o - _.x) * (e > 80 ? .12 : .06),
                      e > 80 && (_.x += (o - _.x) * .08)), e > 30 ? _.facing = a.x > _.x ? 1 : -1 : _
                    .facing = a.facing, _.vy += .25, _.vy > 6 && (_.vy = 6), t < -60 && _.grounded && (_
                      .vy = -10.2, _.grounded = !1), _.y += _.vy, _.grounded = !1, T)) {
                  let {
                    px: e,
                    py: t
                  } = eV(n);
                  _.x + 10 > e && _.x - 10 < e + n.width && _.y >= t && _.y - _.vy <= t + 4 && (_.y = t, _
                    .vy = 0, _.grounded = !0)
                }
                if (_.y > l.height + 50 && (_.x = a.x + 30, _.y = a.y - 20, _.vy = 0, _.grounded = !1, _
                    .invincible = 30), _.x < 0 && (_.x = 0), _.x > l.width && (_.x = l.width), _
                  .shootCooldown -= (eG ? 2 : 1), _.shootCooldown <= 0) {
                  let e = k.find(e => e.active && 350 > Math.abs(e.x - _.x));
                  if (e) {
                    let t = e.x - _.x,
                      o = e.y - 20 - (_.y - 15),
                      a = Math.sqrt(t * t + o * o);
                    if (a > 0) {
                      let e = v.find(e => e.id === _.type) || v[0];
                      C.push({
                        x: _.x,
                        y: _.y - 15,
                        vx: t / a * 6,
                        vy: o / a * 6,
                        fromPlayer: !0,
                        damage: e.damage,
                        active: !0,
                        color: _.skinColor,
                        radius: 3,
                        fromPet: !0
                      }), eU(S, _.x + 10 * _.facing, _.y - 15, 2, _.skinColor), eZ(), eo.playPetShoot()
                    }
                    _.shootCooldown = v.find(e => e.id === _.type)?.shootRate || 45
                  }
                }
                for (let e of (_.animFrame++, _.invincible > 0 && _.invincible--, k)) e.active && _
                  .invincible <= 0 && eO(_.x - 8, _.y - 20, 16, 20, e.x, e.y - ez(e.type), e.width, ez(e
                    .type)) && (_.health -= 8, _.invincible = 40, eU(S, _.x, _.y - 10, 5, _.skinColor), eZ(),
                    eo.playDamage());
                _.health <= 0 && (_.active = !1, _.respawnTimer = 600, eU(S, _.x, _.y - 15, 15, _.skinColor),
                  eZ(), eo.playPetDeath(), e4("", n))
              } else _ && !_.active && (_.respawnTimer--, _.respawnTimer <= 0 && (_.active = !0, _.health = _
                .maxHealth, _.x = a.x + 30, _.y = a.y - 20, _.invincible = 60, eZ(), eo.playPetRespawn(),
                e4("", s)));
              let K = ea.getState().currentLevel;
              K <= 3 ? a.health < a.maxHealth && (a.health = Math.min(a.maxHealth, a.health + 2)) : K <= 50 &&
                a.health < a.maxHealth && F.current % 30 == 0 && (a.health = Math.min(a.maxHealth, a.health +
                  1)), ef.current--, ef.current <= 0 && (ef.current = 600, a.health > 0 && a.health < .25 * a
                  .maxHealth && ea.getState().triggerDramaticMoment("Stay with me! We're not done!", f), k
                  .find(e => e.active && ("boss" === e.type || "bossRedKing" === e.type || "bossTitan" === e
                      .type || "bossDragon" === e.type || "bossPhoenix" === e.type || "bossMechGolem" === e
                      .type || "bossCorrupted" === e.type || "bossFather" === e.type || "bossTwin" === e.type
                      ) && e.health < .25 * e.maxHealth) && ea.getState().triggerDramaticMoment("FINISH HIM!",
                    m));
              let q = ew.current;
              for (let t of C) {
                if (!t.active) continue;
                if (t.x += t.vx * q, t.y += t.vy * q, t.x < $.current - 50 || t.x > $.current + e + 50 || t
                  .y < -50 || t.y > l.height + 50) {
                  t.active = !1;
                  continue
                }
                let o = !1;
                for (let e of T) {
                  let {
                    px: a,
                    py: l
                  } = eV(e);
                  if (t.x + t.radius > a && t.x - t.radius < a + e.width && t.y + t.radius > l && t.y - t
                    .radius < l + e.height) {
                    o = !0;
                    break
                  }
                }
                if (o) {
                  t.active = !1, eU(S, t.x, t.y, 5, t.color);
                  continue
                }
                if (t.fromPlayer)
                  for (let e of k) {
                    if (!e.active) continue;
                    let o = ez(e.type);
                    if (eO(t.x - t.radius, t.y - t.radius, 2 * t.radius, 2 * t.radius, e.x, e.y - o, e.width,
                        o)) {
                      e.health -= t.damage, e.isHit = !0, e.hitTimer = 5, e.vx += (t.vx > 0 ? 3 : -3), t
                        .active = !1, eU(S, t.x, t.y, 8, t.color), X.current = 3;
                      let o = "boss" === e.type || "bossRedKing" === e.type || "bossTitan" === e.type ||
                        "bossDragon" === e.type || "bossPhoenix" === e.type || "bossMechGolem" === e.type ||
                        "bossCorrupted" === e.type || "bossFather" === e.type || "bossTwin" === e.type;
                      if (eZ(), eo.playHit(), e.health <= 0) {
                        e.active = !1;
                        let t = "boss" === e.type ? 500 : "voidGuardian" === e.type ? 150 : 100;
                        if (z.current += t, en.current++, ei.current = 120, en.current > 2 && (z.current +=
                            10 * en.current), o) {
                          eU(S, e.x + e.width / 2, e.y - 25, 60, i), eU(S, e.x + e.width / 2, e.y - 25, 40,
                            f), eU(S, e.x + e.width / 2, e.y - 25, 30, c), eU(S, e.x + e.width / 2, e.y - 25,
                              20, d), X.current = 20;
                          let t = e.bossName || "BOSS";
                          e6(`${t} DEFEATED!`, m)
                        } else eU(S, e.x + e.width / 2, e.y - 25, 15, c), X.current = 5;
                        a.expression = "victory", o ? (eo.stopBossMusic(), eo.startMusic(), eo
                        .playExplosion()) : eo.playEnemyDeath(), .25 > Math.random() && e4(e_("kill"), n)
                      }
                      break
                    }
                  } else {
                    if (a.isShielding) eO(t.x - t.radius, t.y - t.radius, 2 * t.radius, 2 * t.radius, a.x -
                      10, a.y - a.height - 10, a.width + 20, a.height + 20) && (t.active = !1, eU(S, t.x, t
                      .y, 5, s));
                    else if (a.invincible <= 0 && eO(t.x - t.radius, t.y - t.radius, 2 * t.radius, 2 * t
                        .radius, a.x, a.y - a.height, a.width, a.height)) {
                      let e = L <= 3 ? 2 : L <= 50 ? 5 : 10;
                      a.health -= Math.min(t.damage, e), a.invincible = 40, a.expression = "hurt", t
                        .active = !1, eU(S, t.x, t.y, 8, f), X.current = 4, eZ(), eo.playDamage(), .3 > Math
                        .random() && e4(e_("damage"), f)
                    }
                    G && G.health > 0 && t.active && (G.isShielding ? eO(t.x - t.radius, t.y - t.radius, 2 * t
                        .radius, 2 * t.radius, G.x - 10, G.y - G.height - 10, G.width + 20, G.height + 20
                        ) && (t.active = !1, eU(S, t.x, t.y, 5, s)) : G.invincible <= 0 && eO(t.x - t
                        .radius, t.y - t.radius, 2 * t.radius, 2 * t.radius, G.x, G.y - G.height, G.width, G
                        .height) && (G.health -= t.damage, G.invincible = 40, G.expression = "hurt", t
                        .active = !1, eU(S, t.x, t.y, 8, f), X.current = 4, eZ(), eo.playDamage()))
                  }
                R && t.active && t.fromPlayer && t.fromPlayerId && (1 === t.fromPlayerId && G && G.health >
                  0 ? G.isShielding ? eO(t.x - t.radius, t.y - t.radius, 2 * t.radius, 2 * t.radius, G.x -
                    10, G.y - G.height - 10, G.width + 20, G.height + 20) && (t.active = !1, eU(S, t.x, t.y,
                    5, s), a.invincible <= 0 && (a.health -= 3, a.invincible = 20)) : G.invincible <= 0 &&
                  eO(t.x - t.radius, t.y - t.radius, 2 * t.radius, 2 * t.radius, G.x, G.y - G.height, G
                    .width, G.height) && (G.health -= t.damage, G.invincible = 40, G.expression = "hurt", t
                    .active = !1, eU(S, t.x, t.y, 10, c), X.current = 5, eZ(), eo.playDamage()) : 2 === t
                  .fromPlayerId && a.health > 0 && (a.isShielding ? eO(t.x - t.radius, t.y - t.radius, 2 * t
                      .radius, 2 * t.radius, a.x - 10, a.y - a.height - 10, a.width + 20, a.height + 20) &&
                    (t.active = !1, eU(S, t.x, t.y, 5, s), G && G.invincible <= 0 && (G.health -= 3, G
                      .invincible = 20)) : a.invincible <= 0 && eO(t.x - t.radius, t.y - t.radius, 2 * t
                      .radius, 2 * t.radius, a.x, a.y - a.height, a.width, a.height) && (a.health -= t
                      .damage, a.invincible = 40, a.expression = "hurt", t.active = !1, eU(S, t.x, t.y, 10,
                        n), X.current = 5, eZ(), eo.playDamage())))
              }
              for (let e of (D.current = C.filter(e => e.active), D.current.length > 100 && (D.current = D
                  .current.slice(-100)), F.current % 120 == 0 && eS.current.active && (I.current = I
                  .current.filter(e => e.active)), S)) e.x += e.vx, e.y += e.vy, e.vy += .05, e.life--;
              let Y = S.filter(e => e.life > 0);
              for (let e of (Y.length > 200 && Y.splice(0, Y.length - 200), W.current = Y, ek.current))
                if (!e.collected && (e.animFrame++, eO(a.x, a.y - a.height, a.width, a.height, e.x - 10, e.y -
                    10, 20, 20))) {
                  e.collected = !0;
                  let t = 1 + .1 * en.current,
                    o = Math.round(e.value * t);
                  eC.current += Math.ceil(o / 5), z.current += o, eU(S, e.x, e.y, 8 + Math.min(en.current,
                    10), m), eZ(), eo.playCoinCollect()
                } for (let e of e2.current)
                if (!e.opened && eO(a.x, a.y - a.height, a.width, a.height, e.x - 15, e.y - 15, 30, 30)) {
                  if (e.opened = !0, "coins" === e.reward) {
                    let t = 1 + .1 * en.current,
                      o = Math.round(e.value * t);
                    z.current += o, eC.current += Math.ceil(o / 5), eU(S, e.x, e.y, 12, m)
                  } else if ("skill" === e.reward) {
                    let t = P.filter(e => "purchase" === e.unlockMethod && !ea.getState().saveData
                      .unlockedSkills.includes(e.id));
                    if (t.length > 0) {
                      let e = t[Math.floor(Math.random() * t.length)],
                        o = ea.getState().saveData,
                        a = {
                          ...o,
                          unlockedSkills: [...o.unlockedSkills, e.id]
                        };
                      Z(a), ea.setState({
                        saveData: a
                      }), e4("SKILL UNLOCKED: " + e.name + "!", e.color)
                    } else z.current += 50, eU(S, e.x, e.y, 15, m)
                  }
                  eU(S, e.x, e.y, 10, c), eZ(), eo.playCoinCollect()
                } for (let e of e1.current) e.cooldownTimer > 0 && (e.cooldownTimer -= (eG ? 2 : 1)), e
                .activeTimer > 0 && (e.activeTimer--, e.activeTimer <= 0 && (e.isActive = !1));
              if (e1.current.find(e => "bloodFury" === e.id && e.isActive) && (a.shootCooldown = Math.max(0, a
                    .shootCooldown - 2), F.current % 30 == 0 && (a.health = Math.max(1, a.health - 1)), F
                  .current % 3 == 0 && eU(S, a.x + a.width / 2, a.y - 25, 1, "#ff0000")), !eP.current && I
                .current.length > 0) {
                let t = eM.current,
                  o = I.current.filter(e => !e.active).length;
                if (t > 0 && o >= t * (.4 + y % 7 * .05)) {
                  let t = function(e) {
                    if (H[e]) return H[e];
                    if (e >= 9 && e <= 100) {
                      let t = e % 10;
                      if (3 === t || 6 === t || 9 === t) {
                        let t = V(e + 3333),
                          o = ["ambush", "thugsAppear", "trapTriggered", "allyArrives", "warning"],
                          a = o[Math.floor(t() * o.length)];
                        return {
                          type: a,
                          text: ({
                            ambush: "AMBUSH! WATCH YOUR BACK!",
                            thugsAppear: "THUGS BLOCKING THE PATH!",
                            bossSurprise: "A HIDDEN BOSS AWAKENS!",
                            allyArrives: "REINFORCEMENTS ARRIVED!",
                            trapTriggered: "TRAP SPRUNG! BE CAREFUL!",
                            voidRift: "A VOID RIFT TEARS OPEN!",
                            betrayal: "WAIT... WHOSE SIDE ARE YOU ON?!",
                            rescue: "SOMEONE NEEDS SAVING!",
                            treasure: "RARE LOOT AHEAD!",
                            warning: "DANGER APPROACHES...",
                            flashback: "A MEMORY SURFACES...",
                            earthquake: "THE GROUND SHAKES!"
                          })[a],
                          color: "ambush" === a ? f : "thugsAppear" === a ? c : d,
                          spawnEnemies: "ambush" === a || "thugsAppear" === a ? e > 20 ? ["voidGuardian",
                            "glitchWalker"
                          ] : ["drone", "glitchWalker"] : [],
                          enemyCount: "ambush" === a || "thugsAppear" === a ? 2 + Math.floor(3 * t()) : 0,
                          duration: 120
                        }
                      }
                    }
                    if (e > 100) {
                      let t = e % 10;
                      if (3 === t || 5 === t || 7 === t) {
                        let t = V(e + 7777),
                          o = ["ambush", "thugsAppear", "voidRift", "trapTriggered", "bossSurprise",
                            "betrayal"
                          ],
                          a = o[Math.floor(t() * o.length)];
                        return {
                          type: a,
                          text: ({
                            ambush: "AMBUSH! ENEMIES FROM THE SHADOWS!",
                            thugsAppear: "THUGS AHEAD! FIGHT THROUGH!",
                            bossSurprise: "SURPRISE BOSS! PREPARE YOURSELF!",
                            allyArrives: "REINFORCEMENTS HAVE ARRIVED!",
                            trapTriggered: "TRAP TRIGGERED! WATCH YOUR STEP!",
                            voidRift: "A VOID RIFT TEARS OPEN!",
                            betrayal: "SOMEONE IS TURNING AGAINST YOU!",
                            rescue: "A PRISONER NEEDS SAVING!",
                            treasure: "RARE LOOT DETECTED!",
                            warning: "DANGER APPROACHES...",
                            flashback: "A MEMORY SURFACES...",
                            earthquake: "THE GROUND SHAKES!"
                          })[a],
                          color: "bossSurprise" === a ? f : "voidRift" === a ? i : "ambush" === a ? c : d,
                          spawnEnemies: "bossSurprise" === a ? ["bossCorrupted"] : e > 150 ? ["eliteDrone",
                            "heavyWalker", "shadowAssassin"
                          ] : e > 50 ? ["voidGuardian", "eliteDrone"] : ["glitchWalker", "drone"],
                          enemyCount: "bossSurprise" === a ? 1 : 2 + Math.floor(4 * t()),
                          duration: "bossSurprise" === a ? 180 : 120
                        }
                      }
                    }
                    return null
                  }(y);
                  if (t) {
                    if (ej.current = t, eN.current = t.duration, eP.current = !0, t.spawnEnemies && t
                      .spawnEnemies.length > 0 && t.enemyCount) {
                      for (let o = 0; o < t.enemyCount; o++) {
                        let r = t.spawnEnemies[o % t.spawnEnemies.length],
                          n = "boss" === r || "bossRedKing" === r || "bossTitan" === r || "bossDragon" ===
                          r || "bossPhoenix" === r || "bossMechGolem" === r || "bossCorrupted" === r ||
                          "bossFather" === r || "bossTwin" === r,
                          i = "voidGuardian" === r,
                          s = "eliteDrone" === r,
                          c = "heavyWalker" === r,
                          d = "dragon" === r,
                          h = "phoenix" === r,
                          f = "mechGolem" === r,
                          u = "shadowAssassin" === r,
                          m = "bossTitan" === r ? 500 : "bossRedKing" === r ? 400 : "boss" === r ? 300 :
                          "bossDragon" === r ? 600 : "bossPhoenix" === r ? 450 : "bossMechGolem" === r ? 550 :
                          "bossCorrupted" === r ? 480 : "bossTwin" === r ? 700 : 150,
                          x = 20,
                          p = 50,
                          g = 20;
                        n ? (x = 60, p = 80, g = m) : i ? (x = 30, p = 30, g = 25) : s ? (x = 20, p = 50, g =
                            30) : c ? (x = 25, p = 55, g = 40) : d ? (x = 35, p = 40, g = 45) : h ? (x = 25,
                            p = 40, g = 35) : f ? (x = 30, p = 55, g = 60) : u ? (x = 18, p = 50, g = 25) :
                          "drone" === r ? g = 20 : "glitchWalker" === r ? g = 25 : "voidBat" === r ? (x = 16,
                            p = 30, g = 15) : "stormEagle" === r ? (x = 24, p = 45, g = 30) : "emberWisp" ===
                          r ? (x = 16, p = 30, g = 18) : "frostWraith" === r ? (x = 22, p = 45, g = 35) :
                          "shadowDrake" === r ? (x = 30, p = 55, g = 40) : "plasmaSerpent" === r ? (x = 26,
                            p = 50, g = 35) : "neonWyrm" === r ? (x = 32, p = 60, g = 50) : "crystalMoth" ===
                          r ? (x = 18, p = 35, g = 20) : "zombie" === r ? (x = 22, p = 55, g = 55) :
                          "giant" === r ? (x = 55, p = 80, g = 150) : "necromancer" === r ? (x = 20, p = 50,
                            g = 40) : "bomber" === r && (x = 18, p = 45, g = 25);
                        let y = Math.min(a.x + a.facing * (.4 * e) + 60 * o, l.width - 40),
                          b = E(r) || "necromancer" === r;
                        I.current.push({
                          x: Math.max(40, y),
                          y: b ? 200 + Math.floor(150 * Math.random()) : 480,
                          width: x,
                          height: p,
                          vx: 0,
                          vy: 0,
                          type: r,
                          health: g,
                          maxHealth: g,
                          facing: -1,
                          shootCooldown: 70 + Math.floor(30 * Math.random()),
                          animFrame: 10 * o,
                          animTimer: 0,
                          active: !0,
                          grounded: !b,
                          patternTimer: 0,
                          invincible: 0,
                          isHit: !1,
                          hitTimer: 0,
                          bossName: n ? "SURPRISE BOSS" : void 0,
                          bossColor: n ? t.color : void 0
                        })
                      }
                      eM.current += t.enemyCount, X.current = 8
                    }
                    eZ(), eo.playAbilityReady()
                  }
                }
              }
              let J = eS.current,
                Q = ea.getState(),
                et = Q.currentWave >= Q.totalWaves - 1,
                el = eJ.current,
                er = I.current.filter(e => !e.isAmbient && e.active && e.y < 600 && e.y > -100),
                ed = el > 0 && 0 === er.length,
                eh = 0 === eR.current.length;
              if (et && ed && ee.current && eh && !J.active && (J.active = !0, e4(
                  "EXIT OPEN! Reach the gate!", s)), J.active && eO(a.x, a.y - a.height, a.width, a.height, J
                  .x - 40, J.y - 80, 80, 90)) {
                z.current += 200;
                let e = Math.round(Math.max(0, a.health) / a.maxHealth * 100),
                  t = a.kills,
                  o = eM.current,
                  l = eT.current,
                  r = Math.floor(z.current / 5),
                  n = 1;
                (e > 40 || t >= .5 * o) && (n = 2), e > 70 && t >= .8 * o && (n = 3), ea.setState({
                  lastLevelStars: n,
                  lastLevelKills: t,
                  lastLevelMaxCombo: l,
                  lastLevelCoinsEarned: r,
                  lastLevelHealthPct: e,
                  lastLevelTotalEnemies: o
                }), ea.getState().completeLevel(z.current);
                return
              }
              en.current > eT.current && (eT.current = en.current);
              let eu = I.current.filter(e => !e.isAmbient && e.active && e.y < 600 && e.y > -100);
              if (eJ.current > 0 && 0 === eu.length && 0 === eR.current.length && ee.current) {
                .5 > Math.random() && e4(e_("waveClear"), s), eZ(), eo.playWaveComplete(), ee.current = !1;
                let e = ea.getState();
                e.currentWave < e.totalWaves - 1 && ea.getState().advanceWave()
              }
              let em = ea.getState().currentWave >= ea.getState().totalWaves - 1 && ee.current;
              if ("single" === A && !em && (eq.current--, eq.current <= 0)) {
                let e = ea.getState().currentLevel;
                if (I.current.filter(e => e.active).length < Math.min(2 + Math.floor(e / 25), 6) && a.health >
                  0) {
                  let t = 300 + 400 * Math.random(),
                    o = a.x + a.facing * t,
                    l = eS.current,
                    r = l.active && 200 > Math.abs(o - l.x);
                  if (o > 100 && o < (B.current?.width || 9999) - 200 && !r) {
                    let t = ["drone", "glitchWalker"];
                    e >= 10 && t.push("eliteDrone", "shadowAssassin"), e >= 20 && t.push("zombie", "voidBat"),
                      e >= 40 && t.push("bomber", "necromancer");
                    let l = t[Math.floor(Math.random() * t.length)],
                      r = E(l),
                      n = Math.floor(("zombie" === l ? 55 : "bomber" === l ? 25 : "necromancer" === l ? 40 :
                        "shadowAssassin" === l ? 25 : "eliteDrone" === l ? 30 : 20) * (e <= 3 ? .4 : e <=
                        50 ? .6 + .2 * Math.log(1 + (e - 3) / 80) : e <= 200 ? 1 + .25 * Math.log(1 + (e -
                          50) / 50) : 1.35 + .3 * Math.log(1 + (e - 200) / 100))),
                      i = e <= 3 ? .5 : e <= 50 ? Math.min(.7 + e / 500, 1) : Math.min(1 + e / 250, 2.5);
                    I.current.push({
                      x: o,
                      y: r ? 150 + 200 * Math.random() : 480,
                      width: "zombie" === l ? 22 : "bomber" === l ? 18 : 20,
                      height: "zombie" === l ? 55 : "bomber" === l ? 45 : 50,
                      vx: 0,
                      vy: 0,
                      type: l,
                      health: n,
                      maxHealth: n,
                      facing: -1 * a.facing,
                      shootCooldown: Math.floor((70 + Math.floor(30 * Math.random())) / i),
                      animFrame: 0,
                      animTimer: 0,
                      active: !0,
                      grounded: !r,
                      patternTimer: 0,
                      invincible: 0,
                      isHit: !1,
                      hitTimer: 0,
                      isAmbient: !0
                    }), eY.current++
                  }
                }
                eq.current = (e <= 10 ? 200 : e <= 30 ? 150 : e <= 60 ? 100 : 70) + Math.floor(60 * Math
                  .random())
              }
              ea.getState().currentLevel <= 3 && a.health < 1 && (a.health = 1);
              let ex = a.health <= 0,
                ep = !G || G.health <= 0;
              if (R) {
                if (ex || ep) {
                  let e = e => {
                    let t = j.current;
                    if (t) {
                      for (let o = 0; o < 40; o++) {
                        let a = 2 * Math.PI * o / 40,
                          l = 2 + 4 * Math.random();
                        W.current.push({
                          x: t.x + t.width / 2,
                          y: t.y + t.height / 2,
                          vx: Math.cos(a) * l,
                          vy: Math.sin(a) * l - 2,
                          life: 80 + 40 * Math.random(),
                          maxLife: 120,
                          color: e,
                          size: 2 + 3 * Math.random(),
                          type: "spark"
                        })
                      }
                      for (let e = 0; e < 20; e++) {
                        let o = 2 * Math.PI * e / 20;
                        W.current.push({
                          x: t.x + t.width / 2 + 60 * Math.cos(o),
                          y: t.y + t.height / 2 + 60 * Math.sin(o),
                          vx: .5 * Math.cos(o),
                          vy: .5 * Math.sin(o) - 1,
                          life: 50 + 30 * Math.random(),
                          maxLife: 80,
                          color: "#ffd700",
                          size: 4 + 2 * Math.random(),
                          type: "spark"
                        })
                      }
                    }
                  };
                  if (eZ(), eo.stopAll(), ex && !ep) {
                    e(c), ea.getState().versusRoundWin(2);
                    return
                  }
                  if (ep && !ex) {
                    e(n), ea.getState().versusRoundWin(1);
                    return
                  }
                  if (ex && ep) {
                    e("#ffd700"), ea.getState().versusRoundWin(3);
                    return
                  }
                }
              } else if (ex && ep || !G && ex) {
                eZ(), eo.playGameOver(), ea.getState().gameOver();
                return
              }
              o = G && G.health > 0 && !ex ? (a.x + G.x) / 2 - e / 2 + a.width / 2 : G && G.health > 0 && ex ?
                G.x - e / 2 + G.width / 2 : a.x - e / 2 + a.width / 2, $.current += (o - $.current) * .1, $
                .current = Math.max(0, Math.min($.current, l.width - e))
            },
            e7 = (e, t, o) => {
              var a, l, r, x, g, y, b, v, w, k, C, S, T, M, P, A;
              let R = B.current,
                E = j.current,
                L = N.current;
              if (!R || !E) {
                e.fillStyle = "#050510", e.fillRect(0, 0, t, o), e.save(), e.globalAlpha = .6 + .3 * Math.sin(
                    .05 * F.current), e.fillStyle = n, e.shadowBlur = 15, e.shadowColor = n, e.font =
                  "bold 16px monospace", e.textAlign = "center", e.textBaseline = "middle", e.fillText(
                    "LOADING...", t / 2, o / 2), e.shadowBlur = 0, e.globalAlpha = 1, e.restore();
                return
              }
              let G = $.current;
              for (let a of (! function(e, t, o, a, l, r, s, m) {
                  if (m) {
                    let t = e.createLinearGradient(0, 0, 0, o),
                      a = m.skyGradient;
                    for (let e = 0; e < a.length; e++) t.addColorStop(e / (a.length - 1), a[e]);
                    e.fillStyle = t
                  } else e.fillStyle = u;
                  e.fillRect(0, 0, t, o), e.globalAlpha = .55, e.fillStyle = "#000008", e.fillRect(0, 0,
                    t, o), e.globalAlpha = 1, m && "none" !== m.weatherType && function(e, t, o) {
                    if (.015 > Math.random()) {
                      let e = 2 + Math.floor(3 * Math.random()),
                        a = [],
                        l = Math.random() * t,
                        r = 0;
                      a.push({
                        x: l,
                        y: r
                      });
                      for (let t = 0; t < e; t++) l += (Math.random() - .5) * 120, r += o / (e + 1) +
                        40 * Math.random(), a.push({
                          x: l,
                          y: Math.min(r, o)
                        });
                      eL.push({
                        segments: a,
                        life: 6 + Math.floor(4 * Math.random()),
                        flashLife: 4
                      })
                    }
                    for (let a = eL.length - 1; a >= 0; a--) {
                      let l = eL[a];
                      if (l.life--, l.flashLife--, l.life <= 0) {
                        eL.splice(a, 1);
                        continue
                      }
                      l.flashLife > 0 && (e.globalAlpha = .15 * (l.flashLife / 4), e.fillStyle =
                        "#ffffff", e.fillRect(0, 0, t, o), e.globalAlpha = 1);
                      let r = Math.min(l.life / 6, 1);
                      e.save(), e.globalAlpha = .4 * r, e.strokeStyle = "#ffffff", e.lineWidth = 6, e
                        .shadowBlur = 30, e.shadowColor = "#ffffff", e.beginPath(), e.moveTo(l.segments[
                          0].x, l.segments[0].y);
                      for (let t = 1; t < l.segments.length; t++) e.lineTo(l.segments[t].x, l.segments[
                        t].y);
                      e.stroke(), e.globalAlpha = .9 * r, e.strokeStyle = "#00ffff", e.lineWidth = 2, e
                        .shadowBlur = 20, e.shadowColor = "#00ffff", e.beginPath(), e.moveTo(l.segments[
                          0].x, l.segments[0].y);
                      for (let t = 1; t < l.segments.length; t++) e.lineTo(l.segments[t].x, l.segments[
                        t].y);
                      e.stroke(), e.globalAlpha = .5 * r, e.strokeStyle = "#00ffff", e.lineWidth = 1, e
                        .shadowBlur = 8;
                      for (let t = 1; t < l.segments.length - 1; t++)
                        if (.6 > Math.random()) {
                          let o = 15 + 30 * Math.random(),
                            a = (Math.random() - .5) * Math.PI * .6;
                          e.beginPath(), e.moveTo(l.segments[t].x, l.segments[t].y), e.lineTo(l
                              .segments[t].x + Math.cos(a) * o, l.segments[t].y + Math.sin(a + .5) * o),
                            e.stroke()
                        } e.restore()
                    }
                  }(e, t, o), e.globalAlpha = .25;
                  for (let l = 0; l < 30; l++) {
                    let r = ((197.3 * l - .05 * a + .15 * s) % t + t) % t,
                      n = (127.7 * l + .2 * s * (.5 + l % 3 * .3)) % o,
                      i = 1.5 + l % 4 * .8;
                    e.fillStyle = l % 3 == 0 ? "#220044" : l % 3 == 1 ? "#110022" : "#0a0020", e
                      .beginPath(), e.arc(r, n, i, 0, 2 * Math.PI), e.fill()
                  }
                  for (let o of (e.globalAlpha = 1, e.globalAlpha = .4, r)) {
                    let l = ((o.x - a * o.speed) % t + t) % t;
                    e.fillStyle = m ? m.particleColor : "#ffffff", e.fillRect(l, o.y, o.size, o.size)
                  }
                  e.globalAlpha = 1;
                  let x = m ? m.platformGlow : "firewall" === l.background ? c : "void" === l.background ?
                    i : "core" === l.background ? h : n;
                  e.globalAlpha = .06, e.strokeStyle = x, e.lineWidth = 1;
                  let p = -(.15 * a) % 80;
                  for (let a = p; a < t; a += 80) e.beginPath(), e.moveTo(a, 0), e.lineTo(a, o), e
                  .stroke();
                  for (let a = 0; a < o; a += 80) e.beginPath(), e.moveTo(0, a), e.lineTo(t, a), e
                  .stroke();
                  e.globalAlpha = .1;
                  let g = -(.4 * a) % 50;
                  for (let a = g; a < t; a += 50) e.beginPath(), e.moveTo(a, 0), e.lineTo(a, o), e
                  .stroke();
                  e.globalAlpha = .08, e.fillStyle = x;
                  let y = -(.2 * a),
                    b = [60, 40, 80, 50, 70, 45, 90, 55, 65, 75, 35, 85],
                    v = [120, 80, 200, 150, 180, 90, 250, 130, 160, 220, 70, 190];
                  for (let a = 0; a < b.length; a++) {
                    let l = (y + 250 * a) % (t + 500) - 100,
                      r = v[a % v.length],
                      n = b[a % b.length];
                    e.fillRect(l, o - 100 - r, n, r)
                  }
                  let w = m ? m.particleColor : x;
                  e.globalAlpha = .3;
                  for (let l = 0; l < 20; l++) {
                    let r = ((173.7 * l - .1 * a) % t + t) % t,
                      n = (91.3 * l + .3 * s) % o,
                      i = 1 + l % 3;
                    e.shadowBlur = 5, e.shadowColor = w, e.fillStyle = w, e.beginPath(), e.arc(r, n, i, 0,
                      2 * Math.PI), e.fill()
                  }
                  if (e.shadowBlur = 0, e.globalAlpha = 1, m) {
                    let l = m.weatherType,
                      r = m.particleColor;
                    if ("rain" === l) {
                      e.globalAlpha = .3, e.strokeStyle = r, e.lineWidth = 1;
                      for (let l = 0; l < 60; l++) {
                        let r = ((97.3 * l - .3 * a + 2 * s) % t + t) % t,
                          n = (53.7 * l + 6 * s) % o;
                        e.beginPath(), e.moveTo(r, n), e.lineTo(r - 1, n + 8), e.stroke()
                      }
                      e.globalAlpha = 1
                    } else if ("snow" === l) {
                      e.globalAlpha = .6, e.fillStyle = "#ffffff";
                      for (let l = 0; l < 50; l++) {
                        let r = ((79.1 * l - .1 * a + 20 * Math.sin(.01 * s + l)) % t + t) % t,
                          n = (43.7 * l + 1.5 * s) % o,
                          i = 1 + l % 3;
                        e.beginPath(), e.arc(r, n, i, 0, 2 * Math.PI), e.fill()
                      }
                      e.globalAlpha = 1
                    } else if ("embers" === l) {
                      e.globalAlpha = .5;
                      for (let l = 0; l < 40; l++) {
                        let n = ((87.3 * l - .15 * a) % t + t) % t,
                          i = o - (67.1 * l + 2 * s) % o,
                          c = 1 + l % 2;
                        e.shadowBlur = 4, e.shadowColor = r, e.fillStyle = l % 3 == 0 ? d : r, e
                          .beginPath(), e.arc(n, i, c, 0, 2 * Math.PI), e.fill()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1
                    } else if ("glitch" === l) {
                      e.globalAlpha = .06, e.fillStyle = r;
                      for (let a = 0; a < 8; a++) {
                        let l = (2 * s + 97 * a) % o;
                        e.fillRect(0, l, t, 2 + 6 * Math.random())
                      }
                      m.platformGlow === d && s % 180 < 3 && (e.globalAlpha = .15, e.fillStyle =
                        "#ffffff", e.fillRect(0, 0, t, o)), e.globalAlpha = 1
                    } else if ("voidParticles" === l) {
                      e.globalAlpha = .08 + .04 * Math.sin(.02 * s), e.fillStyle = r, e.beginPath(), e
                        .arc(t / 2, o / 2, 200 + 50 * Math.sin(.03 * s), 0, 2 * Math.PI), e.fill(), e
                        .globalAlpha = .4;
                      for (let l = 0; l < 20; l++) {
                        let n = ((113.7 * l - .2 * a) % t + t) % t,
                          i = (73.1 * l + .8 * s) % o;
                        e.fillStyle = l % 2 == 0 ? r : "#440044", e.beginPath(), e.arc(n, i, 2 + +Math
                          .sin(.1 * s + l), 0, 2 * Math.PI), e.fill()
                      }
                      e.globalAlpha = 1
                    } else if ("none" === l) {
                      e.globalAlpha = .3 + .15 * Math.sin(.04 * s);
                      for (let l = 0; l < 15; l++) {
                        let n = ((131.7 * l - .1 * a) % t + t) % t,
                          i = (83.1 * l + 30 * Math.sin(.02 * s + 2 * l)) % o;
                        e.shadowBlur = 8, e.shadowColor = r, e.fillStyle = "#ffffff", e.beginPath();
                        let c = 2 + +Math.sin(.08 * s + l);
                        e.moveTo(n, i - c), e.lineTo(n + c, i), e.lineTo(n, i + c), e.lineTo(n - c, i), e
                          .closePath(), e.fill()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1
                    }
                    "#cc0033" === m.platformGlow && (e.globalAlpha = .04 + .02 * Math.sin(.01 * s), e
                      .fillStyle = "#ff0033", e.fillRect(0, 0, t, o), e.globalAlpha = .2 + .05 * Math
                      .sin(.02 * s), e.shadowBlur = 30, e.shadowColor = "#cc0033", e.fillStyle =
                      "#cc0033", e.beginPath(), e.arc(.8 * t, 60, 35 + 3 * Math.sin(.03 * s), 0, 2 *
                        Math.PI), e.fill(), e.shadowBlur = 0, e.globalAlpha = 1)
                  } else if ("corrupted" === l.background) {
                    e.globalAlpha = .03, e.fillStyle = f;
                    for (let a = 0; a < 5; a++) {
                      let l = (2 * s + 137 * a) % o;
                      e.fillRect(0, l, t, 2 + 4 * Math.random())
                    }
                    e.globalAlpha = 1
                  } else "void" === l.background ? (e.globalAlpha = .05 + .03 * Math.sin(.02 * s), e
                    .fillStyle = i, e.beginPath(), e.arc(t / 2, o / 2, 200 + 50 * Math.sin(.03 * s), 0,
                      2 * Math.PI), e.fill(), e.globalAlpha = 1) : "core" === l.background && (e
                    .globalAlpha = .08, e.fillStyle = h, e.beginPath(), e.arc(t / 2, o / 2, 300 + 30 *
                      Math.sin(.02 * s), 0, 2 * Math.PI), e.fill(), e.globalAlpha = .04, e.fillStyle =
                    n, e.beginPath(), e.arc(t / 2, o / 2, 150 + 20 * Math.sin(.04 * s), 0, 2 * Math.PI),
                    e.fill(), e.globalAlpha = 1)
                }(e, t, o, G, R, Y.current, F.current, J.current ?? void 0), O.current)) {
                let {
                  px: o,
                  py: l
                } = eV(a), r = o - G;
                r + a.width < -50 || r > t + 50 || function(e, t, o, a, l, r) {
                  let s = "firewall" === r ? c : "void" === r ? i : "core" === r ? h : n;
                  e.shadowBlur = 10, e.shadowColor = s, e.globalAlpha = .2, e.fillStyle = s, e.fillRect(t,
                      o, a, l), e.globalAlpha = 1, e.shadowBlur = 0, e.fillStyle = "firewall" === r ?
                    "#1a0d00" : "void" === r ? "#1a0011" : "core" === r ? "#11001a" : "#001a1a", e.fillRect(
                      t, o, a, l), e.globalAlpha = .8, e.shadowBlur = 6, e.shadowColor = s, e.strokeStyle =
                    s, e.lineWidth = 2, e.beginPath(), e.moveTo(t, o), e.lineTo(t + a, o), e.stroke(), e
                    .shadowBlur = 0, e.globalAlpha = 1
                }(e, r, l, a.width, a.height, R.background)
              }
              for (let o of I.current) {
                if (!o.active) continue;
                let a = o.x - G;
                if (!(a < -100) && !(a > t + 100)) {
                  if ("boss" === o.type || "bossRedKing" === o.type || "bossTitan" === o.type ||
                    "bossDragon" === o.type || "bossPhoenix" === o.type || "bossMechGolem" === o.type ||
                    "bossCorrupted" === o.type || "bossFather" === o.type || "bossTwin" === o.type) {
                    let t = o.bossColor || ("bossFather" === o.type ? n : "bossTwin" === o.type ? p : 3 === R
                      .id ? i : h);
                    w = e, k = a + o.width / 2, C = o.y, S = o.facing, T = t, M = o.animFrame, P = o.health,
                      A = o.maxHealth, w.save(), w.translate(k, C), w.shadowBlur = 30, w.shadowColor = T, w
                      .globalAlpha = .15 + .1 * Math.sin(.05 * M), w.beginPath(), w.arc(0, -75, 100, 0, 2 *
                        Math.PI), w.fillStyle = T, w.fill(), w.globalAlpha = 1, w.shadowBlur = 15, w
                      .shadowColor = T, w.beginPath(), w.arc(0, -95, 30, 0, 2 * Math.PI), w.strokeStyle = T, w
                      .lineWidth = 3, w.stroke(), w.fillStyle = "#ff0000", w.shadowColor = "#ff0000", w
                      .shadowBlur = 15, w.beginPath(), w.arc(-12.5, -100, 5, 0, 2 * Math.PI), w.fill(), w
                      .beginPath(), w.arc(12.5, -100, 5, 0, 2 * Math.PI), w.fill(), w.shadowColor = T, w
                      .shadowBlur = 15, w.globalAlpha = .3, w.lineWidth = 8, w.beginPath(), w.moveTo(0, -65),
                      w.lineTo(0, -12.5), w.stroke(), w.globalAlpha = 1, w.lineWidth = 3, w.beginPath(), w
                      .moveTo(0, -65), w.lineTo(0, -12.5), w.stroke(), w.globalAlpha = .3, w.lineWidth = 8, w
                      .beginPath(), w.moveTo(0, -50), w.lineTo(-(25 * S * 2.5), -25 + 5 * Math.sin(.05 * M) *
                        2.5), w.stroke(), w.beginPath(), w.moveTo(0, -50), w.lineTo(25 * S * 2.5, -62.5 + 5 *
                        Math.sin(.05 * M + 1) * 2.5), w.stroke(), w.globalAlpha = 1, w.lineWidth = 3, w
                      .beginPath(), w.moveTo(0, -50), w.lineTo(-(25 * S * 2.5), -25 + 5 * Math.sin(.05 * M) *
                        2.5), w.stroke(), w.beginPath(), w.moveTo(0, -50), w.lineTo(25 * S * 2.5, -62.5 + 5 *
                        Math.sin(.05 * M + 1) * 2.5), w.stroke(), w.globalAlpha = .3, w.lineWidth = 8, w
                      .beginPath(), w.moveTo(0, -12.5), w.lineTo(-25, 32.5), w.stroke(), w.beginPath(), w
                      .moveTo(0, -12.5), w.lineTo(25, 32.5), w.stroke(), w.globalAlpha = 1, w.lineWidth = 3, w
                      .beginPath(), w.moveTo(0, -12.5), w.lineTo(-25, 32.5), w.stroke(), w.beginPath(), w
                      .moveTo(0, -12.5), w.lineTo(25, 32.5), w.stroke(), w.globalAlpha = .8, w.shadowBlur = 0,
                      w.fillStyle = "#330000", w.fillRect(-40, -137.5, 80, 6), w.fillStyle = f, w
                      .shadowColor = f, w.shadowBlur = 8, w.fillRect(-40, -137.5, P / A * 80, 6), w.restore(),
                      o.bossName && (e.save(), e.globalAlpha = .8, e.shadowBlur = 10, e.shadowColor = t, e
                        .fillStyle = t, e.font = "bold 12px monospace", e.textAlign = "center", e.fillText(o
                          .bossName, a + o.width / 2, o.y - 90), e.shadowBlur = 0, e.globalAlpha = 1, e
                        .restore())
                  } else ! function(e, t, o, a, l, r, u) {
                    if ("boss" === a) return;
                    let m = "drone" === a ? f : "glitchWalker" === a ? h : "eliteDrone" === a ? "#ff4466" :
                      "heavyWalker" === a ? "#884400" : c;
                    if ("eliteDrone" === a) {
                      eE(e, t, o + 2 * Math.sin(.15 * r), l, "#ff4466", r, !1, u, 1.1, "angry", !0), e
                        .save(), e.globalAlpha = .15 + .1 * Math.sin(.1 * r), e.shadowBlur = 20, e
                        .shadowColor = "#ff4466", e.fillStyle = "#ff4466", e.beginPath(), e.arc(t, o - 25,
                          30, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore();
                      return
                    }
                    if ("heavyWalker" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 10, e.shadowColor = "#884400", e
                        .strokeStyle = "#884400", e.lineWidth = 3.9000000000000004, e.beginPath(), e.arc(0,
                          -49.4, 11.700000000000001, 0, 2 * Math.PI), e.stroke(), e.fillStyle = "#ff0000", e
                        .beginPath(), e.arc(3 * l * 1.3, -50.7, 2.6, 0, 2 * Math.PI), e.fill(), e
                        .beginPath(), e.moveTo(0, -37.7), e.lineTo(0, -13), e.stroke(), e.lineWidth = 5.2, e
                        .beginPath(), e.moveTo(0, -32.5), e.lineTo(-(15 * l * 1.3), -19.5), e.stroke(), e
                        .beginPath(), e.moveTo(0, -32.5), e.lineTo(15 * l * 1.3, -19.5), e.stroke(), e
                        .lineWidth = 5.2, e.beginPath(), e.moveTo(0, -13), e.lineTo(-13, 10.4), e.stroke(),
                        e.beginPath(), e.moveTo(0, -13), e.lineTo(13, 10.4), e.stroke(), e.shadowBlur = 0, e
                        .restore();
                      return
                    }
                    if ("voidGuardian" === a) e.save(), e.translate(t, o), e.shadowBlur = 10, e
                      .shadowColor = c, e.globalAlpha = .4, e.fillStyle = c, e.fillRect(-15, -25, 30, 25), e
                      .globalAlpha = 1, e.strokeStyle = c, e.lineWidth = 2, e.strokeRect(-15, -25, 30, 25),
                      e.beginPath(), e.moveTo(0, -15), e.lineTo(20 * l, -18), e.stroke(), e.shadowBlur = 0,
                      e.restore();
                    else if ("dragon" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = c, e.strokeStyle = c,
                        e.fillStyle = c, e.lineWidth = 2;
                      let a = 3 * Math.sin(.08 * r);
                      e.beginPath(), e.ellipse(0, -15 + a, 14, 8, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(16 * l, -20 + a, 6, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        f, e.beginPath(), e.arc(18 * l, -21 + a, 2, 0, 2 * Math.PI), e.fill();
                      let n = 10 * Math.sin(.15 * r);
                      e.strokeStyle = c, e.beginPath(), e.moveTo(-6, -18 + a), e.lineTo(-20, -30 + a + n), e
                        .lineTo(-12, -8 + a), e.moveTo(6, -18 + a), e.lineTo(20, -30 + a + n), e.lineTo(12,
                          -8 + a), e.stroke(), e.beginPath(), e.moveTo(-(14 * l), -12 + a), e
                        .quadraticCurveTo(-(22 * l), -6 + a + 4 * Math.sin(.1 * r), -(26 * l), -12 + a), e
                        .stroke(), r % 60 < 15 && (e.globalAlpha = .6, e.fillStyle = d, e.beginPath(), e
                          .moveTo(22 * l, -20 + a), e.lineTo(35 * l, -18 + a), e.lineTo(35 * l, -22 + a), e
                          .closePath(), e.fill(), e.globalAlpha = 1), e.shadowBlur = 0, e.restore()
                    } else if ("phoenix" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = d, e.strokeStyle = d,
                        e.fillStyle = d, e.lineWidth = 2;
                      let a = 4 * Math.sin(.1 * r);
                      e.beginPath(), e.ellipse(0, -14 + a, 10, 6, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(12 * l, -18 + a, 5, 0, 2 * Math.PI), e.stroke();
                      let n = 8 * Math.sin(.2 * r);
                      e.strokeStyle = c, e.beginPath(), e.moveTo(-5, -16 + a), e.lineTo(-18, -26 + a + n), e
                        .lineTo(-8, -6 + a), e.moveTo(5, -16 + a), e.lineTo(18, -26 + a + n), e.lineTo(8, -
                          6 + a), e.stroke(), e.globalAlpha = .5, e.fillStyle = c;
                      for (let t = 1; t <= 3; t++) e.beginPath(), e.arc(-l * (8 + 6 * t), -10 + a + 3 * Math
                        .sin(.15 * r + t), 3 - .5 * t, 0, 2 * Math.PI), e.fill();
                      e.globalAlpha = 1, e.shadowBlur = 0, e.restore()
                    } else if ("mechGolem" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 10, e.shadowColor = s, e.strokeStyle = s,
                        e.lineWidth = 2.5;
                      let a = 1.5 * Math.sin(.06 * r);
                      e.beginPath(), e.moveTo(-6, -38 + a), e.lineTo(6, -38 + a), e.lineTo(8, -30 + a), e
                        .lineTo(-8, -30 + a), e.closePath(), e.stroke(), e.fillStyle = f, e.beginPath(), e
                        .arc(-3, -34 + a, 2, 0, 2 * Math.PI), e.arc(3, -34 + a, 2, 0, 2 * Math.PI), e
                      .fill(), e.strokeStyle = s, e.lineWidth = 3, e.strokeRect(-10, -28 + a, 20, 20), e
                        .lineWidth = 3, e.beginPath(), e.moveTo(-10, -24 + a), e.lineTo(-18, -16 + a + 2 *
                          Math.sin(.1 * r)), e.moveTo(10, -24 + a), e.lineTo(18, -16 + a - 2 * Math.sin(.1 *
                          r)), e.stroke(), e.lineWidth = 3, e.beginPath(), e.moveTo(-6, -8 + a), e.lineTo(-
                          8, 2 + a), e.moveTo(6, -8 + a), e.lineTo(8, 2 + a), e.stroke(), e.shadowBlur = 0,
                        e.restore()
                    } else if ("shadowAssassin" === a) {
                      e.save(), e.translate(t, o), e.globalAlpha = .1, e.strokeStyle = h, e.lineWidth = 1.5;
                      for (let t = 1; t <= 3; t++) {
                        let o = -l * t * 8;
                        e.beginPath(), e.arc(o, -38, 7, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e
                          .moveTo(o, -31), e.lineTo(o, -10), e.stroke()
                      }
                      e.globalAlpha = .7 + .2 * Math.sin(.2 * r), e.shadowBlur = 8, e.shadowColor = h, e
                        .strokeStyle = h, e.lineWidth = 1.5, e.beginPath(), e.arc(0, -38, 7, 0, 2 * Math
                        .PI), e.stroke(), e.fillStyle = i, e.shadowColor = i, e.beginPath(), e.arc(3 * l, -
                          39, 2, 0, 2 * Math.PI), e.fill(), e.strokeStyle = h, e.beginPath(), e.moveTo(0, -
                          31), e.lineTo(0, -10), e.stroke(), e.beginPath(), e.moveTo(0, -25), e.lineTo(18 *
                          l, -28), e.stroke(), e.beginPath(), e.moveTo(0, -25), e.lineTo(-(10 * l), -20), e
                        .stroke();
                      let a = 10 * Math.sin(.3 * r);
                      e.beginPath(), e.moveTo(0, -10), e.lineTo(-6 + .3 * a, a), e.stroke(), e.beginPath(),
                        e.moveTo(0, -10), e.lineTo(6 - .3 * a, -a), e.stroke(), e.shadowBlur = 0, e
                        .globalAlpha = 1, e.restore()
                    } else if ("voidBat" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 8, e.shadowColor = "#8800aa", e
                        .strokeStyle = "#8800aa", e.fillStyle = i, e.lineWidth = 1.5;
                      let a = 4 * Math.sin(.2 * r);
                      e.beginPath(), e.ellipse(0, -12 + a, 6, 4, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(7 * l, -14 + a, 3.5, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        i, e.beginPath(), e.arc(8 * l, -15 + a, 1.2, 0, 2 * Math.PI), e.fill();
                      let n = 8 * Math.sin(.3 * r);
                      e.beginPath(), e.moveTo(-3, -14 + a), e.quadraticCurveTo(-12, -22 + a + n, -8, -6 +
                        a), e.moveTo(3, -14 + a), e.quadraticCurveTo(12, -22 + a + n, 8, -6 + a), e
                      .stroke(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("stormEagle" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = d, e.strokeStyle = d,
                        e.fillStyle = "#ffff44", e.lineWidth = 2;
                      let a = 5 * Math.sin(.12 * r);
                      e.beginPath(), e.ellipse(0, -16 + a, 12, 6, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(14 * l, -20 + a, 5, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        "#ffffff", e.beginPath(), e.arc(16 * l, -21 + a, 1.5, 0, 2 * Math.PI), e.fill();
                      let n = 10 * Math.sin(.2 * r);
                      e.strokeStyle = d, e.beginPath(), e.moveTo(-6, -18 + a), e.lineTo(-22, -30 + a + n), e
                        .lineTo(-10, -8 + a), e.moveTo(6, -18 + a), e.lineTo(22, -30 + a + n), e.lineTo(10,
                          -8 + a), e.stroke(), r % 30 < 5 && (e.globalAlpha = .7, e.strokeStyle = "#ffffff",
                          e.lineWidth = 1, e.beginPath(), e.moveTo(5 * l, -8 + a), e.lineTo(8 * l, -3 + a),
                          e.lineTo(3 * l, -2 + a), e.lineTo(7 * l, 3 + a), e.stroke(), e.globalAlpha = 1), e
                        .shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("emberWisp" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 10, e.shadowColor = c;
                      let a = 5 * Math.sin(.15 * r);
                      e.globalAlpha = .6 + .2 * Math.sin(.1 * r), e.fillStyle = c, e.beginPath(), e.arc(0, -
                          12 + a, 5, 0, 2 * Math.PI), e.fill(), e.fillStyle = d, e.beginPath(), e.arc(0, -
                          12 + a, 2.5, 0, 2 * Math.PI), e.fill(), e.globalAlpha = .4, e.strokeStyle = c, e
                        .lineWidth = 1.5;
                      for (let t = 0; t < 4; t++) {
                        let o = t / 4 * Math.PI * 2 + .08 * r,
                          l = 8 + 4 * Math.sin(.15 * r + 2 * t);
                        e.beginPath(), e.moveTo(0, -12 + a), e.lineTo(Math.cos(o) * l, -12 + a + Math.sin(
                          o) * l), e.stroke()
                      }
                      e.globalAlpha = .8, e.fillStyle = "#ffffff", e.beginPath(), e.arc(-2, -13 + a, 1, 0,
                          2 * Math.PI), e.fill(), e.beginPath(), e.arc(2, -13 + a, 1, 0, 2 * Math.PI), e
                        .fill(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("frostWraith" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = "#88eeff", e
                        .strokeStyle = "#88eeff", e.lineWidth = 1.5;
                      let a = 6 * Math.sin(.1 * r);
                      e.globalAlpha = .5 + .15 * Math.sin(.08 * r), e.beginPath(), e.moveTo(-8, -5 + a), e
                        .quadraticCurveTo(-10, -30 + a, 0, -35 + a), e.quadraticCurveTo(10, -30 + a, 8, -5 +
                          a);
                      for (let t = 0; t < 4; t++) {
                        let o = -8 + 4 * t + 1,
                          l = -5 + a + 3 * Math.sin(.15 * r + t);
                        e.lineTo(o, l)
                      }
                      e.closePath(), e.stroke(), e.globalAlpha = .8, e.fillStyle = "#ffffff", e.beginPath(),
                        e.arc(-3, -22 + a, 2, 0, 2 * Math.PI), e.fill(), e.beginPath(), e.arc(3, -22 + a, 2,
                          0, 2 * Math.PI), e.fill(), e.globalAlpha = .3, e.fillStyle = "#ffffff";
                      for (let t = 0; t < 4; t++) {
                        let o = 12 * Math.cos(.05 * r + 1.5 * t),
                          l = -20 + a + 8 * Math.sin(.07 * r + 1.3 * t);
                        e.beginPath(), e.arc(o, l, 1.5, 0, 2 * Math.PI), e.fill()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("shadowDrake" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = h, e.strokeStyle = h,
                        e.fillStyle = i, e.lineWidth = 2;
                      let a = 4 * Math.sin(.08 * r);
                      e.beginPath(), e.ellipse(0, -16 + a, 14, 8, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(17 * l, -22 + a, 7, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        i, e.beginPath(), e.arc(19 * l, -23 + a, 2, 0, 2 * Math.PI), e.fill();
                      let n = 12 * Math.sin(.15 * r);
                      e.strokeStyle = h, e.beginPath(), e.moveTo(-8, -20 + a), e.lineTo(-24, -34 + a + n), e
                        .lineTo(-16, -24 + a), e.lineTo(-22, -14 + a + .5 * n), e.lineTo(-10, -12 + a), e
                        .moveTo(8, -20 + a), e.lineTo(24, -34 + a + n), e.lineTo(16, -24 + a), e.lineTo(22,
                          -14 + a + .5 * n), e.lineTo(10, -12 + a), e.stroke(), e.beginPath(), e.moveTo(-(
                          14 * l), -14 + a), e.quadraticCurveTo(-(24 * l), -8 + a + 5 * Math.sin(.1 * r), -(
                          28 * l), -16 + a), e.stroke(), e.globalAlpha = .15 + .1 * Math.sin(.1 * r), e
                        .fillStyle = h, e.beginPath(), e.arc(0, -16 + a, 22, 0, 2 * Math.PI), e.fill(), e
                        .shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("plasmaSerpent" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 12, e.shadowColor = i, e.strokeStyle = i,
                        e.lineWidth = 2.5;
                      let a = 4 * Math.sin(.1 * r);
                      e.globalAlpha = .8;
                      for (let t = 0; t < 6; t++) {
                        let o = -l * t * 7,
                          n = -14 + a + 5 * Math.sin(.15 * r + .8 * t),
                          i = 4 - .3 * t;
                        e.beginPath(), e.arc(o, n, i, 0, 2 * Math.PI), e.stroke()
                      }
                      e.beginPath(), e.arc(5 * l, -16 + a, 6, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        "#ffffff", e.beginPath(), e.arc(7 * l, -17 + a, 2, 0, 2 * Math.PI), e.fill(), e
                        .globalAlpha = .4, e.strokeStyle = "#ff44ff", e.lineWidth = 1;
                      for (let t = 0; t < 3; t++) {
                        let o = l * (2 + 5 * t),
                          n = -14 + a + 6 * Math.sin(.2 * r + t);
                        e.beginPath(), e.moveTo(o, n), e.lineTo(o + 8 * Math.sin(.3 * r + 2 * t), n + 5 *
                          Math.cos(.25 * r + t)), e.stroke()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("neonWyrm" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 15, e.shadowColor = n, e.strokeStyle = n,
                        e.fillStyle = "#00ffff", e.lineWidth = 2.5;
                      let a = 5 * Math.sin(.07 * r);
                      e.globalAlpha = .9;
                      for (let t = 0; t < 8; t++) {
                        let o = -l * t * 9,
                          n = -18 + a + 6 * Math.sin(.12 * r + .7 * t),
                          i = 6 - .5 * t;
                        e.beginPath(), e.arc(o, n, i, 0, 2 * Math.PI), e.stroke()
                      }
                      e.beginPath(), e.arc(8 * l, -22 + a, 8, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        "#ffffff", e.beginPath(), e.arc(11 * l, -24 + a, 2.5, 0, 2 * Math.PI), e.fill(), e
                        .fillStyle = n, e.beginPath(), e.arc(11 * l, -24 + a, 1.5, 0, 2 * Math.PI), e
                      .fill();
                      let i = 10 * Math.sin(.12 * r);
                      e.strokeStyle = n, e.lineWidth = 2, e.beginPath(), e.moveTo(-5, -22 + a), e.lineTo(-
                          25, -38 + a + i), e.lineTo(-15, -16 + a), e.moveTo(5, -22 + a), e.lineTo(25, -38 +
                          a + i), e.lineTo(15, -16 + a), e.stroke(), e.globalAlpha = .12 + .06 * Math.sin(
                          .08 * r), e.fillStyle = n, e.beginPath(), e.arc(0, -18 + a, 30, 0, 2 * Math.PI), e
                        .fill(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("crystalMoth" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 10, e.shadowColor = s, e.strokeStyle = s,
                        e.fillStyle = "#88ffaa", e.lineWidth = 1.5;
                      let a = 5 * Math.sin(.13 * r);
                      e.beginPath(), e.ellipse(0, -12 + a, 4, 6, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(0, -20 + a, 3, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        "#ffffff", e.beginPath(), e.arc(-1.5, -21 + a, 1, 0, 2 * Math.PI), e.fill(), e
                        .beginPath(), e.arc(1.5, -21 + a, 1, 0, 2 * Math.PI), e.fill();
                      let l = 6 * Math.sin(.25 * r);
                      e.fillStyle = s, e.globalAlpha = .3, e.beginPath(), e.moveTo(-4, -16 + a), e.lineTo(-
                          16, -24 + a + l), e.lineTo(-14, -12 + a + .5 * l), e.closePath(), e.fill(), e
                        .stroke(), e.beginPath(), e.moveTo(4, -16 + a), e.lineTo(16, -24 + a + l), e.lineTo(
                          14, -12 + a + .5 * l), e.closePath(), e.fill(), e.stroke(), e.globalAlpha = .5 +
                        .3 * Math.sin(.1 * r), e.fillStyle = "#ffffff";
                      for (let t = 0; t < 3; t++) {
                        let o = 12 * Math.cos(.06 * r + 2 * t),
                          l = -16 + a + 8 * Math.sin(.08 * r + 1.5 * t);
                        e.beginPath(), e.arc(o, l, 1, 0, 2 * Math.PI), e.fill()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("zombie" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 8, e.shadowColor = "#44aa00", e
                        .strokeStyle = "#44aa00", e.lineWidth = 2.5;
                      let a = 3 * Math.sin(.08 * r);
                      e.beginPath(), e.arc(.3 * a, -40, 8, 0, 2 * Math.PI), e.stroke(), e.fillStyle =
                        "#88ff00", e.beginPath(), e.arc(2 * l + .3 * a, -41, 2, 0, 2 * Math.PI), e.fill(), e
                        .beginPath(), e.arc(-l + .3 * a, -41, 2, 0, 2 * Math.PI), e.fill(), e.beginPath(), e
                        .moveTo(.3 * a, -32), e.lineTo(.2 * a, -12), e.stroke(), e.lineWidth = 2, e
                        .beginPath(), e.moveTo(.2 * a, -26), e.lineTo(16 * l, -22 + a), e.stroke(), e
                        .beginPath(), e.moveTo(.2 * a, -26), e.lineTo(-(8 * l), -20), e.stroke(), e
                        .lineWidth = 2.5, e.beginPath(), e.moveTo(.2 * a, -12), e.lineTo(-8 + .5 * a, 2), e
                        .stroke(), e.beginPath(), e.moveTo(.2 * a, -12), e.lineTo(8 - .5 * a, 2), e
                      .stroke(), e.globalAlpha = .3, e.fillStyle = "#44aa00";
                      for (let t = 0; t < 3; t++) {
                        let o = 10 * Math.sin(.05 * r + 2 * t),
                          a = -20 + 8 * Math.cos(.07 * r + t);
                        e.beginPath(), e.arc(o, a, 2, 0, 2 * Math.PI), e.fill()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("giant" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 15, e.shadowColor = "#cc4400", e
                        .strokeStyle = "#cc4400", e.lineWidth = 6.4;
                      let a = 2 * Math.sin(.04 * r);
                      e.beginPath(), e.arc(a, -60.800000000000004, 19.200000000000003, 0, 2 * Math.PI), e
                        .stroke(), e.fillStyle = "#ff0000", e.beginPath(), e.arc(4 * l + a, -
                          62.400000000000006, 4.800000000000001, 0, 2 * Math.PI), e.fill(), e.beginPath(), e
                        .arc(-(2 * l) + a, -62.400000000000006, 4.800000000000001, 0, 2 * Math.PI), e
                      .fill(), e.beginPath(), e.moveTo(a, -41.6), e.lineTo(a, -12.8), e.stroke(), e
                        .lineWidth = 6.4, e.beginPath(), e.moveTo(a, -35.2), e.lineTo(22 * l * 1.6, -
                          22.400000000000002 + a), e.stroke(), e.beginPath(), e.moveTo(a, -35.2), e.lineTo(-
                          (18 * l * 1.6), -16), e.stroke(), e.lineWidth = 8, e.beginPath(), e.moveTo(a, -
                          12.8), e.lineTo(-16 + a, 6.4), e.stroke(), e.beginPath(), e.moveTo(a, -12.8), e
                        .lineTo(16 + a, 6.4), e.stroke(), e.globalAlpha = .15, e.fillStyle = "#ff4400", e
                        .beginPath(), e.ellipse(0, 4, 25, 5, 0, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 0,
                        e.globalAlpha = 1, e.restore()
                    } else if ("necromancer" === a) {
                      e.save(), e.translate(t, o), e.shadowBlur = 15, e.shadowColor = "#6600aa", e
                        .strokeStyle = "#6600aa", e.fillStyle = i, e.lineWidth = 2;
                      let a = 6 * Math.sin(.08 * r);
                      e.globalAlpha = .7, e.beginPath(), e.moveTo(-10, -5 + a), e.quadraticCurveTo(-12, -
                          30 + a, 0, -38 + a), e.quadraticCurveTo(12, -30 + a, 10, -5 + a), e.closePath(), e
                        .stroke(), e.globalAlpha = .15, e.fillStyle = "#6600aa", e.fill(), e.globalAlpha =
                        1, e.fillStyle = "#ffffff", e.beginPath(), e.arc(-3, -28 + a, 2.5, 0, 2 * Math.PI),
                        e.fill(), e.beginPath(), e.arc(3, -28 + a, 2.5, 0, 2 * Math.PI), e.fill(), e
                        .fillStyle = "#ff44ff", e.beginPath(), e.arc(-3, -28 + a, 1.2, 0, 2 * Math.PI), e
                        .fill(), e.beginPath(), e.arc(3, -28 + a, 1.2, 0, 2 * Math.PI), e.fill(), e
                        .strokeStyle = "#8844cc", e.lineWidth = 2, e.beginPath(), e.moveTo(12 * l, -32 + a),
                        e.lineTo(10 * l, 0 + a), e.stroke(), e.fillStyle = "#ff44ff", e.shadowColor =
                        "#ff44ff", e.shadowBlur = 12, e.beginPath(), e.arc(12 * l, -35 + a, 4, 0, 2 * Math
                          .PI), e.fill(), e.globalAlpha = .4, e.strokeStyle = "#ff44ff", e.lineWidth = 1;
                      for (let t = 0; t < 3; t++) {
                        let o = .06 * r + 2 * Math.PI / 3 * t,
                          l = 16 * Math.cos(o),
                          n = -20 + a + 10 * Math.sin(o);
                        e.beginPath(), e.arc(l, n, 3, 0, 2 * Math.PI), e.stroke()
                      }
                      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else if ("bomber" === a) {
                      e.save(), e.translate(t, o);
                      let a = .3 * Math.sin(.2 * r) + .7;
                      e.shadowBlur = 8 + 6 * Math.sin(.15 * r), e.shadowColor = f, e.strokeStyle = f, e
                        .lineWidth = 2;
                      let n = 3 * Math.sin(.4 * r);
                      e.beginPath(), e.arc(0, -38 + n, 7, 0, 2 * Math.PI), e.stroke(), e.fillStyle = d, e
                        .globalAlpha = a, e.beginPath(), e.arc(0, -46 + n, 3 + 2 * Math.sin(.3 * r), 0, 2 *
                          Math.PI), e.fill(), e.globalAlpha = 1, e.fillStyle = "#ffffff", e.beginPath(), e
                        .arc(-3, -39 + n, 1.5, 0, 2 * Math.PI), e.fill(), e.beginPath(), e.arc(3, -39 + n,
                          1.5, 0, 2 * Math.PI), e.fill(), e.strokeStyle = f, e.beginPath(), e.moveTo(0, -
                          31 + n), e.lineTo(0, -12 + n), e.stroke(), e.lineWidth = 1.5, e.beginPath(), e
                        .moveTo(0, -26 + n), e.lineTo(14 * l, -22 + n), e.stroke(), e.beginPath(), e.moveTo(
                          0, -26 + n), e.lineTo(-(8 * l), -20 + n), e.stroke(), e.lineWidth = 2;
                      let i = 12 * Math.sin(.4 * r);
                      e.beginPath(), e.moveTo(0, -12 + n), e.lineTo(-6 + .4 * i, 0 + n), e.stroke(), e
                        .beginPath(), e.moveTo(0, -12 + n), e.lineTo(6 - .4 * i, 0 + n), e.stroke(), e
                        .globalAlpha = .1 + .08 * Math.sin(.25 * r), e.fillStyle = "#ff0000", e.beginPath(),
                        e.arc(0, -22 + n, 20 + 5 * Math.sin(.2 * r), 0, 2 * Math.PI), e.fill(), e
                        .shadowBlur = 0, e.globalAlpha = 1, e.restore()
                    } else eE(e, t + ("glitchWalker" === a ? 3 * Math.sin(.5 * r) : 0), o, l, m, r, !1, u,
                      .9, "angry", !0)
                  }(e, a + o.width / 2, o.y, o.type, o.facing, o.animFrame, o.grounded);
                  if (o.isHit) {
                    e.save(), e.globalAlpha = .5, e.fillStyle = "#ffffff";
                    let t = ez(o.type);
                    e.fillRect(a, o.y - t, o.width, t), e.globalAlpha = 1, e.restore()
                  }
                }
              }
              let H = E.x - G + E.width / 2,
                U = E.y,
                V = E.skinColor || n;
              if ((E.invincible <= 0 || F.current % 4 < 2) && E.health > 0 && eE(e, H, U, E.facing, V, E
                  .animFrame, E.isShooting, E.grounded, 1, E.expression, E.isMoving, !1, E.vx, E.skinEffect ||
                  ""), L && L.health > 0) {
                let t = L.x - G + L.width / 2,
                  o = L.y;
                (L.invincible <= 0 || F.current % 4 < 2) && eE(e, t, o, L.facing, L.skinColor, L.animFrame, L
                    .isShooting, L.grounded, 1, L.expression, L.isMoving, !1, L.vx, L.skinEffect || ""), e
                  .save(), e.globalAlpha = .7, e.shadowBlur = 5, e.shadowColor = c, e.fillStyle = c, e.font =
                  "8px monospace", e.textAlign = "center", e.fillText("P2", t, L.y - 55), e.shadowBlur = 0, e
                  .globalAlpha = 1, e.restore();
                let a = Math.max(0, L.health / L.maxHealth);
                e.save(), e.globalAlpha = .8, e.fillStyle = "#1a0a00", e.fillRect(t - 15, L.y - 60, 30, 4), e
                  .fillStyle = c, e.shadowBlur = 3, e.shadowColor = c, e.fillRect(t - 15, L.y - 60, 30 * a,
                  4), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
              }
              for (let o of es.current) {
                if (!o.active) continue;
                let a = o.x - G;
                a < -50 || a > t + 50 || (eE(e, a, o.y, o.facing, o.color, o.animFrame, o.shootCooldown > 10,
                    o.grounded, .85, o.expression, !0, !1, 0, ""), e.save(), e.globalAlpha = .6, e
                  .shadowBlur = 5, e.shadowColor = o.color, e.fillStyle = o.color, e.font = "8px monospace",
                  e.textAlign = "center", e.fillText(o.name, a, o.y - 55), e.shadowBlur = 0, e.globalAlpha =
                  1, e.restore())
              }
              let z = ec.current;
              if (z && z.active) {
                let o = z.x - G;
                if (o > -50 && o < t + 50) {
                  ! function(e, t, o, a, l, r, n) {
                    e.save(), e.shadowBlur = 8, e.shadowColor = l, e.strokeStyle = l, e.fillStyle = l, e
                      .lineWidth = 1.5;
                    let s = 3 * Math.sin(.08 * r);
                    if ("neonWolf" === a) e.beginPath(), e.ellipse(t, o - 10 + s, 8, 5, 0, 0, 2 * Math.PI), e
                      .stroke(), e.beginPath(), e.arc(t + 10 * n, o - 15 + s, 5, 0, 2 * Math.PI), e.stroke(),
                      e.beginPath(), e.moveTo(t + 8 * n, o - 19 + s), e.lineTo(t + 6 * n, o - 24 + s), e
                      .moveTo(t + 13 * n, o - 19 + s), e.lineTo(t + 14 * n, o - 24 + s), e.stroke(), e
                      .fillStyle = "#ffffff", e.beginPath(), e.arc(t + 12 * n, o - 15 + s, 1.5, 0, 2 * Math
                        .PI), e.fill(), e.beginPath(), e.moveTo(t - 8 * n, o - 10 + s), e.quadraticCurveTo(t -
                        14 * n, o - 20 + s + 3 * Math.sin(.15 * r), t - 16 * n, o - 16 + s), e.stroke();
                    else if ("plasmaFalcon" === a) {
                      e.beginPath(), e.ellipse(t, o - 12 + s, 6, 4, 0, 0, 2 * Math.PI), e.stroke();
                      let a = 6 * Math.sin(.2 * r);
                      e.beginPath(), e.moveTo(t - 5, o - 12 + s), e.lineTo(t - 16, o - 18 + s + a), e.lineTo(
                          t - 8, o - 8 + s), e.moveTo(t + 5, o - 12 + s), e.lineTo(t + 16, o - 18 + s + a), e
                        .lineTo(t + 8, o - 8 + s), e.stroke(), e.beginPath(), e.arc(t + 8 * n, o - 16 + s, 3,
                          0, 2 * Math.PI), e.stroke(), e.fillStyle = "#ffffff", e.beginPath(), e.arc(t + 9 *
                          n, o - 16 + s, 1.2, 0, 2 * Math.PI), e.fill(), e.beginPath(), e.moveTo(t + 11 * n,
                          o - 16 + s), e.lineTo(t + 14 * n, o - 15 + s), e.stroke()
                    } else if ("shadowSpider" === a) {
                      e.beginPath(), e.arc(t, o - 10 + s, 6, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e
                        .arc(t + 6 * n, o - 14 + s, 4, 0, 2 * Math.PI), e.stroke();
                      for (let a = 0; a < 4; a++) {
                        let l = 2 * Math.sin(.15 * r + a);
                        e.beginPath(), e.moveTo(t - 4, o - 8 + s), e.lineTo(t - 12 + l, o - 2 + 2 * a + s), e
                          .moveTo(t + 4, o - 8 + s), e.lineTo(t + 12 - l, o - 2 + 2 * a + s), e.stroke()
                      }
                      e.fillStyle = "#ff0000", e.beginPath(), e.arc(t + 7 * n, o - 15 + s, 1.5, 0, 2 * Math
                        .PI), e.arc(t + 5 * n, o - 15 + s, 1.5, 0, 2 * Math.PI), e.fill()
                    } else if ("crystalGolem" === a) e.beginPath(), e.moveTo(t - 7, o + s), e.lineTo(t - 9,
                        o - 10 + s), e.lineTo(t, o - 18 + s), e.lineTo(t + 9, o - 10 + s), e.lineTo(t + 7, o +
                        s), e.closePath(), e.stroke(), e.beginPath(), e.moveTo(t - 9, o - 8 + s), e.lineTo(t -
                        14, o - 14 + s + 2 * Math.sin(.1 * r)), e.moveTo(t + 9, o - 8 + s), e.lineTo(t + 14,
                        o - 14 + s - 2 * Math.sin(.1 * r)), e.stroke(), e.fillStyle = l, e.shadowBlur = 12, e
                      .beginPath(), e.arc(t + 2 * n, o - 13 + s, 2, 0, 2 * Math.PI), e.fill();
                    else if ("voidDrake" === a) {
                      e.beginPath(), e.ellipse(t, o - 10 + s, 9, 5, 0, 0, 2 * Math.PI), e.stroke();
                      let a = 8 * Math.sin(.15 * r);
                      e.beginPath(), e.moveTo(t - 6, o - 12 + s), e.lineTo(t - 18, o - 22 + s + a), e.lineTo(
                          t - 10, o - 6 + s), e.moveTo(t + 6, o - 12 + s), e.lineTo(t + 18, o - 22 + s + a), e
                        .lineTo(t + 10, o - 6 + s), e.stroke(), e.beginPath(), e.arc(t + 12 * n, o - 14 + s,
                          4, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e.moveTo(t + 10 * n, o - 18 + s), e
                        .lineTo(t + 8 * n, o - 24 + s), e.moveTo(t + 14 * n, o - 17 + s), e.lineTo(t + 16 * n,
                          o - 23 + s), e.stroke(), e.fillStyle = i, e.beginPath(), e.arc(t + 13 * n, o - 14 +
                          s, 1.5, 0, 2 * Math.PI), e.fill(), e.beginPath(), e.moveTo(t - 9 * n, o - 10 + s), e
                        .quadraticCurveTo(t - 16 * n, o - 6 + s + 4 * Math.sin(.12 * r), t - 20 * n, o - 10 +
                          s), e.stroke()
                    } else if ("neonCat" === a) e.beginPath(), e.ellipse(t, o - 10 + s, 7, 5, 0, 0, 2 * Math
                        .PI), e.stroke(), e.beginPath(), e.arc(t + 8 * n, o - 15 + s, 5, 0, 2 * Math.PI), e
                      .stroke(), e.beginPath(), e.moveTo(t + 5 * n, o - 19 + s), e.lineTo(t + 4 * n, o - 26 +
                        s), e.lineTo(t + 8 * n, o - 20 + s), e.moveTo(t + 11 * n, o - 19 + s), e.lineTo(t +
                        12 * n, o - 26 + s), e.lineTo(t + 14 * n, o - 20 + s), e.stroke(), e.shadowBlur = 12,
                      e.fillStyle = "#ffffff", e.beginPath(), e.arc(t + 9 * n, o - 15 + s, 1.5, 0, 2 * Math
                        .PI), e.fill(), e.beginPath(), e.arc(t + 7 * n, o - 15 + s, 1.5, 0, 2 * Math.PI), e
                      .fill(), e.beginPath(), e.moveTo(t - 7 * n, o - 10 + s), e.bezierCurveTo(t - 12 * n, o -
                        18 + s + 3 * Math.sin(.15 * r), t - 18 * n, o - 6 + s - 3 * Math.sin(.15 * r), t -
                        20 * n, o - 14 + s), e.stroke();
                    else if ("thunderBird" === a) {
                      e.beginPath(), e.ellipse(t, o - 12 + s, 7, 4, 0, 0, 2 * Math.PI), e.stroke();
                      let a = 7 * Math.sin(.25 * r);
                      e.beginPath(), e.moveTo(t - 5, o - 12 + s), e.lineTo(t - 14, o - 20 + s + a), e.lineTo(
                          t - 8, o - 10 + s), e.moveTo(t + 5, o - 12 + s), e.lineTo(t + 14, o - 20 + s + a), e
                        .lineTo(t + 8, o - 10 + s), e.stroke(), e.shadowBlur = 14;
                      let l = t - 14,
                        i = t + 14,
                        c = o - 20 + s + a;
                      e.beginPath(), e.moveTo(l, c), e.lineTo(l - 2, c + 4), e.lineTo(l + 1, c + 3), e.lineTo(
                          l - 1, c + 7), e.moveTo(i, c), e.lineTo(i + 2, c + 4), e.lineTo(i - 1, c + 3), e
                        .lineTo(i + 1, c + 7), e.stroke(), e.beginPath(), e.arc(t + 9 * n, o - 16 + s, 3, 0,
                          2 * Math.PI), e.stroke(), e.fillStyle = "#ffffff", e.beginPath(), e.arc(t + 10 * n,
                          o - 16 + s, 1.2, 0, 2 * Math.PI), e.fill(), e.beginPath(), e.moveTo(t + 12 * n, o -
                          16 + s), e.lineTo(t + 15 * n, o - 15 + s), e.stroke()
                    } else if ("iceFox" === a) {
                      e.beginPath(), e.ellipse(t, o - 10 + s, 8, 5, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.moveTo(t + 8 * n, o - 20 + s), e.lineTo(t + 14 * n, o - 14 + s), e
                        .lineTo(t + 8 * n, o - 10 + s), e.closePath(), e.stroke(), e.beginPath(), e.moveTo(t +
                          6 * n, o - 19 + s), e.lineTo(t + 4 * n, o - 26 + s), e.lineTo(t + 9 * n, o - 20 +
                        s), e.moveTo(t + 11 * n, o - 19 + s), e.lineTo(t + 13 * n, o - 26 + s), e.lineTo(t +
                          10 * n, o - 20 + s), e.stroke(), e.shadowBlur = 12, e.fillStyle = "#ffffff", e
                        .beginPath(), e.arc(t + 10 * n, o - 15 + s, 1.3, 0, 2 * Math.PI), e.fill(), e
                        .beginPath(), e.moveTo(t - 8 * n, o - 10 + s), e.quadraticCurveTo(t - 16 * n, o - 18 +
                          s + 4 * Math.sin(.1 * r), t - 20 * n, o - 14 + s), e.quadraticCurveTo(t - 16 * n,
                          o - 8 + s - 2 * Math.sin(.1 * r), t - 8 * n, o - 8 + s), e.stroke(), e.shadowBlur =
                        6, e.fillStyle = "#ffffff";
                      for (let a = 0; a < 3; a++) {
                        let l = t + 14 * Math.sin(.08 * r + 2.1 * a),
                          n = o - 14 + 8 * Math.cos(.1 * r + 1.7 * a) + s;
                        e.beginPath(), e.arc(l, n, 1, 0, 2 * Math.PI), e.fill()
                      }
                    } else if ("magmaSnail" === a) {
                      e.beginPath(), e.arc(t, o - 14 + s, 9, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e
                        .arc(t - 2, o - 14 + s, 6, 0, 1.5 * Math.PI), e.stroke(), e.beginPath(), e.arc(t + 1,
                          o - 14 + s, 3, 0, 1.5 * Math.PI), e.stroke(), e.beginPath(), e.ellipse(t + 8 * n,
                          o - 6 + s, 6, 3, 0, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e.moveTo(t + 10 * n,
                          o - 8 + s), e.lineTo(t + 12 * n, o - 16 + s + 2 * Math.sin(.1 * r)), e.moveTo(t +
                          13 * n, o - 8 + s), e.lineTo(t + 15 * n, o - 16 + s - 2 * Math.sin(.1 * r)), e
                        .stroke(), e.fillStyle = "#ffffff", e.beginPath(), e.arc(t + 12 * n, o - 16 + s + 2 *
                          Math.sin(.1 * r), 1.2, 0, 2 * Math.PI), e.arc(t + 15 * n, o - 16 + s - 2 * Math.sin(
                          .1 * r), 1.2, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 10, e.fillStyle = "#ff4400";
                      for (let a = 0; a < 3; a++) {
                        let l = t + 10 * Math.cos(.12 * r + 2.09 * a),
                          n = o - 14 + 8 * Math.sin(.15 * r + 2.09 * a) + s;
                        e.beginPath(), e.arc(l, n, 1.5 - .3 * a, 0, 2 * Math.PI), e.fill()
                      }
                    } else if ("cosmicOwl" === a) {
                      e.beginPath(), e.ellipse(t, o - 10 + s, 8, 7, 0, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.arc(t + 4 * n, o - 18 + s, 6, 0, 2 * Math.PI), e.stroke(), e
                        .beginPath(), e.moveTo(t + 0 * n, o - 23 + s), e.lineTo(t - 2 * n, o - 30 + s), e
                        .lineTo(t + 3 * n, o - 24 + s), e.moveTo(t + 8 * n, o - 23 + s), e.lineTo(t + 10 * n,
                          o - 30 + s), e.lineTo(t + 6 * n, o - 24 + s), e.stroke(), e.shadowBlur = 14, e
                        .fillStyle = "#ffffff", e.beginPath(), e.arc(t + 6 * n, o - 18 + s, 2, 0, 2 * Math
                        .PI), e.fill(), e.beginPath(), e.arc(t + 2 * n, o - 18 + s, 2, 0, 2 * Math.PI), e
                        .fill(), e.fillStyle = l, e.beginPath(), e.arc(t + 6 * n, o - 18 + s, 1, 0, 2 * Math
                          .PI), e.fill(), e.beginPath(), e.arc(t + 2 * n, o - 18 + s, 1, 0, 2 * Math.PI), e
                        .fill();
                      let a = 4 * Math.sin(.12 * r);
                      e.beginPath(), e.moveTo(t - 6, o - 10 + s), e.lineTo(t - 14, o - 14 + s + a), e.lineTo(
                          t - 8, o - 4 + s), e.moveTo(t + 6, o - 10 + s), e.lineTo(t + 14, o - 14 + s + a), e
                        .lineTo(t + 8, o - 4 + s), e.stroke(), e.shadowBlur = 8, e.fillStyle = "#ffffff";
                      for (let a = 0; a < 4; a++) {
                        let l = t + 5 * Math.cos(1.57 * a + .02 * r),
                          n = o - 10 + 4 * Math.sin(1.57 * a + .02 * r) + s;
                        e.beginPath(), e.arc(l, n, .8, 0, 2 * Math.PI), e.fill()
                      }
                    }
                    e.shadowBlur = 0, e.restore()
                  }(e, o, z.y, z.type, z.skinColor, z.animFrame, z.facing), e.save(), e.globalAlpha = .7;
                  let t = Math.max(0, z.health / z.maxHealth);
                  e.fillStyle = "#001a00", e.fillRect(o - 12, z.y - 30, 24, 3), e.fillStyle = t > .5 ? s : t >
                    .25 ? c : f, e.shadowBlur = 3, e.shadowColor = e.fillStyle, e.fillRect(o - 12, z.y - 30,
                      24 * t, 3), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
                }
              }
              for (let o of ek.current) {
                if (o.collected) continue;
                let a = o.x - G;
                if (a < -20 || a > t + 20) continue;
                let l = 4 * Math.sin(.06 * o.animFrame),
                  r = .3 * Math.sin(.12 * o.animFrame) + .7;
                e.save(), e.globalAlpha = r, e.shadowBlur = 12, e.shadowColor = m, e.fillStyle = m, e
                  .beginPath(), e.arc(a, o.y + l, 8, 0, 2 * Math.PI), e.fill(), e.strokeStyle = "#fff8dc", e
                  .lineWidth = 1, e.beginPath(), e.arc(a, o.y + l, 5, 0, 2 * Math.PI), e.stroke(), e
                  .globalAlpha = .5 * r, e.fillStyle = "#ffffff", e.beginPath(), e.arc(a + 3, o.y + l - 3,
                    1.5, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
              }
              for (let o of e2.current) {
                if (o.opened) continue;
                let a = o.x - G;
                a < -30 || a > t + 30 || (e.save(), e.shadowBlur = 15, e.shadowColor = "skill" === o.reward ?
                  h : m, e.strokeStyle = "skill" === o.reward ? h : m, e.lineWidth = 2, e.strokeRect(a - 12,
                    o.y - 12, 24, 20), e.beginPath(), e.moveTo(a - 14, o.y - 12), e.lineTo(a, o.y - 20), e
                  .lineTo(a + 14, o.y - 12), e.stroke(), e.fillStyle = "skill" === o.reward ? i : "#ffd700",
                  e.beginPath(), e.arc(a, o.y - 4, 3, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 0, e
                  .restore())
              }
              let _ = eS.current;
              if (_.active) {
                let t, o = _.x - G;
                a = _.y - 30, t = .3 * Math.sin(.05 * (l = F.current)) + .7, e.shadowBlur = 25, e
                  .shadowColor = s, e.globalAlpha = .3 * t, e.beginPath(), e.arc(o, a, 35, 0, 2 * Math.PI), e
                  .fillStyle = s, e.fill(), e.globalAlpha = .8 * t, e.beginPath(), e.arc(o, a, 18, 0, 2 * Math
                    .PI), e.fill(), e.globalAlpha = 1, e.strokeStyle = s, e.lineWidth = 2, e.beginPath(), e
                  .arc(o, a, 22 + 5 * Math.sin(.08 * l), 0, 2 * Math.PI), e.stroke(), e.globalAlpha = .5, e
                  .strokeStyle = "#ffffff", e.lineWidth = 1, e.beginPath(), e.arc(o, a, 12 + 3 * Math.sin(
                    .12 * l), 0, 2 * Math.PI), e.stroke(), e.shadowBlur = 0, e.globalAlpha = 1
              } else {
                let o = _.x - G;
                if (o > -100 && o < t + 100) {
                  let t = 5 * Math.sin(.06 * F.current);
                  e.save(), e.globalAlpha = .4 + .2 * Math.sin(.04 * F.current), e.shadowBlur = 8, e
                    .shadowColor = f, e.fillStyle = f, e.font = "bold 9px monospace", e.textAlign = "center",
                    e.fillText("CLEAR ALL", o, _.y - 65 + t), e.fillText("ENEMIES", o, _.y - 53 + t), e
                    .beginPath(), e.moveTo(o + 10, _.y - 40 + t), e.lineTo(o - 5, _.y - 46 + t), e.lineTo(o -
                      5, _.y - 34 + t), e.closePath(), e.fill(), e.shadowBlur = 0, e.globalAlpha = 1, e
                    .restore()
                }
              }
              if (E.isShielding && (e.save(), e.globalAlpha = .3 + .15 * Math.sin(.1 * F.current), e
                  .shadowBlur = 20, e.shadowColor = s, e.strokeStyle = s, e.lineWidth = 2, e.beginPath(), e
                  .arc(H, U - 25, 35, 0, 2 * Math.PI), e.stroke(), e.globalAlpha = .1, e.fillStyle = s, e
                  .fill(), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()), L && L.isShielding) {
                let t = L.x - G + L.width / 2;
                e.save(), e.globalAlpha = .3 + .15 * Math.sin(.1 * F.current), e.shadowBlur = 20, e
                  .shadowColor = c, e.strokeStyle = c, e.lineWidth = 2, e.beginPath(), e.arc(t, L.y - 25, 35,
                    0, 2 * Math.PI), e.stroke(), e.globalAlpha = .1, e.fillStyle = c, e.fill(), e.shadowBlur =
                  0, e.globalAlpha = 1, e.restore()
              }
              if (E.isDashing) {
                e.save(), e.globalAlpha = .3, e.strokeStyle = n, e.lineWidth = 1.5;
                for (let t = 1; t <= 3; t++) {
                  let o = -E.facing * t * 12;
                  e.globalAlpha = .3 - .08 * t, e.beginPath(), e.moveTo(H + o, -38), e.lineTo(H + o + 2 * E
                    .facing, -29), e.lineTo(H + o, -10), e.stroke()
                }
                e.globalAlpha = 1, e.restore()
              }
              if (L && L.isDashing) {
                let t = L.x - G + L.width / 2;
                e.save(), e.globalAlpha = .3, e.strokeStyle = c, e.lineWidth = 1.5;
                for (let o = 1; o <= 3; o++) {
                  let a = -L.facing * o * 12;
                  e.globalAlpha = .3 - .08 * o, e.beginPath(), e.moveTo(t + a, -38), e.lineTo(t + a + 2 * L
                    .facing, -29), e.lineTo(t + a, -10), e.stroke()
                }
                e.globalAlpha = 1, e.restore()
              }
              for (let o of D.current) {
                if (!o.active) continue;
                let a = o.x - G;
                a < -20 || a > t + 20 || (r = o.y, x = o.radius, g = o.color, e.shadowBlur = 10, e
                  .shadowColor = g, e.globalAlpha = .35, e.beginPath(), e.arc(a, r, 2.5 * x, 0, 2 * Math
                  .PI), e.fillStyle = g, e.fill(), e.globalAlpha = 1, e.beginPath(), e.arc(a, r, x, 0, 2 *
                    Math.PI), e.fillStyle = "#ffffff", e.fill(), e.globalAlpha = .8, e.beginPath(), e.arc(a,
                    r, 1.2 * x, 0, 2 * Math.PI), e.fillStyle = g, e.fill(), e.shadowBlur = 0)
              }
              for (let o of W.current) {
                let a = o.x - G;
                a < -20 || a > t + 20 || (y = o.y, b = o.size * (o.life / o.maxLife), v = o.color, e
                  .globalAlpha = o.life / o.maxLife, e.shadowBlur = 5, e.shadowColor = v, e.fillStyle = v, e
                  .beginPath(), e.arc(a, y, b, 0, 2 * Math.PI), e.fill(), e.shadowBlur = 0)
              }
            },
            te = (e, t, o) => {
              let a = j.current,
                l = N.current,
                r = B.current;
              if (!a || !r) return;
              let i = "versus" === ea.getState().gameMode;
              e.save(), e.globalAlpha = .9;
              let h = Math.min(180, .25 * t);
              e.fillStyle = "#001a00", e.fillRect(16, 16, h, 12), e.strokeStyle = s, e.lineWidth = 1, e
                .shadowBlur = 5, e.shadowColor = s, e.strokeRect(16, 16, h, 12);
              let u = Math.max(0, a.health / a.maxHealth),
                x = u > .5 ? s : u > .25 ? c : f;
              if (e.fillStyle = x, e.shadowColor = x, e.shadowBlur = 8, e.fillRect(17, 17, (h - 2) * u, 10), e
                .shadowColor = s, e.shadowBlur = 5, e.fillStyle = s, e.font = "bold 10px monospace", e
                .textAlign = "left", e.fillText("P1 HP", 16, 12), l) {
                e.fillStyle = "#1a0a00", e.fillRect(16, 38, h, 12), e.strokeStyle = c, e.shadowColor = c, e
                  .strokeRect(16, 38, h, 12);
                let t = Math.max(0, l.health / l.maxHealth);
                e.fillStyle = t > .5 ? c : t > .25 ? d : f, e.shadowColor = e.fillStyle, e.fillRect(17, 39, (
                    h - 2) * t, 10), e.fillStyle = c, e.shadowColor = c, e.font = "bold 10px monospace", e
                  .fillText("P2 HP", 16, 34)
              }
              let p = G.find(e => e.id === r.id);
              if (p) {
                e.shadowColor = n, e.shadowBlur = 5, e.fillStyle = n, e.font = "10px monospace", e.textAlign =
                  "center", e.fillText(p.chapter, t / 2, 20), e.font = "bold 12px monospace", e.fillText(p
                    .name, t / 2, 34);
                let o = ea.getState();
                e.font = "9px monospace", e.fillStyle = d, e.shadowColor = d, e.shadowBlur = 3, e.fillText(
                  `WAVE ${o.currentWave+1}/${o.totalWaves}`, t / 2, 48)
              }
              if (eC.current > 0 && (e.shadowColor = m, e.shadowBlur = 5, e.fillStyle = m, e.font =
                  "10px monospace", e.textAlign = "right", e.fillText(`🪙 ${eC.current}`, t - 16, 62)), e
                .shadowColor = c, e.shadowBlur = 5, e.fillStyle = c, e.font = "10px monospace", e.textAlign =
                "right", e.fillText("SCORE", t - 16, 20), e.font = "bold 12px monospace", e.fillText(String(z
                  .current), t - 16, 34), l)
                if (e.font = "9px monospace", i) {
                  e.fillStyle = f, e.shadowColor = f;
                  let o = ea.getState();
                  e.fillText(`VS R${o.versusCurrentRound}`, t - 16, 48), e.font = "8px monospace", e
                    .fillStyle = n, e.fillText(`P1:${o.versusP1Wins}`, t - 46, 60), e.fillStyle = c, e
                    .fillText(`P2:${o.versusP2Wins}`, t - 16, 60)
                } else e.fillStyle = c, e.shadowColor = c, e.fillText("CO-OP", t - 16, 48);
              let g = I.current.find(e => e.active && ("boss" === e.type || "bossRedKing" === e.type ||
                "bossTitan" === e.type || "bossDragon" === e.type || "bossPhoenix" === e.type ||
                "bossMechGolem" === e.type || "bossCorrupted" === e.type || "bossFather" === e.type ||
                "bossTwin" === e.type));
              if (g) {
                let a = Math.min(300, .5 * t),
                  l = (t - a) / 2,
                  r = o - 16 - 12,
                  n = g.bossName || "BOSS",
                  i = g.bossColor || f;
                e.globalAlpha = .9, e.shadowBlur = 10, e.shadowColor = i, e.fillStyle = i, e.font =
                  "bold 12px monospace", e.textAlign = "center", e.fillText(n, t / 2, r - 6), e.globalAlpha =
                  .8, e.fillStyle = "#1a0000", e.fillRect(l, r, a, 16);
                let s = Math.max(0, g.health / g.maxHealth),
                  h = s > .5 ? f : s > .25 ? c : d,
                  u = e.createLinearGradient(l, r, l + a * s, r);
                u.addColorStop(0, h), u.addColorStop(1, f), e.fillStyle = u, e.shadowBlur = 10, e
                  .shadowColor = h, e.fillRect(l + 1, r + 1, (a - 2) * s, 14), e.globalAlpha = .3, e
                  .strokeStyle = "#ffffff", e.lineWidth = 1, e.shadowBlur = 0;
                for (let t = 1; t < 10; t++) {
                  let o = l + a / 10 * t;
                  e.beginPath(), e.moveTo(o, r), e.lineTo(o, r + 16), e.stroke()
                }
                e.globalAlpha = .9, e.strokeStyle = i, e.lineWidth = 2, e.shadowBlur = 8, e.shadowColor = i, e
                  .strokeRect(l, r, a, 16), g.enraged && (e.globalAlpha = .3 * Math.sin(.2 * F.current) + .7,
                    e.fillStyle = "#ff0000", e.shadowBlur = 15, e.shadowColor = "#ff0000", e.font =
                    "bold 10px monospace", e.textAlign = "center", e.fillText("⚠ ENRAGED ⚠", t / 2, r + 16 +
                      14)), e.globalAlpha = .7, e.fillStyle = "#ffffff", e.font = "bold 9px monospace", e
                  .shadowBlur = 0, e.fillText(`${Math.ceil(100*s)}%`, l + a / 2, r + 16 - 3)
              }
              e.shadowBlur = 0, e.globalAlpha = 1, e.restore();
              let y = eS.current,
                b = y.x - a.x,
                v = t - 40,
                w = o / 2,
                k = 5 * Math.sin(.08 * F.current);
              e.save(), b > 400 && !i ? (e.globalAlpha = .6 + .3 * Math.sin(.06 * F.current), e.shadowBlur =
                15, e.shadowColor = y.active ? s : d, e.fillStyle = y.active ? s : d, e.beginPath(), e
                .moveTo(v + 15, w + k), e.lineTo(v - 8, w - 10 + k), e.lineTo(v - 8, w + 10 + k), e
                .closePath(), e.fill(), e.font = "8px monospace", e.textAlign = "center", e.fillText(
                  `${Math.floor(b/100)}m`, v + 3, w + 22 + k)) : (e.globalAlpha = .4 + .2 * Math.sin(.06 * F
                  .current), e.shadowBlur = 10, e.shadowColor = s, e.fillStyle = s, e.beginPath(), e.moveTo(
                  v + 12, w + k), e.lineTo(v - 6, w - 8 + k), e.lineTo(v - 6, w + 8 + k), e.closePath(), e
                .fill()), e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
            };
          return requestAnimationFrame(A), () => {
            cancelAnimationFrame(r.current), window.removeEventListener("resize", o), window
              .removeEventListener("orientationchange", a), window.visualViewport && window.visualViewport
              .removeEventListener("resize", o), C()
          }
        }, [ea, e3, eX, eQ]), (0, o.jsx)("canvas", {
          ref: l,
          className: "absolute top-0 left-0 w-full h-full",
          style: {
            touchAction: "none"
          }
        })
      });

    function eY() {
      return window.__neonWarriorControls
    }

    function eJ(e = 10) {
      try {
        navigator.vibrate?.(e)
      } catch {}
    }
    let eZ = {
        fire: "🔥",
        frost: "❄️",
        shadow: "👤",
        summon: "👻",
        death: "💀",
        lightning: "⚡",
        void: "🌀",
        blood: "🩸"
      },
      eX = {
        fire: "#ff4400",
        frost: "#88eeff",
        shadow: "#8800ff",
        summon: "#aa00ff",
        death: "#660066",
        lightning: "#ffff00",
        void: "#ff00ff",
        blood: "#cc0000"
      },
      eQ = [1, .9, .8, .7, .6];

    function e0({
      cooldownFrames: e,
      maxCooldown: t,
      size: a
    }) {
      if (e <= 0 || t <= 0) return null;
      let l = e / t,
        r = Math.ceil(e / 60),
        n = a / 2,
        i = -Math.PI / 2,
        s = i + 2 * l * Math.PI,
        c = n + n * Math.cos(i),
        d = n + n * Math.sin(i),
        h = n + n * Math.cos(s),
        f = n + n * Math.sin(s),
        u = l >= .999 ? `M ${n} ${n} L ${c} ${d} A ${n} ${n} 0 1 1 ${n-.01} ${d} Z` :
        `M ${n} ${n} L ${c} ${d} A ${n} ${n} 0 ${+(l>.5)} 1 ${h} ${f} Z`;
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 flex items-center justify-center pointer-events-none",
        style: {
          width: a,
          height: a
        },
        children: [(0, o.jsx)("svg", {
          width: a,
          height: a,
          viewBox: `0 0 ${a} ${a}`,
          className: "absolute",
          style: {
            transform: "rotate(0deg)"
          },
          children: (0, o.jsx)("path", {
            d: u,
            fill: "rgba(0,0,0,0.7)"
          })
        }), (0, o.jsxs)("span", {
          className: "absolute font-bold text-white z-10",
          style: {
            fontSize: a < 60 ? 11 : 14,
            textShadow: "0 0 4px rgba(0,0,0,0.8)"
          },
          children: [r, "s"]
        })]
      })
    }

    function e1({
      icon: e,
      label: t,
      color: l,
      size: r,
      cooldownFrames: n,
      maxCooldown: i,
      onPressStart: s,
      onPressEnd: c,
      pulseEffect: d = !1,
      style: h
    }) {
      let f = n > 0,
        u = f ? .4 : 1,
        m = (0, a.useCallback)(e => {
          e.preventDefault(), e.stopPropagation(), f || (eJ(12), s())
        }, [f, s]),
        x = (0, a.useCallback)(e => {
          e.preventDefault(), e.stopPropagation(), c?.()
        }, [c]),
        p = .3 * !f,
        g = f ? .2 : .6,
        y = f ? .04 : .1;
      return (0, o.jsxs)("div", {
        className: "relative select-none",
        style: {
          width: r,
          height: r,
          touchAction: "none"
        },
        children: [(0, o.jsx)("button", {
          className: "flex items-center justify-center rounded-full active:scale-90 transition-transform select-none font-bold relative overflow-hidden",
          style: {
            width: r,
            height: r,
            backgroundColor: `rgba(${e2(l)}, ${y})`,
            border: `2.5px solid rgba(${e2(l)}, ${g})`,
            color: l,
            textShadow: `0 0 6px ${l}`,
            fontSize: r < 60 ? "20px" : r < 80 ? "24px" : "28px",
            boxShadow: f ? "none" : `0 0 ${r/4}px rgba(${e2(l)}, ${p})`,
            opacity: u,
            touchAction: "none",
            animation: d && !f ? "touch-btn-pulse 2s ease-in-out infinite" : "none",
            ...h
          },
          onTouchStart: m,
          onTouchEnd: x,
          onTouchCancel: x,
          "aria-label": t,
          children: e
        }), (0, o.jsx)(e0, {
          cooldownFrames: n,
          maxCooldown: i,
          size: r
        }), (0, o.jsx)("div", {
          className: "absolute -bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap",
          style: {
            fontSize: 7,
            color: `rgba(${e2(l)}, ${f?.3:.6})`,
            fontWeight: 700,
            letterSpacing: "0.05em"
          },
          children: t
        })]
      })
    }

    function e2(e) {
      let t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
      return t ? `${parseInt(t[1],16)},${parseInt(t[2],16)},${parseInt(t[3],16)}` : "255,255,255"
    }

    function e5() {
      let e = ea(e => e.gamePhase),
        t = ea(e => e.currentLevel);
      ea(e => e.dashCooldown), ea(e => e.shieldCooldown), ea(e => e.specialCooldown), ea(e => e.saveData);
      let a = ea(e => e.setGamePhase);
      return "playing" === e || "settings" === e && t > 0 ? "settings" === e && t > 0 ? (0, o.jsx)(e3, {
        onResume: () => a("playing")
      }) : (0, o.jsx)(e4, {}) : null
    }

    function e3({
      onResume: e
    }) {
      let t = ea(e => e.backToMenu);
      return (0, o.jsx)("div", {
        className: "absolute inset-0 z-30 flex items-center justify-center pointer-events-auto",
        style: {
          backgroundColor: "rgba(0,0,0,0.75)",
          touchAction: "none"
        },
        children: (0, o.jsxs)("div", {
          className: "flex flex-col items-center gap-6",
          children: [(0, o.jsx)("div", {
            className: "text-3xl font-bold tracking-widest",
            style: {
              color: n,
              textShadow: `0 0 20px ${n}`
            },
            children: "⏸ PAUSED"
          }), (0, o.jsx)("button", {
            className: "px-8 py-3 rounded-xl font-bold text-lg tracking-wider select-none active:scale-95 transition-transform",
            style: {
              backgroundColor: `rgba(${e2(n)}, 0.15)`,
              border: `2px solid rgba(${e2(n)}, 0.6)`,
              color: n,
              textShadow: `0 0 8px ${n}`,
              boxShadow: `0 0 15px rgba(${e2(n)}, 0.2)`,
              touchAction: "none"
            },
            onTouchStart: t => {
              t.preventDefault(), eJ(15), e()
            },
            onClick: () => {
              eJ(15), e()
            },
            "aria-label": "Resume game",
            children: "▶ RESUME"
          }), (0, o.jsx)("button", {
            className: "px-8 py-3 rounded-xl font-bold text-lg tracking-wider select-none active:scale-95 transition-transform",
            style: {
              backgroundColor: `rgba(${e2(i)}, 0.1)`,
              border: `2px solid rgba(${e2(i)}, 0.4)`,
              color: i,
              textShadow: `0 0 8px ${i}`,
              touchAction: "none"
            },
            onTouchStart: e => {
              e.preventDefault(), eJ(10), t()
            },
            onClick: () => {
              eJ(10), t()
            },
            "aria-label": "Quit to menu",
            children: "✕ QUIT"
          })]
        })
      })
    }

    function e4() {
      let e = ea(e => e.dashCooldown),
        t = ea(e => e.shieldCooldown),
        l = ea(e => e.specialCooldown),
        r = ea(e => e.saveData),
        [c, d] = (0, a.useState)(!1),
        [h, f] = (0, a.useState)({
          x: 0,
          y: 0
        }),
        u = (0, a.useRef)(null),
        m = (0, a.useRef)({
          x: 0,
          y: 0
        }),
        x = (0, a.useRef)(null),
        p = (0, a.useRef)(null),
        [g] = (0, a.useState)(() => window.matchMedia("(hover: none) and (pointer: coarse)").matches ||
          /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)),
        y = r.equippedSkills,
        b = r.skillUpgrades,
        v = (0, a.useMemo)(() => {
          let o = [{
            key: "dash",
            icon: "⚡",
            color: n,
            label: "",
            cooldown: e,
            maxCooldown: 90,
            skillId: ""
          }, {
            key: "shield",
            icon: "🛡",
            color: s,
            label: "",
            cooldown: t,
            maxCooldown: 300,
            skillId: ""
          }, {
            key: "special",
            icon: "✦",
            color: i,
            label: "",
            cooldown: l,
            maxCooldown: 360,
            skillId: ""
          }];
          for (let e = 0; e < 3; e++) {
            let t = y[e];
            if (t) {
              let a = P.find(e => e.id === t);
              if (a) {
                let l = eQ[Math.min((b[t] ?? 1) - 1, eQ.length - 1)];
                o[e] = {
                  ...o[e],
                  icon: eZ[a.element] || o[e].icon,
                  color: eX[a.element] || o[e].color,
                  label: a.name.slice(0, 6),
                  maxCooldown: Math.floor(a.cooldown * l),
                  skillId: t
                }
              }
            }
          }
          return o
        }, [y, b, e, t, l]),
        w = (0, a.useCallback)((e, t) => {
          let o = e - m.current.x,
            a = t - m.current.y,
            l = Math.sqrt(o * o + a * a),
            r = Math.min(l, 40),
            n = Math.atan2(a, o),
            i = l > 0 ? r / 40 * Math.cos(n) : 0,
            s = l > 0 ? r / 40 * Math.sin(n) : 0;
          f({
            x: l > 0 ? r * Math.cos(n) : 0,
            y: l > 0 ? r * Math.sin(n) : 0
          });
          let c = eY();
          c?.setJoystick({
            active: !0,
            dx: i,
            dy: s
          }), i < -.3 ? c?.moveLeft() : i > .3 ? c?.moveRight() : c?.stopMove()
        }, [40]),
        k = (0, a.useCallback)(e => {
          e.preventDefault(), e.stopPropagation();
          let t = e.changedTouches[0];
          if (null !== u.current) return;
          u.current = t.identifier, d(!0);
          let o = x.current?.getBoundingClientRect();
          o && (m.current = {
            x: o.left + o.width / 2,
            y: o.top + o.height / 2
          }), eJ(8), w(t.clientX, t.clientY)
        }, [w]),
        C = (0, a.useCallback)(e => {
          e.preventDefault(), e.stopPropagation();
          for (let t = 0; t < e.changedTouches.length; t++) {
            let o = e.changedTouches[t];
            if (o.identifier === u.current) {
              w(o.clientX, o.clientY);
              break
            }
          }
        }, [w]),
        S = (0, a.useCallback)(e => {
          e.preventDefault(), e.stopPropagation();
          for (let t = 0; t < e.changedTouches.length; t++)
            if (e.changedTouches[t].identifier === u.current) {
              u.current = null, d(!1), f({
                x: 0,
                y: 0
              });
              let e = eY();
              e?.setJoystick({
                active: !1,
                dx: 0,
                dy: 0
              }), e?.stopMove();
              break
            }
        }, []),
        T = (0, a.useCallback)(() => {
          eJ(15);
          let e = eY();
          e?.jump()
        }, []),
        M = (0, a.useCallback)(() => {
          eJ(10);
          let e = eY();
          e?.shoot(), p.current = setInterval(() => {
            let e = eY();
            e?.shoot()
          }, 150)
        }, []),
        j = (0, a.useCallback)(() => {
          let e = eY();
          e?.stopShoot(), p.current && (clearInterval(p.current), p.current = null)
        }, []),
        N = (0, a.useCallback)((e, t) => {
          let o = eY();
          if (t) o?.executeSkill(t);
          else switch (e) {
            case "dash":
              o?.dash();
              break;
            case "shield":
              o?.shield();
              break;
            case "special":
              o?.special()
          }
        }, []),
        A = (0, a.useCallback)(() => {
          eJ(15);
          let e = eY();
          e?.pause()
        }, []);
      return (0, a.useEffect)(() => () => {
        p.current && clearInterval(p.current)
      }, []), (0, o.jsxs)("div", {
        className: "absolute inset-0 z-20 pointer-events-none select-none",
        style: {
          touchAction: "none"
        },
        children: [(0, o.jsx)("div", {
          className: "absolute pointer-events-auto",
          style: {
            left: 12,
            bottom: 18,
            touchAction: "none"
          },
          children: (0, o.jsxs)("div", {
            ref: x,
            className: "relative rounded-full",
            style: {
              width: 130,
              height: 130,
              backgroundColor: c ? "rgba(0, 255, 255, 0.12)" : "rgba(0, 255, 255, 0.06)",
              border: `2.5px solid ${c?"rgba(0, 255, 255, 0.7)":"rgba(0, 255, 255, 0.35)"}`,
              boxShadow: c ?
                "0 0 20px rgba(0, 255, 255, 0.25), inset 0 0 12px rgba(0, 255, 255, 0.06)" :
                "0 0 12px rgba(0, 255, 255, 0.1), inset 0 0 8px rgba(0, 255, 255, 0.03)",
              transition: c ? "none" : "box-shadow 0.3s, background-color 0.3s, border-color 0.3s",
              animation: c ? "none" : "joystick-idle-pulse 2s ease-in-out infinite"
            },
            onTouchStart: k,
            onTouchMove: C,
            onTouchEnd: S,
            onTouchCancel: S,
            children: [(0, o.jsxs)("div", {
              className: "absolute inset-0 flex flex-col items-center justify-center pointer-events-none transition-opacity duration-200",
              style: {
                opacity: .7 * !c,
                color: n,
                fontSize: 12,
                fontWeight: 900,
                letterSpacing: "0.15em",
                textShadow: "0 0 12px rgba(0, 255, 255, 0.6), 0 0 25px rgba(0, 255, 255, 0.3)"
              },
              children: [(0, o.jsx)("span", {
                children: "⬍"
              }), (0, o.jsx)("span", {
                style: {
                  fontSize: 9,
                  marginTop: 1
                },
                children: ""
              })]
            }), (0, o.jsx)("div", {
              className: "absolute left-1/2 -translate-x-1/2 pointer-events-none",
              style: {
                top: 6,
                color: c ? "rgba(0, 255, 255, 0.7)" : "rgba(0, 255, 255, 0.35)",
                fontSize: 14,
                fontWeight: 900,
                transition: "color 0.15s",
                textShadow: c ? "0 0 8px rgba(0,255,255,0.5)" : "none"
              },
              children: "▲"
            }), (0, o.jsx)("div", {
              className: "absolute left-1/2 -translate-x-1/2 pointer-events-none",
              style: {
                bottom: 6,
                color: c ? "rgba(0, 255, 255, 0.7)" : "rgba(0, 255, 255, 0.35)",
                fontSize: 14,
                fontWeight: 900,
                transition: "color 0.15s",
                textShadow: c ? "0 0 8px rgba(0,255,255,0.5)" : "none"
              },
              children: "▼"
            }), (0, o.jsx)("div", {
              className: "absolute top-1/2 -translate-y-1/2 pointer-events-none",
              style: {
                left: 6,
                color: c ? "rgba(0, 255, 255, 0.7)" : "rgba(0, 255, 255, 0.35)",
                fontSize: 14,
                fontWeight: 900,
                transition: "color 0.15s",
                textShadow: c ? "0 0 8px rgba(0,255,255,0.5)" : "none"
              },
              children: "◀"
            }), (0, o.jsx)("div", {
              className: "absolute top-1/2 -translate-y-1/2 pointer-events-none",
              style: {
                right: 6,
                color: c ? "rgba(0, 255, 255, 0.7)" : "rgba(0, 255, 255, 0.35)",
                fontSize: 14,
                fontWeight: 900,
                transition: "color 0.15s",
                textShadow: c ? "0 0 8px rgba(0,255,255,0.5)" : "none"
              },
              children: "▶"
            }), (0, o.jsx)("div", {
              className: "absolute pointer-events-none",
              style: {
                left: "50%",
                top: 0,
                bottom: 0,
                width: 1,
                backgroundColor: "rgba(0, 255, 255, 0.06)",
                transform: "translateX(-50%)"
              }
            }), (0, o.jsx)("div", {
              className: "absolute pointer-events-none",
              style: {
                top: "50%",
                left: 0,
                right: 0,
                height: 1,
                backgroundColor: "rgba(0, 255, 255, 0.06)",
                transform: "translateY(-50%)"
              }
            }), (0, o.jsx)("div", {
              className: "absolute rounded-full pointer-events-none",
              style: {
                width: 50,
                height: 50,
                backgroundColor: c ? "rgba(0, 255, 255, 0.3)" : "rgba(0, 255, 255, 0.15)",
                border: `2.5px solid ${c?"rgba(0, 255, 255, 0.9)":"rgba(0, 255, 255, 0.5)"}`,
                boxShadow: c ?
                  "0 0 15px rgba(0, 255, 255, 0.4), inset 0 0 8px rgba(0, 255, 255, 0.15)" :
                  "0 0 8px rgba(0, 255, 255, 0.15), inset 0 0 5px rgba(0, 255, 255, 0.06)",
                top: "50%",
                left: "50%",
                transform: `translate(calc(-50% + ${h.x}px), calc(-50% + ${h.y}px))`,
                transition: c ? "box-shadow 0.1s, background-color 0.1s, border-color 0.1s" :
                  "transform 0.15s ease-out, box-shadow 0.2s, background-color 0.2s, border-color 0.2s"
              }
            })]
          })
        }), (0, o.jsxs)("div", {
          className: "absolute pointer-events-auto flex flex-col items-end gap-2",
          style: {
            right: 8,
            bottom: 12,
            touchAction: "none"
          },
          children: [(0, o.jsx)("div", {
            className: "flex gap-1.5 items-end",
            children: v.map(e => (0, o.jsx)(e1, {
              icon: e.icon,
              label: e.label,
              color: e.color,
              size: 52,
              cooldownFrames: e.cooldown,
              maxCooldown: e.maxCooldown,
              onPressStart: () => N(e.key, e.skillId)
            }, e.key))
          }), (0, o.jsxs)("div", {
            className: "flex gap-2 items-end",
            children: [(0, o.jsx)(e1, {
              icon: "⬆",
              label: "",
              color: s,
              size: 80,
              cooldownFrames: 0,
              maxCooldown: 0,
              onPressStart: T
            }), (0, o.jsx)(e1, {
              icon: "🔥",
              label: "",
              color: i,
              size: 76,
              cooldownFrames: 0,
              maxCooldown: 0,
              onPressStart: M,
              onPressEnd: j,
              pulseEffect: !0
            })]
          })]
        }), (0, o.jsx)("div", {
          className: "absolute pointer-events-auto",
          style: {
            top: 8,
            right: 8,
            touchAction: "none"
          },
          children: (0, o.jsx)("button", {
            className: "flex items-center justify-center rounded-xl active:scale-90 transition-transform select-none",
            style: {
              width: 44,
              height: 44,
              backgroundColor: "rgba(255, 255, 255, 0.05)",
              border: "2px solid rgba(255, 255, 255, 0.2)",
              color: "rgba(255, 255, 255, 0.6)",
              fontSize: "18px",
              touchAction: "none"
            },
            onTouchStart: e => {
              e.preventDefault(), A()
            },
            onClick: A,
            "aria-label": "Pause game",
            children: "⏸"
          })
        })]
      })
    }

    function e6() {
      let e = (0, a.useRef)(null),
        t = ea(e => e.gamePhase),
        l = ea(e => e.waitingForTap),
        r = ea(e => e.introTimer),
        n = ea(e => e.tapToStart),
        i = "playing" === t && l && r <= 0,
        s = () => {
          i && n()
        };
      return (0, o.jsxs)("div", {
        className: "fixed inset-0 overflow-hidden bg-[#050510] pointer-events-none",
        style: {
          width: "100vw",
          height: "100dvh",
          zIndex: 0
        },
        children: [(0, o.jsx)(eq, {
          ref: e
        }), "playing" === t && !l && (0, o.jsx)("div", {
          className: "pointer-events-auto",
          children: (0, o.jsx)(e5, {})
        }), i && (0, o.jsx)("div", {
          className: "absolute inset-0 z-40 flex items-center justify-center cursor-pointer select-none pointer-events-auto",
          style: {
            backgroundColor: "rgba(0, 0, 0, 0.5)"
          },
          onClick: s,
          onTouchStart: e => {
            e.preventDefault(), s()
          },
          role: "button",
          "aria-label": "Tap to start the game",
          children: (0, o.jsxs)("div", {
            className: "flex flex-col items-center gap-4",
            children: [(0, o.jsx)("div", {
              className: "text-3xl sm:text-4xl md:text-5xl font-bold tracking-widest",
              style: {
                color: "#00ffff",
                animation: "tap-start-pulse 1.5s ease-in-out infinite"
              },
              children: "TAP TO START"
            }), (0, o.jsx)("div", {
              className: "text-sm sm:text-base tracking-wide",
              style: {
                color: "rgba(0, 255, 255, 0.5)",
                animation: "tap-start-pulse 1.5s ease-in-out infinite 0.5s"
              },
              children: "⚡ Tap anywhere to begin ⚡"
            })]
          })
        })]
      })
    }

    function e8() {
      let e = ea(e => e.score),
        t = ea(e => e.currentLevel),
        l = ea(e => e.lastLevelKills),
        r = ea(e => e.lastLevelMaxCombo),
        n = ea(e => e.lastLevelCoinsEarned),
        i = ea(e => e.retryLevel),
        s = ea(e => e.backToMenu),
        c = ea(e => e.revive),
        d = ea(e => e.canRevive),
        [h, f] = (0, a.useState)(!1),
        [u, m] = (0, a.useState)(0),
        x = (0, a.useCallback)(() => {
          h || (f(!0), m(0), eo.init(), eo.playMenuClick(), ey.getInstance().showRewardedAdWithCallbacks(() => {
            f(!1), c(), eo.playAbilityReady()
          }, e => {
            f(!1), console.log("Rewarded ad skipped:", e)
          }, e => {
            m(e)
          }))
        }, [h, c]),
        p = Math.max(0, Math.ceil((100 - u) / 20));
      return h ? (0, o.jsx)("div", {
        className: "absolute inset-0 z-30 flex items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.92)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center px-4",
          children: [(0, o.jsx)("div", {
            className: "text-base sm:text-lg font-mono font-bold mb-3",
            style: {
              color: "#ffd700",
              textShadow: "0 0 10px #ffd700"
            },
            children: "🎬 WATCH AD TO REVIVE"
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-32 sm:h-40 rounded-lg mx-auto mb-3 flex items-center justify-center",
            style: {
              backgroundColor: "#111",
              border: "1px solid #333"
            },
            children: (0, o.jsxs)("div", {
              children: [(0, o.jsx)("div", {
                className: "text-xl sm:text-2xl font-bold font-mono mb-1",
                style: {
                  color: "#ff3333",
                  textShadow: "0 0 10px #ff3333"
                },
                children: "REVIVE"
              }), (0, o.jsx)("div", {
                className: "text-[10px] sm:text-xs font-mono",
                style: {
                  color: "#888"
                },
                children: "Continue with FULL HP"
              })]
            })
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-3 rounded-full overflow-hidden mx-auto mb-2",
            style: {
              backgroundColor: "#222"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all",
              style: {
                width: `${u}%`,
                backgroundColor: "#ffd700",
                boxShadow: "0 0 8px #ffd700"
              }
            })
          }), (0, o.jsxs)("div", {
            className: "text-xs font-mono",
            style: {
              color: "#555"
            },
            children: ["Ad playing... ", p, "s remaining"]
          })]
        })
      }) : (0, o.jsx)("div", {
        className: "absolute inset-0 z-20 overflow-y-auto",
        style: {
          WebkitOverflowScrolling: "touch",
          scrollbarWidth: "none",
          maxHeight: "100dvh",
          overscrollBehavior: "contain"
        },
        children: (0, o.jsx)("div", {
          className: "text-center pointer-events-auto px-3 max-w-md w-full mx-auto flex flex-col items-center",
          style: {
            minHeight: "100dvh",
            paddingBottom: "calc(env(safe-area-inset-bottom, 20px) + 2.5rem)"
          },
          children: (0, o.jsxs)("div", {
            className: "my-auto w-full py-6",
            children: [(0, o.jsx)("h1", {
              className: "text-3xl sm:text-5xl font-bold tracking-wider mb-2 sm:mb-4",
              style: {
                color: "#ff3333",
                textShadow: "0 0 20px #ff3333, 0 0 40px #ff3333, 0 0 80px #ff0000",
                animation: "neon-pulse 2s ease-in-out infinite"
              },
              children: "SYSTEM FAILURE"
            }), (0, o.jsx)("p", {
              className: "font-mono text-xs sm:text-sm mb-1 sm:mb-2",
              style: {
                color: "#00ffff",
                textShadow: "0 0 5px #00ffff"
              },
              children: '"That... was a glitch. But I\'m not done."      '
            }), (0, o.jsxs)("p", {
              className: "font-mono text-xs sm:text-sm mb-2 sm:mb-3",
              style: {
                color: "#00ffff",
                textShadow: "0 0 8px #00ffff"
              },
              children: ["LEVEL ", t]
            }), (0, o.jsxs)("div", {
              className: "grid grid-cols-2 gap-x-4 sm:gap-x-6 gap-y-0.5 sm:gap-y-1 mb-2 sm:mb-3 mx-auto max-w-xs",
              children: [(0, o.jsxs)("div", {
                className: "text-right font-mono text-xs sm:text-sm",
                style: {
                  color: "#ff6600",
                  textShadow: "0 0 5px #ff6600"
                },
                children: ["Kills: ", l]
              }), (0, o.jsxs)("div", {
                className: "text-left font-mono text-xs sm:text-sm",
                style: {
                  color: "#ff00ff",
                  textShadow: "0 0 5px #ff00ff"
                },
                children: ["Max Combo: ", r, "x"]
              }), (0, o.jsxs)("div", {
                className: "text-right font-mono text-xs sm:text-sm",
                style: {
                  color: "#ffd700",
                  textShadow: "0 0 5px #ffd700"
                },
                children: ["Coins: +", n]
              }), (0, o.jsxs)("div", {
                className: "text-left font-mono text-xs sm:text-sm",
                style: {
                  color: "#00ff66",
                  textShadow: "0 0 5px #00ff66"
                },
                children: ["Score: ", e]
              })]
            }), (0, o.jsxs)("div", {
              className: "flex flex-col gap-2 sm:gap-3 items-center",
              children: [d && (0, o.jsxs)(o.Fragment, {
                children: [(0, o.jsx)("button", {
                  onClick: x,
                  className: "neon-btn w-60 sm:w-72 py-3 px-4 text-base sm:text-lg font-bold font-mono tracking-wider min-h-[44px]",
                  style: {
                    borderColor: "#ffd700",
                    color: "#ffd700",
                    textShadow: "0 0 10px #ffd700, 0 0 20px #ffd700",
                    background: "linear-gradient(135deg, rgba(255,215,0,0.15), rgba(255,100,0,0.1))",
                    boxShadow: "0 0 20px rgba(255,215,0,0.3)",
                    animation: "neon-pulse 2s ease-in-out infinite"
                  },
                  children: "🎬 WATCH AD TO REVIVE"
                }), (0, o.jsx)("div", {
                  className: "text-[10px] sm:text-xs font-mono mb-0.5",
                  style: {
                    color: "#ffd700",
                    textShadow: "0 0 5px #ffd700"
                  },
                  children: "Continue where you died with FULL HP!"
                })]
              }), (0, o.jsx)("button", {
                onClick: i,
                className: "neon-btn w-48 sm:w-56 py-3 px-4 text-base sm:text-lg font-bold font-mono tracking-wider min-h-[44px]",
                style: {
                  borderColor: "#00ffff",
                  color: "#00ffff",
                  textShadow: "0 0 10px #00ffff"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                children: "↺ RETRY"
              }), (0, o.jsx)("button", {
                onClick: s,
                className: "neon-btn w-36 sm:w-48 py-2.5 px-3 text-xs sm:text-sm font-bold font-mono tracking-wider min-h-[44px]",
                style: {
                  borderColor: "#666",
                  color: "#888"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                children: "MAIN MENU"
              })]
            })]
          })
        })
      })
    }
    var e9 = e.i(37902);

    function e7({
      filled: e,
      delay: t
    }) {
      let [l, r] = (0, a.useState)(!1);
      return (0, a.useEffect)(() => {
        let e = setTimeout(() => r(!0), t);
        return () => clearTimeout(e)
      }, [t]), (0, o.jsx)("span", {
        className: "inline-block text-2xl sm:text-4xl transition-all duration-500",
        style: {
          opacity: +!!l,
          transform: l ? "scale(1) rotate(0deg)" : "scale(0) rotate(-180deg)",
          color: e ? "#ffd700" : "#333333",
          textShadow: e ? "0 0 10px #ffd700, 0 0 20px #ffd700, 0 0 40px #ff8c00" : "none",
          filter: e ? "drop-shadow(0 0 6px #ffd700)" : "none",
          animation: e && l ? "star-pulse 1.5s ease-in-out infinite" : "none"
        },
        children: "★"
      })
    }

    function te() {
      let e = ea(e => e.currentLevel),
        t = ea(e => e.score),
        l = ea(e => e.totalScore),
        r = ea(e => e.saveData),
        n = ea(e => e.nextLevel),
        i = ea(e => e.retryLevel),
        s = ea(e => e.backToMenu),
        c = ea(e => e.setGamePhase),
        d = ea(e => e.lastLevelStars),
        h = ea(e => e.lastLevelKills),
        f = ea(e => e.lastLevelMaxCombo),
        u = ea(e => e.lastLevelCoinsEarned),
        m = ea(e => e.lastLevelHealthPct),
        x = ea(e => e.lastLevelTotalEnemies),
        p = P.filter(t => "level" === t.unlockMethod && t.unlockLevel === e),
        [g, y] = (0, a.useState)(() => {
          let e = ey.getInstance().onLevelComplete();
          return e && eo.init(), e
        }),
        [b, v] = (0, a.useState)(0),
        [w, k] = (0, a.useState)(!1),
        [C, S] = (0, a.useState)(!1),
        [T, M] = (0, a.useState)(!1),
        [j, N] = (0, a.useState)(0),
        A = e <= G.length ? G.find(t => t.id === e) : U(e),
        R = e >= 100,
        I = u || Math.floor(t / 5);
      (0, a.useEffect)(() => {
        if (!g) return;
        let e = ey.getInstance(),
          t = !1;
        return e.showInterstitialAd(e => {
          !t && (v(e), e >= 20 && k(!0))
        }).then(() => {
          t || (y(!1), eo.init(), eo.playCoinCollect())
        }), () => {
          t = !0
        }
      }, [g]);
      let E = (0, a.useCallback)(() => {
          C || T || (M(!0), N(0), eo.init(), ey.getInstance().showRewardedAdWithCallbacks(() => {
            M(!1), S(!0), eo.playCoinCollect()
          }, e => {
            M(!1), console.log("Bonus ad skipped:", e)
          }, e => {
            N(e)
          }))
        }, [C, T]),
        L = Math.max(0, Math.ceil((100 - b) / 20));
      return g ? (0, o.jsx)("div", {
        className: "absolute inset-0 z-30 flex items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.92)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center px-4",
          children: [(0, o.jsx)("div", {
            className: "text-base sm:text-lg font-mono font-bold mb-3",
            style: {
              color: "#ffd700",
              textShadow: "0 0 10px #ffd700"
            },
            children: "🎬 ADVERTISEMENT"
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-32 sm:h-40 rounded-lg mx-auto mb-3 flex items-center justify-center",
            style: {
              backgroundColor: "#111",
              border: "1px solid #333"
            },
            children: (0, o.jsxs)("div", {
              children: [(0, o.jsx)("div", {
                className: "text-xl sm:text-2xl font-bold font-mono mb-1",
                style: {
                  color: "#00ffff",
                  textShadow: "0 0 10px #00ffff"
                },
                children: "NEON STICKMAN"
              }), (0, o.jsx)("div", {
                className: "text-[10px] sm:text-xs font-mono",
                style: {
                  color: "#888"
                },
                children: "Stick War — Coming Soon"
              })]
            })
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-2 rounded-full overflow-hidden mx-auto mb-2",
            style: {
              backgroundColor: "#222"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all",
              style: {
                width: `${b}%`,
                backgroundColor: "#ffd700",
                boxShadow: "0 0 8px #ffd700"
              }
            })
          }), w ? (0, o.jsx)("button", {
            onClick: () => {
              y(!1), eo.init(), eo.playCoinCollect()
            },
            className: "text-xs font-mono px-4 py-1.5 rounded min-h-[44px]",
            style: {
              color: "#888",
              border: "1px solid #444"
            },
            children: "SKIP AD ▶"
          }) : (0, o.jsxs)("div", {
            className: "text-xs font-mono",
            style: {
              color: "#555"
            },
            children: ["Ad playing... ", L, "s"]
          })]
        })
      }) : T ? (0, o.jsx)("div", {
        className: "absolute inset-0 z-30 flex items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.92)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center px-4",
          children: [(0, o.jsx)("div", {
            className: "text-base sm:text-lg font-mono font-bold mb-3",
            style: {
              color: "#ffd700",
              textShadow: "0 0 10px #ffd700"
            },
            children: "🎬 WATCHING AD FOR 2X COINS"
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-32 sm:h-40 rounded-lg mx-auto mb-3 flex items-center justify-center",
            style: {
              backgroundColor: "#111",
              border: "1px solid #333"
            },
            children: (0, o.jsxs)("div", {
              children: [(0, o.jsx)("div", {
                className: "text-xl sm:text-2xl font-bold font-mono mb-1",
                style: {
                  color: "#ffd700",
                  textShadow: "0 0 10px #ffd700"
                },
                children: "2X BONUS"
              }), (0, o.jsx)("div", {
                className: "text-[10px] sm:text-xs font-mono",
                style: {
                  color: "#888"
                },
                children: "Double your coins!"
              })]
            })
          }), (0, o.jsx)("div", {
            className: "w-64 sm:w-72 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${j}%`,
                backgroundColor: "#00ffff",
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: j < 100 ? "Please wait..." : "✅ 2x Bonus unlocked!"
          })]
        })
      }) : (0, o.jsxs)("div", {
        style: {
          WebkitOverflowScrolling: "touch",
          scrollbarWidth: "none",
          maxHeight: "100dvh",
          overscrollBehavior: "contain"
        },
        className: "jsx-64a063c0fb59431f absolute inset-0 z-20 overflow-y-auto",
        children: [(0, o.jsx)("div", {
          style: {
            minHeight: "100dvh",
            paddingBottom: "calc(env(safe-area-inset-bottom, 20px) + 2.5rem)"
          },
          className: "jsx-64a063c0fb59431f text-center pointer-events-auto px-3 max-w-md w-full mx-auto flex flex-col items-center",
          children: (0, o.jsxs)("div", {
            className: "jsx-64a063c0fb59431f my-auto w-full py-6",
            children: [(0, o.jsx)("h1", {
              style: {
                color: "#00ff66",
                textShadow: "0 0 20px #00ff66, 0 0 40px #00ff66, 0 0 80px #00ff66",
                animation: "neon-pulse 2s ease-in-out infinite"
              },
              className: "jsx-64a063c0fb59431f text-2xl sm:text-4xl font-bold tracking-wider mb-1 sm:mb-2",
              children: "ZONE CLEARED"
            }), (0, o.jsxs)("p", {
              style: {
                color: "#00ffff",
                textShadow: "0 0 5px #00ffff"
              },
              className: "jsx-64a063c0fb59431f font-mono text-xs sm:text-sm mb-2",
              children: [A?.chapter, " — ", A?.name]
            }), (0, o.jsxs)("div", {
              className: "jsx-64a063c0fb59431f flex justify-center gap-1 sm:gap-2 mb-2",
              children: [(0, o.jsx)(e7, {
                filled: d >= 1,
                delay: 300
              }), (0, o.jsx)(e7, {
                filled: d >= 2,
                delay: 600
              }), (0, o.jsx)(e7, {
                filled: d >= 3,
                delay: 900
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-64a063c0fb59431f grid grid-cols-2 gap-x-4 sm:gap-x-6 gap-y-0.5 sm:gap-y-1 mb-2 mx-auto max-w-xs",
              children: [(0, o.jsxs)("div", {
                style: {
                  color: "#ff6600",
                  textShadow: "0 0 5px #ff6600"
                },
                className: "jsx-64a063c0fb59431f text-right font-mono text-xs sm:text-sm",
                children: ["Kills: ", h, "/", x]
              }), (0, o.jsxs)("div", {
                style: {
                  color: "#00ff66",
                  textShadow: "0 0 5px #00ff66"
                },
                className: "jsx-64a063c0fb59431f text-left font-mono text-xs sm:text-sm",
                children: ["Health: ", m, "%"]
              }), (0, o.jsxs)("div", {
                style: {
                  color: "#ffff00",
                  textShadow: "0 0 5px #ffff00"
                },
                className: "jsx-64a063c0fb59431f text-right font-mono text-xs sm:text-sm",
                children: ["Combo: ", f, "x"]
              }), (0, o.jsxs)("div", {
                style: {
                  color: "#ffd700",
                  textShadow: "0 0 5px #ffd700"
                },
                className: "jsx-64a063c0fb59431f text-left font-mono text-xs sm:text-sm",
                children: ["Coins: +", I]
              })]
            }), (0, o.jsxs)("p", {
              style: {
                color: "#ff6600",
                textShadow: "0 0 10px #ff6600"
              },
              className: "jsx-64a063c0fb59431f font-mono text-base sm:text-lg mb-0.5",
              children: ["Score: ", t]
            }), (0, o.jsxs)("p", {
              style: {
                color: "#ffd700",
                textShadow: "0 0 10px #ffd700"
              },
              className: "jsx-64a063c0fb59431f font-mono text-xs sm:text-sm mb-0.5",
              children: ["+", I, " COINS", C && (0, o.jsxs)("span", {
                style: {
                  color: "#ff6600"
                },
                className: "jsx-64a063c0fb59431f",
                children: [" +", I, " BONUS!"]
              })]
            }), (0, o.jsxs)("p", {
              style: {
                color: "#aa00ff",
                textShadow: "0 0 5px #aa00ff"
              },
              className: "jsx-64a063c0fb59431f font-mono text-[10px] sm:text-xs mb-2",
              children: ["Total: ", l, " | Coins: ", r.totalCoins + (C ? I : 0)]
            }), !C && !R && (0, o.jsx)("button", {
              onClick: E,
              style: {
                borderColor: "#ffd700",
                color: "#ffd700",
                textShadow: "0 0 8px #ffd700, 0 0 16px #ffd700",
                background: "linear-gradient(135deg, rgba(255,215,0,0.12), rgba(255,102,0,0.08))",
                boxShadow: "0 0 12px rgba(255,215,0,0.2)"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              className: "jsx-64a063c0fb59431f neon-btn w-56 sm:w-64 py-2.5 px-3 text-xs sm:text-sm font-bold font-mono tracking-wider mb-2 min-h-[44px]",
              children: "🎬 WATCH AD FOR 2X COINS"
            }), C && (0, o.jsx)("div", {
              style: {
                color: "#00ff66"
              },
              className: "jsx-64a063c0fb59431f font-mono text-xs sm:text-sm mb-2",
              children: "BONUS CLAIMED!"
            }), p.length > 0 && (0, o.jsxs)("div", {
              style: {
                backgroundColor: "rgba(255,102,0,0.1)",
                border: "1px solid rgba(255,102,0,0.4)"
              },
              className: "jsx-64a063c0fb59431f mb-2 p-2 sm:p-3 rounded-lg mx-auto max-w-sm",
              children: [(0, o.jsx)("div", {
                style: {
                  color: "#ff6600",
                  textShadow: "0 0 8px #ff6600"
                },
                className: "jsx-64a063c0fb59431f text-[10px] sm:text-xs font-mono font-bold mb-1",
                children: "NEW SKILL UNLOCKED!"
              }), p.map(e => (0, o.jsxs)("div", {
                className: "jsx-64a063c0fb59431f flex items-center gap-1.5 sm:gap-2 mb-0.5",
                children: [(0, o.jsx)("div", {
                  style: {
                    backgroundColor: e.color,
                    boxShadow: `0 0 8px ${e.glowColor}`
                  },
                  className: "jsx-64a063c0fb59431f w-3 h-3 sm:w-4 sm:h-4 rounded-full flex-shrink-0"
                }), (0, o.jsxs)("div", {
                  className: "jsx-64a063c0fb59431f text-left",
                  children: [(0, o.jsx)("span", {
                    style: {
                      color: e.color
                    },
                    className: "jsx-64a063c0fb59431f font-mono text-[10px] sm:text-xs font-bold",
                    children: e.name
                  }), (0, o.jsx)("span", {
                    style: {
                      color: "#888"
                    },
                    className: "jsx-64a063c0fb59431f font-mono text-[8px] sm:text-[9px] ml-1",
                    children: e.element.toUpperCase()
                  }), (0, o.jsx)("p", {
                    style: {
                      color: "#666"
                    },
                    className: "jsx-64a063c0fb59431f font-mono text-[7px] sm:text-[8px]",
                    children: e.description
                  })]
                })]
              }, e.id)), (0, o.jsx)("div", {
                style: {
                  color: "#aaa"
                },
                className: "jsx-64a063c0fb59431f font-mono text-[8px] sm:text-[9px] mt-1",
                children: "Go to SKILLS to equip!"
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-64a063c0fb59431f flex flex-col gap-1.5 sm:gap-2 items-center",
              children: [!R && (0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), n()
                },
                style: {
                  borderColor: "#00ff66",
                  color: "#00ff66",
                  textShadow: "0 0 10px #00ff66, 0 0 20px #00ff66, 0 0 40px #00ff66",
                  boxShadow: "0 0 20px rgba(0,255,102,0.4), 0 0 40px rgba(0,255,102,0.15), inset 0 0 20px rgba(0,255,102,0.1)",
                  background: "linear-gradient(135deg, rgba(0,255,102,0.15), rgba(0,255,102,0.05))",
                  animation: "neon-pulse 2s ease-in-out infinite"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                className: "jsx-64a063c0fb59431f neon-btn w-56 sm:w-64 py-3 px-4 text-lg sm:text-2xl font-bold font-mono tracking-wider min-h-[44px]",
                children: "▶ PLAY NEXT"
              }), (0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), i()
                },
                style: {
                  borderColor: "#ff6600",
                  color: "#ff6600",
                  textShadow: "0 0 8px #ff6600"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                className: "jsx-64a063c0fb59431f neon-btn w-40 sm:w-48 py-2.5 px-3 text-sm sm:text-base font-bold font-mono tracking-wider min-h-[44px]",
                children: "↻ RETRY"
              }), (0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), c("level-map")
                },
                style: {
                  borderColor: "#00ffff",
                  color: "#00ffff",
                  textShadow: "0 0 8px #00ffff"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                className: "jsx-64a063c0fb59431f neon-btn w-40 sm:w-48 py-2.5 px-3 text-sm sm:text-base font-bold font-mono tracking-wider min-h-[44px]",
                children: "LEVEL MAP"
              }), r.unlockedSkills.length > 0 && (0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), c("skill-shop")
                },
                style: {
                  borderColor: "#ff6600",
                  color: "#ff6600",
                  textShadow: "0 0 8px #ff6600"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                className: "jsx-64a063c0fb59431f neon-btn w-40 sm:w-48 py-2.5 px-3 text-sm sm:text-base font-bold font-mono tracking-wider min-h-[44px]",
                children: "SKILLS"
              }), (0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), s()
                },
                style: {
                  borderColor: "#666",
                  color: "#888"
                },
                onMouseEnter: () => {
                  eo.init(), eo.playMenuHover()
                },
                className: "jsx-64a063c0fb59431f neon-btn w-32 sm:w-40 py-2 px-3 text-xs sm:text-sm font-bold font-mono tracking-wider mt-0.5 min-h-[44px]",
                children: "MAIN MENU"
              })]
            })]
          })
        }), (0, o.jsx)(e9.default, {
          id: "64a063c0fb59431f",
          children: "@keyframes star-pulse{0%,to{transform:scale(1)}50%{transform:scale(1.15)}}"
        })]
      })
    }

    function tt() {
      let e = ea(e => e.totalScore),
        t = ea(e => e.currentLevel),
        a = ea(e => e.backToMenu),
        l = ea(e => e.nextLevel);
      return ea(e => e.setGamePhase), (0, o.jsx)("div", {
        className: "absolute inset-0 z-20 flex items-center justify-center pointer-events-none",
        children: (0, o.jsxs)("div", {
          className: "text-center pointer-events-auto",
          children: [(0, o.jsx)("h1", {
            className: "text-5xl sm:text-7xl font-bold tracking-wider mb-4",
            style: {
              color: "#00ff66",
              textShadow: "0 0 20px #00ff66, 0 0 40px #00ff66, 0 0 80px #00ff66",
              animation: "neon-pulse 2s ease-in-out infinite"
            },
            children: "VICTORY"
          }), (0, o.jsx)("p", {
            className: "font-mono text-sm mb-2",
            style: {
              color: "#00ffff",
              textShadow: "0 0 5px #00ffff"
            },
            children: '"Lights back on. Grid\'s running. I could use a reboot."      '
          }), (0, o.jsx)("p", {
            className: "font-mono text-xs mb-6",
            style: {
              color: "#aa00ff",
              textShadow: "0 0 5px #aa00ff"
            },
            children: "— Spark"
          }), (0, o.jsxs)("p", {
            className: "font-mono text-2xl mb-8",
            style: {
              color: "#ff6600",
              textShadow: "0 0 10px #ff6600"
            },
            children: ["Final Score: ", e]
          }), (0, o.jsxs)("div", {
            className: "flex flex-col gap-3 items-center",
            children: [t >= 100 ? (0, o.jsx)("button", {
              onClick: a,
              className: "neon-btn w-64 py-4 px-8 text-2xl font-bold font-mono tracking-wider",
              style: {
                borderColor: "#ffaa00",
                color: "#ffaa00",
                textShadow: "0 0 10px #ffaa00, 0 0 20px #ffaa00",
                boxShadow: "0 0 20px rgba(255,170,0,0.4), 0 0 40px rgba(255,170,0,0.15)",
                background: "linear-gradient(135deg, rgba(255,170,0,0.15), rgba(255,170,0,0.05))"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              children: "🏆 ALL LEVELS COMPLETE"
            }) : (0, o.jsx)("button", {
              onClick: () => {
                eo.init(), eo.playMenuClick(), l()
              },
              className: "neon-btn w-64 py-4 px-8 text-2xl font-bold font-mono tracking-wider",
              style: {
                borderColor: "#00ff66",
                color: "#00ff66",
                textShadow: "0 0 10px #00ff66, 0 0 20px #00ff66, 0 0 40px #00ff66",
                boxShadow: "0 0 20px rgba(0,255,102,0.4), 0 0 40px rgba(0,255,102,0.15), inset 0 0 20px rgba(0,255,102,0.1)",
                background: "linear-gradient(135deg, rgba(0,255,102,0.15), rgba(0,255,102,0.05))",
                animation: "neon-pulse 2s ease-in-out infinite"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              children: "▶ PLAY NEXT"
            }), (0, o.jsx)("button", {
              onClick: a,
              className: "neon-btn w-48 py-3 px-6 text-lg font-bold font-mono tracking-wider",
              style: {
                borderColor: "#666",
                color: "#888"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              children: "MAIN MENU"
            })]
          })]
        })
      })
    }
    let to = {
      cityPan: {
        bg: "#050520",
        accent: n,
        icon: "🌆"
      },
      kidnapping: {
        bg: "#200510",
        accent: f,
        icon: "⚡"
      },
      blueWakes: {
        bg: "#050515",
        accent: n,
        icon: "💙"
      },
      blueAngry: {
        bg: "#150505",
        accent: f,
        icon: "🔥"
      },
      shadowAppears: {
        bg: "#100515",
        accent: h,
        icon: "👤"
      },
      handshake: {
        bg: "#051010",
        accent: n,
        icon: "🤝"
      },
      gangForming: {
        bg: "#050a10",
        accent: m,
        icon: "⚔️"
      },
      lunaCaptured: {
        bg: "#150510",
        accent: x,
        icon: "🔒"
      },
      blueSeesLuna: {
        bg: "#050a10",
        accent: n,
        icon: "💫"
      },
      motherThreat: {
        bg: "#100505",
        accent: c,
        icon: "⚠️"
      },
      protectMother: {
        bg: "#050510",
        accent: n,
        icon: "🛡️"
      },
      bossIntro: {
        bg: "#150505",
        accent: f,
        icon: "💀"
      },
      bossDefeated: {
        bg: "#051005",
        accent: s,
        icon: "🏆"
      },
      reunion: {
        bg: "#050510",
        accent: x,
        icon: "💖"
      },
      victoryCelebration: {
        bg: "#050a05",
        accent: m,
        icon: "🎉"
      },
      revive: {
        bg: "#050510",
        accent: n,
        icon: "⚡"
      },
      gangJoin: {
        bg: "#050a10",
        accent: s,
        icon: "✊"
      },
      walking: {
        bg: "#050510",
        accent: n,
        icon: "🚶"
      },
      warScene: {
        bg: "#150505",
        accent: c,
        icon: "⚔️"
      },
      darkRevelation: {
        bg: "#100510",
        accent: h,
        icon: "👁️"
      },
      betrayal: {
        bg: "#150505",
        accent: f,
        icon: "💔"
      },
      flashback: {
        bg: "#0a0515",
        accent: "#8888ff",
        icon: "💭"
      },
      lunaVision: {
        bg: "#050510",
        accent: x,
        icon: "🔮"
      },
      shadowPast: {
        bg: "#0a0515",
        accent: h,
        icon: "🌑"
      },
      motherSecret: {
        bg: "#050a0a",
        accent: "#44ddaa",
        icon: "🤫"
      },
      voidRift: {
        bg: "#0a0515",
        accent: i,
        icon: "🌀"
      },
      mysteryFigure: {
        bg: "#050510",
        accent: "#ff0044",
        icon: "❓"
      },
      sacrifice: {
        bg: "#150505",
        accent: m,
        icon: "🕊️"
      },
      truthRevealed: {
        bg: "#050510",
        accent: m,
        icon: "💡"
      },
      darkCorridor: {
        bg: "#050508",
        accent: "#666",
        icon: "🚪"
      },
      explosion: {
        bg: "#150800",
        accent: c,
        icon: "💥"
      },
      silentPrayer: {
        bg: "#050510",
        accent: n,
        icon: "🙏"
      },
      stormApproaching: {
        bg: "#050510",
        accent: d,
        icon: "⛈️"
      },
      hiddenBase: {
        bg: "#050808",
        accent: "#44ddaa",
        icon: "🏗️"
      },
      theDeal: {
        bg: "#100505",
        accent: m,
        icon: "🤝"
      },
      lastStand: {
        bg: "#150505",
        accent: f,
        icon: "🗡️"
      },
      newDawn: {
        bg: "#050a05",
        accent: m,
        icon: "🌅"
      },
      gangOath: {
        bg: "#050510",
        accent: n,
        icon: "✊"
      },
      redKingPlan: {
        bg: "#150505",
        accent: f,
        icon: "👑"
      }
    };

    function ta() {
      let e = ea(e => e.currentCutscene),
        t = ea(e => e.cutsceneFrameIndex),
        l = ea(e => e.advanceCutscene),
        r = ea(e => e.skipCutscene),
        [i, s] = (0, a.useState)(0),
        [c, d] = (0, a.useState)(!0),
        [h, f] = (0, a.useState)("in"),
        u = (0, a.useRef)(null),
        m = (0, a.useRef)(null),
        x = (0, a.useRef)(!0),
        p = (0, a.useRef)(void 0),
        g = e?.frames[t];
      e?.frames.length;
      let y = g && to[g.scene] || {
        bg: "#050510",
        accent: n,
        icon: "🎬"
      };
      p.current = g, x.current = c;
      let b = (0, a.useCallback)(() => {
        let e = p.current;
        if (e) {
          if (x.current) {
            s(e.dialogue.length), d(!1), x.current = !1, u.current && clearTimeout(u.current), u.current =
              setTimeout(() => {
                f("out"), setTimeout(() => l(), 200)
              }, 1500);
            return
          }
          f("out"), setTimeout(() => l(), 200)
        }
      }, [l]);
      if ((0, a.useEffect)(() => {
          if (!g) return;
          s(0), d(!0), x.current = !0, f("in");
          let e = g.dialogue,
            t = 0;
          m.current && clearInterval(m.current), m.current = setInterval(() => {
            s(++t), t >= e.length && (m.current && clearInterval(m.current), d(!1), x.current = !1)
          }, 30);
          let o = setTimeout(() => f("visible"), 300);
          return u.current && clearTimeout(u.current), u.current = setTimeout(() => {
            b()
          }, g.duration * (1e3 / 60)), () => {
            m.current && clearInterval(m.current), clearTimeout(o), u.current && clearTimeout(u.current)
          }
        }, [t, e?.id, g, b]), !e || !g) return null;
      let v = g.dialogue.slice(0, i),
        w = g.speakerColor || y.accent;
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 z-40 flex flex-col items-center justify-center cursor-pointer select-none",
        style: {
          backgroundColor: y.bg,
          opacity: "in" === h ? .7 : "out" === h ? .3 : 1,
          transition: "opacity 0.3s ease"
        },
        onClick: b,
        onTouchStart: e => {
          e.preventDefault(), b()
        },
        role: "button",
        "aria-label": "Tap to advance cutscene",
        children: [(0, o.jsx)("div", {
          className: "absolute inset-0 pointer-events-none",
          style: {
            background: `radial-gradient(ellipse at center, ${y.accent}08 0%, transparent 70%)`
          }
        }), (0, o.jsx)("div", {
          className: "absolute inset-0 pointer-events-none overflow-hidden",
          children: Array.from({
            length: 12
          }).map((e, t) => (0, o.jsx)("div", {
            className: "absolute rounded-full",
            style: {
              left: `${10+7*t%80}%`,
              bottom: "-10px",
              width: 2 + t % 3,
              height: 2 + t % 3,
              backgroundColor: t % 2 == 0 ? y.accent : `${y.accent}80`,
              boxShadow: `0 0 ${4+t%4}px ${y.accent}40`,
              animation: `particle-float ${6+t%8}s linear ${t%5}s infinite`,
              "--drift": `${-10+7*t%20}px`
            }
          }, t))
        }), (0, o.jsx)("div", {
          className: "text-4xl sm:text-5xl mb-4",
          style: {
            filter: `drop-shadow(0 0 15px ${y.accent})`,
            animation: "neon-pulse 3s ease-in-out infinite"
          },
          children: y.icon
        }), (0, o.jsx)("div", {
          className: "text-sm sm:text-base font-bold font-mono tracking-widest mb-2 px-3 py-1 rounded",
          style: {
            color: w,
            textShadow: `0 0 10px ${w}, 0 0 20px ${w}40`,
            backgroundColor: `${w}10`,
            border: `1px solid ${w}30`
          },
          children: g.speaker
        }), (0, o.jsx)("div", {
          className: "text-center px-8 max-w-lg",
          children: (0, o.jsxs)("p", {
            className: "text-lg sm:text-2xl font-bold font-mono tracking-wide leading-relaxed",
            style: {
              color: "#e0e0e0",
              textShadow: `0 0 8px ${y.accent}40`
            },
            children: [v, c && (0, o.jsx)("span", {
              className: "inline-block w-2 h-5 ml-1 align-middle",
              style: {
                backgroundColor: y.accent,
                animation: "blink 0.6s step-end infinite"
              }
            })]
          })
        }), (0, o.jsx)("div", {
          className: "flex gap-2 mt-6",
          children: e.frames.map((e, a) => (0, o.jsx)("div", {
            className: "w-2 h-2 rounded-full transition-all duration-300",
            style: {
              backgroundColor: a < t || a === t ? y.accent : "#333",
              boxShadow: a === t ? `0 0 8px ${y.accent}` : "none",
              transform: a === t ? "scale(1.3)" : "scale(1)"
            }
          }, a))
        }), (0, o.jsx)("div", {
          className: "text-xs font-mono mt-8",
          style: {
            color: "#444",
            animation: "neon-pulse 2s ease-in-out infinite"
          },
          children: "TAP TO CONTINUE"
        }), (0, o.jsx)("button", {
          className: "absolute top-3 right-3 text-[10px] font-mono px-2 py-1 rounded z-50",
          style: {
            color: "#555",
            border: "1px solid #333",
            backgroundColor: "rgba(0,0,0,0.3)"
          },
          onClick: e => {
            e.stopPropagation(), r()
          },
          onTouchStart: e => {
            e.stopPropagation(), e.preventDefault(), r()
          },
          children: "SKIP ▸▸"
        })]
      })
    }
    let tl = {
        common: "#888888",
        rare: n,
        epic: i,
        legendary: m
      },
      tr = {
        common: "COM",
        rare: "RAR",
        epic: "EPC",
        legendary: "LEG"
      };

    function tn({
      onComplete: e
    }) {
      let [t, l] = (0, a.useState)(0);
      return (0, a.useEffect)(() => {
        let e = setInterval(() => {
          l(t => t >= 100 ? (clearInterval(e), 100) : t + 2)
        }, 60);
        return () => clearInterval(e)
      }, []), (0, a.useEffect)(() => {
        if (t >= 100) {
          let t = setTimeout(e, 300);
          return () => clearTimeout(t)
        }
      }, [t, e]), (0, o.jsx)("div", {
        className: "fixed inset-0 z-50 flex flex-col items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.95)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("div", {
            className: "text-2xl font-bold font-mono mb-4",
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            children: "🎬 WATCHING AD"
          }), (0, o.jsx)("div", {
            className: "w-64 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${t}%`,
                backgroundColor: n,
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: t < 100 ? "Please wait..." : "✅ Reward unlocked!"
          })]
        })
      })
    }

    function ti({
      color: e,
      glowColor: t
    }) {
      return (0, o.jsxs)("svg", {
        width: "36",
        height: "56",
        viewBox: "0 0 40 64",
        style: {
          filter: `drop-shadow(0 0 4px ${t})`,
          animation: "stickman-bob 2s ease-in-out infinite"
        },
        children: [(0, o.jsx)("circle", {
          cx: "20",
          cy: "10",
          r: "7",
          fill: "none",
          stroke: e,
          strokeWidth: "2.5"
        }), (0, o.jsx)("circle", {
          cx: "22",
          cy: "9",
          r: "1.5",
          fill: e
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "17",
          x2: "20",
          y2: "36",
          stroke: e,
          strokeWidth: "2.5"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "23",
          x2: "9",
          y2: "30",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "23",
          x2: "31",
          y2: "30",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "36",
          x2: "12",
          y2: "54",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "20",
          y1: "36",
          x2: "28",
          y2: "54",
          stroke: e,
          strokeWidth: "2"
        })]
      })
    }

    function ts({
      color: e,
      glowColor: t
    }) {
      return (0, o.jsxs)("svg", {
        width: "32",
        height: "32",
        viewBox: "0 0 40 40",
        style: {
          filter: `drop-shadow(0 0 3px ${t})`
        },
        children: [(0, o.jsx)("circle", {
          cx: "20",
          cy: "15",
          r: "8",
          fill: "none",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("circle", {
          cx: "22",
          cy: "13",
          r: "2",
          fill: t
        }), (0, o.jsx)("ellipse", {
          cx: "20",
          cy: "30",
          rx: "10",
          ry: "6",
          fill: "none",
          stroke: e,
          strokeWidth: "2"
        }), (0, o.jsx)("line", {
          x1: "12",
          y1: "34",
          x2: "8",
          y2: "39",
          stroke: e,
          strokeWidth: "1.5"
        }), (0, o.jsx)("line", {
          x1: "28",
          y1: "34",
          x2: "32",
          y2: "39",
          stroke: e,
          strokeWidth: "1.5"
        })]
      })
    }

    function tc() {
      let e = ea(e => e.saveData),
        t = ea(e => e.buySkin),
        l = ea(e => e.selectSkin),
        r = ea(e => e.buyPetSkin),
        c = ea(e => e.selectPetSkin),
        d = ea(e => e.addCoinsReward),
        h = ea(e => e.backToMenu),
        [f, u] = (0, a.useState)("character"),
        [x, p] = (0, a.useState)(!1),
        [g, y] = (0, a.useState)(null),
        b = (0, a.useCallback)(e => {
          eo.init(), eo.playMenuClick(), e()
        }, []),
        k = (0, a.useCallback)(e => {
          p(!0), y(() => e)
        }, []),
        S = (0, a.useCallback)(() => {
          p(!1), d(200), eo.playCoinCollect(), g && (g(), y(null))
        }, [g, d]),
        T = (0, a.useCallback)(() => {
          k(() => {})
        }, [k]),
        M = (0, a.useMemo)(() => {
          let e = {};
          for (let t of w) e[t.petId] || (e[t.petId] = []), e[t.petId].push(t);
          return e
        }, []),
        j = (0, a.useMemo)(() => new Set(e.unlockedPets), [e.unlockedPets]),
        N = (0, a.useCallback)(a => {
          let r = e.unlockedSkins.includes(a.id),
            c = e.currentSkin === a.id,
            d = e.totalCoins >= a.price,
            h = 0 === a.price,
            f = tl[a.rarity] || "#888888";
          return (0, o.jsxs)("div", {
            className: "rounded-lg flex flex-col items-center p-2 relative",
            style: {
              width: "120px",
              minWidth: "120px",
              backgroundColor: c ? `${a.color}15` : r ? `${a.color}08` : "rgba(0,0,0,0.3)",
              border: `2px solid ${c?a.color:r?`${a.color}60`:"#333"}`,
              boxShadow: c ? `0 0 12px ${a.color}40, inset 0 0 12px ${a.color}10` : "none"
            },
            children: [(0, o.jsx)("div", {
              className: "absolute top-1 right-1 text-[7px] font-bold font-mono px-1.5 py-0.5 rounded-full",
              style: {
                backgroundColor: `${f}30`,
                color: f,
                border: `1px solid ${f}60`
              },
              children: tr[a.rarity]
            }), (0, o.jsx)("div", {
              className: "flex justify-center mb-1 mt-1",
              children: (0, o.jsx)(ti, {
                color: a.color,
                glowColor: a.glowColor
              })
            }), (0, o.jsx)("div", {
              className: "font-bold text-[10px] font-mono mb-1 text-center leading-tight",
              style: {
                color: a.color
              },
              children: a.name
            }), a.effect && (0, o.jsxs)("div", {
              className: "text-[7px] font-mono font-bold mb-1 px-1.5 py-0.5 rounded-full",
              style: {
                backgroundColor: `${i}15`,
                color: i,
                border: `1px solid ${i}40`
              },
              children: ["✨ ", a.effect.toUpperCase()]
            }), (0, o.jsx)("div", {
              className: "w-full mt-auto",
              children: c ? (0, o.jsx)("div", {
                className: "text-[10px] font-mono font-bold py-2 px-2 rounded text-center",
                style: {
                  color: s,
                  backgroundColor: "rgba(0,255,102,0.12)",
                  border: "2px solid rgba(0,255,102,0.5)",
                  textShadow: "0 0 8px rgba(0,255,102,0.6)",
                  boxShadow: "0 0 10px rgba(0,255,102,0.2), inset 0 0 8px rgba(0,255,102,0.05)",
                  minHeight: 36,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                },
                children: "✓ EQUIPPED"
              }) : r ? (0, o.jsx)("button", {
                onClick: () => b(() => l(a.id)),
                className: "w-full text-[11px] font-mono font-bold py-2 px-2 rounded",
                style: {
                  minHeight: 36,
                  backgroundColor: "rgba(0,255,102,0.12)",
                  border: "2px solid rgba(0,255,102,0.7)",
                  color: "#ffffff",
                  textShadow: "0 0 6px rgba(0,255,102,0.5)",
                  boxShadow: "0 0 8px rgba(0,255,102,0.15)",
                  cursor: "pointer",
                  transition: "all 0.15s ease"
                },
                onMouseEnter: e => {
                  e.currentTarget.style.backgroundColor = "rgba(0,255,102,0.2)", e.currentTarget
                    .style.boxShadow = "0 0 15px rgba(0,255,102,0.3)"
                },
                onMouseLeave: e => {
                  e.currentTarget.style.backgroundColor = "rgba(0,255,102,0.12)", e.currentTarget
                    .style.boxShadow = "0 0 8px rgba(0,255,102,0.15)"
                },
                children: "▶ EQUIP"
              }) : (0, o.jsxs)("div", {
                className: "flex flex-col gap-1",
                children: [(0, o.jsx)("button", {
                  onClick: () => {
                    (d || h) && b(() => {
                      t(a.id) && (l(a.id), eo.playCoinCollect())
                    })
                  },
                  className: "w-full text-[9px] font-mono font-bold py-1.5 px-1 rounded",
                  style: {
                    minHeight: 32,
                    backgroundColor: d || h ? "rgba(255,215,0,0.12)" : "rgba(0,0,0,0.2)",
                    border: `2px solid ${d||h?"#ffd700":"#444"}`,
                    color: d || h ? "#ffd700" : "#555",
                    textShadow: d || h ? "0 0 6px rgba(255,215,0,0.4)" : "none",
                    cursor: d || h ? "pointer" : "default",
                    transition: "all 0.15s ease",
                    opacity: h ? 1 : void 0
                  },
                  children: h ? "🪙 FREE" : `BUY ${a.price} 🪙`
                }), (0, o.jsx)("button", {
                  onClick: () => {
                    k(() => {
                      b(() => {
                        t(a.id) && (l(a.id), eo.playCoinCollect())
                      })
                    })
                  },
                  className: "w-full text-[9px] font-mono font-bold py-1.5 px-1 rounded",
                  style: {
                    minHeight: 32,
                    backgroundColor: "rgba(0,255,255,0.08)",
                    border: "2px solid rgba(0,255,255,0.5)",
                    color: n,
                    textShadow: "0 0 6px rgba(0,255,255,0.4)",
                    cursor: "pointer",
                    transition: "all 0.15s ease"
                  },
                  onMouseEnter: e => {
                    e.currentTarget.style.backgroundColor = "rgba(0,255,255,0.15)", e
                      .currentTarget.style.boxShadow = "0 0 12px rgba(0,255,255,0.2)"
                  },
                  onMouseLeave: e => {
                    e.currentTarget.style.backgroundColor = "rgba(0,255,255,0.08)", e
                      .currentTarget.style.boxShadow = "none"
                  },
                  children: "🎬 WATCH AD"
                })]
              })
            })]
          }, a.id)
        }, [e, b, k, t, l]),
        P = (0, a.useCallback)(t => {
          let a = e.unlockedPetSkins.includes(t.id),
            l = e.currentPetSkin === t.id,
            d = e.totalCoins >= t.price,
            h = 0 === t.price,
            f = tl[t.rarity] || "#888888",
            u = v.find(e => e.id === t.petId),
            m = j.has(t.petId);
          return (0, o.jsxs)("div", {
            className: "rounded-lg flex flex-col items-center p-2 relative",
            style: {
              width: "120px",
              minWidth: "120px",
              backgroundColor: l ? `${t.color}15` : a ? `${t.color}08` : "rgba(0,0,0,0.3)",
              border: `2px solid ${l?t.color:a?`${t.color}60`:"#333"}`,
              boxShadow: l ? `0 0 12px ${t.color}40, inset 0 0 12px ${t.color}10` : "none",
              opacity: m ? 1 : .5
            },
            children: [(0, o.jsx)("div", {
              className: "absolute top-1 right-1 text-[7px] font-bold font-mono px-1.5 py-0.5 rounded-full",
              style: {
                backgroundColor: `${f}30`,
                color: f,
                border: `1px solid ${f}60`
              },
              children: tr[t.rarity]
            }), (0, o.jsx)("div", {
              className: "flex justify-center mb-1 mt-1",
              children: (0, o.jsx)(ts, {
                color: t.color,
                glowColor: t.glowColor
              })
            }), (0, o.jsx)("div", {
              className: "font-bold text-[10px] font-mono mb-0.5 text-center leading-tight",
              style: {
                color: t.color
              },
              children: t.name
            }), (0, o.jsx)("div", {
              className: "text-[7px] font-mono mb-1 text-center",
              style: {
                color: "#666"
              },
              children: u?.name || t.petId
            }), t.effect && (0, o.jsxs)("div", {
              className: "text-[7px] font-mono font-bold mb-1 px-1.5 py-0.5 rounded-full",
              style: {
                backgroundColor: `${i}15`,
                color: i,
                border: `1px solid ${i}40`
              },
              children: ["✨ ", t.effect.toUpperCase()]
            }), (0, o.jsx)("div", {
              className: "w-full mt-auto",
              children: m ? l ? (0, o.jsx)("div", {
                className: "text-[10px] font-mono font-bold py-2 px-2 rounded text-center",
                style: {
                  color: s,
                  backgroundColor: "rgba(0,255,102,0.12)",
                  border: "2px solid rgba(0,255,102,0.5)",
                  textShadow: "0 0 8px rgba(0,255,102,0.6)",
                  boxShadow: "0 0 10px rgba(0,255,102,0.2), inset 0 0 8px rgba(0,255,102,0.05)",
                  minHeight: 36,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                },
                children: "✓ EQUIPPED"
              }) : a ? (0, o.jsx)("button", {
                onClick: () => b(() => c(t.id)),
                className: "w-full text-[11px] font-mono font-bold py-2 px-2 rounded",
                style: {
                  minHeight: 36,
                  backgroundColor: "rgba(0,255,102,0.12)",
                  border: "2px solid rgba(0,255,102,0.7)",
                  color: "#ffffff",
                  textShadow: "0 0 6px rgba(0,255,102,0.5)",
                  boxShadow: "0 0 8px rgba(0,255,102,0.15)",
                  cursor: "pointer",
                  transition: "all 0.15s ease"
                },
                children: "▶ EQUIP"
              }) : (0, o.jsxs)("div", {
                className: "flex flex-col gap-1",
                children: [(0, o.jsx)("button", {
                  onClick: () => {
                    (d || h) && b(() => {
                      r(t.id) && (c(t.id), eo.playCoinCollect())
                    })
                  },
                  className: "w-full text-[9px] font-mono font-bold py-1.5 px-1 rounded",
                  style: {
                    minHeight: 32,
                    backgroundColor: d || h ? "rgba(255,215,0,0.12)" : "rgba(0,0,0,0.2)",
                    border: `2px solid ${d||h?"#ffd700":"#444"}`,
                    color: d || h ? "#ffd700" : "#555",
                    textShadow: d || h ? "0 0 6px rgba(255,215,0,0.4)" : "none",
                    cursor: d || h ? "pointer" : "default",
                    transition: "all 0.15s ease"
                  },
                  children: h ? "🪙 FREE" : `BUY ${t.price} 🪙`
                }), (0, o.jsx)("button", {
                  onClick: () => {
                    k(() => {
                      b(() => {
                        r(t.id) && (c(t.id), eo.playCoinCollect())
                      })
                    })
                  },
                  className: "w-full text-[9px] font-mono font-bold py-1.5 px-1 rounded",
                  style: {
                    minHeight: 32,
                    backgroundColor: "rgba(0,255,255,0.08)",
                    border: "2px solid rgba(0,255,255,0.5)",
                    color: n,
                    textShadow: "0 0 6px rgba(0,255,255,0.4)",
                    cursor: "pointer",
                    transition: "all 0.15s ease"
                  },
                  children: "🎬 WATCH AD"
                })]
              }) : (0, o.jsx)("div", {
                className: "text-[8px] font-mono text-center py-1.5 rounded",
                style: {
                  color: "#555",
                  backgroundColor: "rgba(0,0,0,0.2)",
                  border: "1px solid #333",
                  minHeight: 32,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                },
                children: "🔒 UNLOCK PET FIRST"
              })
            })]
          }, t.id)
        }, [e, j, b, k, r, c]);
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 z-20 flex flex-col pointer-events-auto",
        style: {
          backgroundColor: "rgba(5, 5, 20, 0.97)"
        },
        children: [x && (0, o.jsx)(tn, {
          onComplete: S
        }), (0, o.jsxs)("div", {
          className: "flex items-center justify-between px-3 py-1.5 flex-shrink-0",
          style: {
            borderBottom: "1px solid rgba(0,255,255,0.12)",
            backgroundColor: "rgba(0,0,0,0.4)"
          },
          children: [(0, o.jsx)("div", {
            className: "text-base sm:text-lg font-bold tracking-wider font-mono",
            style: {
              color: n,
              textShadow: "0 0 10px #00ffff, 0 0 20px rgba(0,255,255,0.3)"
            },
            children: "🎨 SKIN SHOP"
          }), (0, o.jsxs)("div", {
            className: "font-mono text-sm font-bold px-3 py-1 rounded-lg",
            style: {
              color: m,
              backgroundColor: "rgba(255,215,0,0.08)",
              border: "1px solid rgba(255,215,0,0.2)",
              textShadow: "0 0 8px #ffd700"
            },
            children: ["🪙 ", e.totalCoins.toLocaleString()]
          }), (0, o.jsx)("button", {
            onClick: () => b(() => h()),
            className: "neon-btn py-1.5 px-4 text-xs font-bold tracking-wider font-mono",
            style: {
              borderColor: "#555",
              color: "#ccc",
              minHeight: 36
            },
            children: "← BACK"
          })]
        }), (0, o.jsx)("div", {
          className: "flex flex-shrink-0",
          style: {
            backgroundColor: "rgba(0,0,0,0.25)"
          },
          children: [{
            id: "character",
            label: "CHARACTER SKINS",
            color: n,
            icon: "🤺"
          }, {
            id: "pet",
            label: "PET SKINS",
            color: s,
            icon: "🐾"
          }].map(e => (0, o.jsxs)("button", {
            onClick: () => b(() => u(e.id)),
            className: "flex-1 py-2.5 text-xs sm:text-sm font-bold font-mono tracking-wider text-center transition-all duration-200",
            style: {
              backgroundColor: f === e.id ? `${e.color}15` : "transparent",
              borderBottom: f === e.id ? `3px solid ${e.color}` : "3px solid transparent",
              color: f === e.id ? e.color : "#555",
              textShadow: f === e.id ? `0 0 8px ${e.color}` : "none",
              cursor: "pointer"
            },
            children: [e.icon, " ", e.label]
          }, e.id))
        }), (0, o.jsx)("div", {
          className: "flex-1 overflow-y-auto overflow-x-hidden p-3 dark-scroll allow-scroll",
          "data-scrollable": !0,
          children: "character" === f ? (0, o.jsx)("div", {
            className: "grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-3 justify-items-center",
            children: C.map(e => N(e))
          }) : (0, o.jsx)("div", {
            className: "space-y-4",
            children: v.map(e => {
              let t = M[e.id];
              if (!t || 0 === t.length) return null;
              let a = j.has(e.id);
              return (0, o.jsxs)("div", {
                children: [(0, o.jsxs)("div", {
                  className: "flex items-center gap-2 mb-2 pb-1",
                  style: {
                    borderBottom: `1px solid ${e.color}20`
                  },
                  children: [(0, o.jsx)(ts, {
                    color: e.color,
                    glowColor: e.glowColor
                  }), (0, o.jsx)("div", {
                    className: "text-xs font-bold font-mono",
                    style: {
                      color: a ? e.color : "#555",
                      textShadow: a ? `0 0 6px ${e.color}` : "none"
                    },
                    children: e.name
                  }), !a && (0, o.jsx)("span", {
                    className: "text-[8px] font-mono px-1.5 py-0.5 rounded",
                    style: {
                      color: "#666",
                      backgroundColor: "rgba(0,0,0,0.2)",
                      border: "1px solid #333"
                    },
                    children: "🔒 LOCKED"
                  })]
                }), (0, o.jsx)("div", {
                  className: "grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-3 justify-items-center",
                  children: t.map(e => P(e))
                })]
              }, e.id)
            })
          })
        }), (0, o.jsxs)("div", {
          className: "flex items-center justify-between px-4 py-2 flex-shrink-0",
          style: {
            borderTop: "1px solid rgba(0,255,255,0.12)",
            backgroundColor: "rgba(0,0,0,0.4)"
          },
          children: [(0, o.jsxs)("div", {
            className: "text-[10px] sm:text-xs font-mono",
            style: {
              color: "#888"
            },
            children: ["🎬 Watch any ad for ", (0, o.jsx)("span", {
              style: {
                color: m,
                fontWeight: "bold"
              },
              children: "+200"
            }), " Coins!"]
          }), (0, o.jsx)("button", {
            onClick: () => b(T),
            className: "neon-btn py-1.5 px-4 text-xs font-bold tracking-wider font-mono",
            style: {
              borderColor: n,
              color: n,
              textShadow: "0 0 8px #00ffff",
              minHeight: 36,
              backgroundImage: "linear-gradient(90deg, transparent, rgba(0,255,255,0.06), transparent)",
              backgroundSize: "200% 100%",
              animation: "ad-shimmer 3s linear infinite"
            },
            children: "🎬 WATCH AD +200 🪙"
          })]
        })]
      })
    }
    let td = ["fire", "frost", "shadow", "summon", "death", "lightning", "void", "blood"],
      th = {
        fire: "#ff4400",
        frost: "#88eeff",
        shadow: "#8800ff",
        summon: "#aa00ff",
        death: "#330033",
        lightning: "#ffff00",
        void: "#ff00ff",
        blood: "#cc0000"
      },
      tf = {
        fire: "FIRE",
        frost: "FROST",
        shadow: "SHADOW",
        summon: "SUMMON",
        death: "DEATH",
        lightning: "LIGHTNING",
        void: "VOID",
        blood: "BLOOD"
      },
      tu = {
        common: "#aaaaaa",
        rare: "#4488ff",
        epic: "#aa00ff",
        legendary: "#ffaa00"
      },
      tm = ["DASH", "SHIELD", "SPECIAL"],
      tx = ["Shift/Q", "E", "F/R"];

    function tp({
      onComplete: e
    }) {
      let [t, l] = (0, a.useState)(0);
      return (0, a.useEffect)(() => {
        let e = setInterval(() => {
          l(t => t >= 100 ? (clearInterval(e), 100) : t + 2)
        }, 60);
        return () => clearInterval(e)
      }, []), (0, a.useEffect)(() => {
        if (t >= 100) {
          let t = setTimeout(e, 300);
          return () => clearTimeout(t)
        }
      }, [t, e]), (0, o.jsx)("div", {
        className: "fixed inset-0 z-50 flex flex-col items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.95)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("div", {
            className: "text-2xl font-bold font-mono mb-4",
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            children: "🎬 WATCHING AD"
          }), (0, o.jsx)("div", {
            className: "w-64 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${t}%`,
                backgroundColor: n,
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: t < 100 ? "Please wait..." : "✅ Reward unlocked!"
          })]
        })
      })
    }

    function tg() {
      let e = ea(e => e.saveData),
        t = ea(e => e.setGamePhase),
        l = ea(e => e.buySkill),
        r = ea(e => e.equipSkill),
        i = ea(e => e.unequipSkill),
        d = ea(e => e.upgradeSkill),
        h = ea(e => e.addCoinsReward),
        [f, u] = (0, a.useState)("all"),
        [x, p] = (0, a.useState)(!1),
        [g, y] = (0, a.useState)(null),
        [b, v] = (0, a.useState)(null),
        [w, k] = (0, a.useState)(null),
        [C, N] = (0, a.useState)(null),
        A = e => {
          eo.init(), eo.playMenuClick(), e()
        },
        R = (0, a.useCallback)(e => {
          p(!0), y(() => e)
        }, []),
        I = (0, a.useCallback)(() => {
          p(!1), h(200), g && (g(), y(null))
        }, [g, h]),
        E = (e, t) => {
          A(() => {
            i(e), eo.playDamage(), N(t), setTimeout(() => N(null), 800)
          })
        },
        L = "all" === f ? P : P.filter(e => e.element === f),
        D = e.equippedSkills;
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 z-30 flex flex-col items-center bg-[#050510ee] overflow-hidden",
        children: [x && (0, o.jsx)(tp, {
          onComplete: I
        }), (0, o.jsxs)("div", {
          className: "w-full max-w-2xl px-4 pt-4 pb-2",
          children: [(0, o.jsxs)("div", {
            className: "flex items-center justify-between mb-3",
            children: [(0, o.jsx)("h2", {
              className: "text-3xl font-bold tracking-wider",
              style: {
                color: c,
                textShadow: "0 0 15px #ff6600, 0 0 30px #ff6600"
              },
              children: "⚡ SKILLS"
            }), (0, o.jsx)("div", {
              className: "flex items-center gap-3 font-mono text-sm",
              children: (0, o.jsxs)("span", {
                style: {
                  color: m,
                  textShadow: "0 0 8px #ffd700"
                },
                children: ["🪙 ", e.totalCoins]
              })
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3 p-3 rounded-lg",
            style: {
              backgroundColor: "rgba(255,102,0,0.08)",
              border: "1px solid #ff660030"
            },
            children: [(0, o.jsxs)("div", {
              className: "text-xs font-mono mb-2 flex items-center gap-2",
              style: {
                color: c
              },
              children: [(0, o.jsx)("span", {
                children: "⚔️ EQUIPPED SKILLS"
              }), (0, o.jsx)("span", {
                style: {
                  color: "#666"
                },
                children: "(3 slots — tap UNEQUIP to remove)"
              })]
            }), (0, o.jsx)("div", {
              className: "flex gap-2",
              children: [0, 1, 2].map(t => {
                let a = D[t],
                  l = a ? P.find(e => e.id === a) : null,
                  r = a ? e.skillUpgrades[a] ?? 1 : 0;
                return (0, o.jsx)("div", {
                  className: "flex-1 p-2 rounded text-center",
                  style: {
                    backgroundColor: l ? `${l.color}15` : "rgba(0,0,0,0.3)",
                    border: `2px solid ${l?l.color+"80":"#33333340"}`,
                    minHeight: 70,
                    transition: "all 0.3s ease",
                    boxShadow: l ? `0 0 12px ${l.color}30` : "none"
                  },
                  children: l ? (0, o.jsxs)("div", {
                    className: "flex flex-col items-center",
                    children: [(0, o.jsx)("div", {
                      className: "text-[10px] font-mono font-bold",
                      style: {
                        color: l.color
                      },
                      children: l.name
                    }), (0, o.jsxs)("div", {
                      className: "text-[9px] font-mono mt-0.5",
                      style: {
                        color: "#ffaa00"
                      },
                      children: ["LV ", r, "/", 5]
                    }), (0, o.jsxs)("div", {
                      className: "text-[8px] font-mono mt-0.5",
                      style: {
                        color: "#888"
                      },
                      children: ["[Slot ", t + 1, ": ", tm[t], "]"]
                    }), (0, o.jsx)("button", {
                      onClick: () => E(t, a),
                      className: "mt-1.5 text-[8px] font-mono font-bold px-2 py-0.5 rounded",
                      style: {
                        backgroundColor: "rgba(255,51,51,0.15)",
                        border: "1px solid rgba(255,51,51,0.5)",
                        color: "#ff5555",
                        cursor: "pointer",
                        transition: "all 0.2s"
                      },
                      onMouseEnter: e => {
                        e.currentTarget.style.backgroundColor =
                          "rgba(255,51,51,0.3)", e.currentTarget.style
                          .transform = "scale(1.05)"
                      },
                      onMouseLeave: e => {
                        e.currentTarget.style.backgroundColor =
                          "rgba(255,51,51,0.15)", e.currentTarget.style
                          .transform = "scale(1)"
                      },
                      children: "✕ UNEQUIP"
                    })]
                  }) : (0, o.jsxs)("div", {
                    className: "flex flex-col items-center",
                    children: [(0, o.jsx)("span", {
                      className: "text-[10px] font-mono font-bold",
                      style: {
                        color: "#555"
                      },
                      children: tm[t]
                    }), (0, o.jsxs)("span", {
                      className: "text-[8px] font-mono mt-0.5",
                      style: {
                        color: "#444"
                      },
                      children: ["[", tx[t], "]"]
                    }), (0, o.jsx)("span", {
                      className: "text-[8px] font-mono mt-1.5 px-2 py-0.5 rounded",
                      style: {
                        color: "#555",
                        backgroundColor: "rgba(0,255,255,0.05)",
                        border: "1px solid rgba(0,255,255,0.15)"
                      },
                      children: "Empty Slot"
                    })]
                  })
                }, t)
              })
            })]
          }), (0, o.jsxs)("div", {
            className: "flex gap-1.5 mb-2 flex-wrap",
            children: [(0, o.jsx)("button", {
              onClick: () => A(() => u("all")),
              className: "px-2.5 py-1 rounded text-[10px] font-mono font-bold",
              style: {
                backgroundColor: "all" === f ? "rgba(255,255,255,0.15)" : "rgba(0,0,0,0.3)",
                border: `1px solid ${"all"===f?"#ffffff60":"#33333340"}`,
                color: "all" === f ? "#ffffff" : "#666"
              },
              children: "ALL"
            }), td.map(e => (0, o.jsx)("button", {
              onClick: () => A(() => u(e)),
              className: "px-2.5 py-1 rounded text-[10px] font-mono font-bold",
              style: {
                backgroundColor: f === e ? `${th[e]}25` : "rgba(0,0,0,0.3)",
                border: `1px solid ${f===e?th[e]+"60":"#33333340"}`,
                color: f === e ? th[e] : "#666"
              },
              children: tf[e]
            }, e))]
          })]
        }), (0, o.jsx)("div", {
          className: "flex-1 w-full max-w-2xl px-4 overflow-y-auto pb-4",
          style: {
            scrollbarWidth: "none"
          },
          children: (0, o.jsx)("div", {
            className: "flex flex-col gap-2",
            children: L.map(t => {
              let a = e.unlockedSkills.includes(t.id),
                i = D.indexOf(t.id),
                c = i >= 0,
                h = e.totalCoins >= t.unlockCost,
                f = "ad" === t.unlockMethod,
                u = ("purchase" === t.unlockMethod || "chest" === t.unlockMethod) && !a && h,
                m = a ? e.skillUpgrades[t.id] ?? 1 : 0,
                x = m >= 5,
                p = m + 1,
                g = a && !x ? M[p - 1] ?? 0 : 0,
                y = !!a && !x && (j[p - 1] ?? !1),
                N = e.totalCoins >= g,
                I = a ? S[m - 1] : 1,
                L = a ? T[m - 1] : 1,
                W = b === t.id,
                O = w === t.id,
                B = C === t.id;
              return (0, o.jsxs)("div", {
                className: "p-3 rounded-lg flex gap-3",
                style: {
                  backgroundColor: a ? `${t.color}08` : "rgba(0,0,0,0.2)",
                  border: `2px solid ${c?t.color:a?t.color+"40":"#33333330"}`,
                  boxShadow: c ? `0 0 15px ${t.color}30, inset 0 0 15px ${t.color}08` :
                    "none",
                  transition: "all 0.3s ease",
                  transform: O ? "scale(1.02)" : B ? "scale(0.98)" : "scale(1)"
                },
                children: [(0, o.jsxs)("div", {
                  className: "w-12 h-12 rounded flex items-center justify-center flex-shrink-0 relative",
                  style: {
                    backgroundColor: `${t.color}15`,
                    border: `1px solid ${t.color}40`
                  },
                  children: [(0, o.jsx)("div", {
                    className: "w-6 h-6 rounded-full",
                    style: {
                      backgroundColor: t.color,
                      boxShadow: `0 0 10px ${t.glowColor}`
                    }
                  }), a && (0, o.jsxs)("div", {
                    className: "absolute -top-1 -right-1 text-[7px] font-mono font-bold px-1 rounded",
                    style: {
                      backgroundColor: m >= 4 ? "#ffaa00" : "#333",
                      color: m >= 4 ? "#000" : "#ccc",
                      border: `1px solid ${m>=4?"#ffaa00":"#555"}`
                    },
                    children: ["LV", m]
                  })]
                }), (0, o.jsxs)("div", {
                  className: "flex-1 min-w-0",
                  children: [(0, o.jsxs)("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [(0, o.jsx)("span", {
                      className: "font-bold text-sm font-mono",
                      style: {
                        color: a ? t.color : "#555"
                      },
                      children: t.name
                    }), a && (0, o.jsxs)("span", {
                      className: "text-[8px] font-mono px-1.5 py-0.5 rounded",
                      style: {
                        backgroundColor: `${tu[t.rarity]}20`,
                        border: `1px solid ${tu[t.rarity]}40`,
                        color: tu[t.rarity]
                      },
                      children: ["LV ", m, "/", 5]
                    }), (0, o.jsx)("span", {
                      className: "text-[8px] font-mono px-1.5 py-0.5 rounded",
                      style: {
                        backgroundColor: `${tu[t.rarity]}20`,
                        border: `1px solid ${tu[t.rarity]}40`,
                        color: tu[t.rarity]
                      },
                      children: t.rarity.toUpperCase()
                    }), (0, o.jsx)("span", {
                      className: "text-[8px] font-mono px-1.5 py-0.5 rounded",
                      style: {
                        backgroundColor: `${th[t.element]}15`,
                        border: `1px solid ${th[t.element]}30`,
                        color: th[t.element]
                      },
                      children: tf[t.element]
                    })]
                  }), (0, o.jsx)("div", {
                    className: "text-[10px] font-mono mt-0.5",
                    style: {
                      color: a ? "#888" : "#444"
                    },
                    children: t.description
                  }), (0, o.jsxs)("div", {
                    className: "flex items-center gap-3 mt-1 text-[9px] font-mono",
                    style: {
                      color: "#666"
                    },
                    children: [(0, o.jsxs)("span", {
                      children: ["DMG: ", (0, o.jsx)("span", {
                        style: {
                          color: t.color
                        },
                        children: a ? Math.round(t.damage * I) : t
                          .damage
                      }), a && I > 1 && (0, o.jsxs)("span", {
                        style: {
                          color: "#ffaa00"
                        },
                        children: [" (×", I, ")"]
                      })]
                    }), (0, o.jsxs)("span", {
                      children: ["CD: ", (0, o.jsxs)("span", {
                        style: {
                          color: "#aaa"
                        },
                        children: [(t.cooldown * L / 60).toFixed(1),
                          "s"
                        ]
                      }), a && L < 1 && (0, o.jsxs)("span", {
                        style: {
                          color: "#00ff66"
                        },
                        children: [" (×", L, ")"]
                      })]
                    }), (0, o.jsxs)("span", {
                      children: ["Type: ", (0, o.jsx)("span", {
                        style: {
                          color: "#aaa"
                        },
                        children: t.effectType.toUpperCase()
                      })]
                    })]
                  }), a && !x && (0, o.jsxs)("div", {
                    className: "mt-1.5 flex items-center gap-2",
                    children: [(0, o.jsx)("div", {
                      className: "flex gap-0.5",
                      children: Array.from({
                        length: 5
                      }).map((e, a) => (0, o.jsx)("div", {
                        className: "w-5 h-1.5 rounded-sm",
                        style: {
                          backgroundColor: a < m ? t.color : "#222",
                          border: `1px solid ${a<m?t.color:"#444"}`
                        }
                      }, a))
                    }), (0, o.jsx)("button", {
                      onClick: () => {
                        var o;
                        let a, l, r, n;
                        return o = t.id, l = M[(a = (e.skillUpgrades[o] ??
                            1) + 1) - 1] ?? 0, r = j[a - 1] ?? !1, n = e
                          .totalCoins >= l, void(r && !n ? R(() => {
                            A(() => {
                              d(o) && (eo.playCoinCollect(), v(o),
                                setTimeout(() => v(null), 1e3))
                            })
                          }) : A(() => {
                            d(o) && (eo.playCoinCollect(), v(o),
                              setTimeout(() => v(null), 1e3))
                          }))
                      },
                      className: "text-[9px] font-mono font-bold px-2 py-0.5 rounded",
                      style: {
                        backgroundColor: W ? `${t.color}40` : y && !N ?
                          "rgba(0,255,255,0.1)" : N ?
                          "rgba(255,215,0,0.15)" : "rgba(0,0,0,0.3)",
                        border: `1px solid ${W?t.color:y&&!N?n:N?"#ffd700":"#333"}`,
                        color: W ? "#fff" : y && !N ? n : N ? "#ffd700" :
                          "#555",
                        transition: "all 0.3s",
                        transform: W ? "scale(1.1)" : "scale(1)"
                      },
                      children: W ? "✨ UPGRADED!" : y && !N ? "🎬 WATCH AD" :
                        `${g} 🪙`
                    })]
                  }), a && x && (0, o.jsxs)("div", {
                    className: "mt-1.5 text-[9px] font-mono font-bold",
                    style: {
                      color: "#ffaa00",
                      textShadow: "0 0 5px #ffaa00"
                    },
                    children: ["✨ MAX LEVEL — DMG ×", S[4], " | CD ×", T[4]]
                  })]
                }), (0, o.jsx)("div", {
                  className: "flex flex-col gap-1.5 items-end flex-shrink-0 justify-center",
                  children: a ? (0, o.jsxs)(o.Fragment, {
                    children: [c && (0, o.jsxs)("div", {
                      className: "flex flex-col items-end gap-1",
                      children: [(0, o.jsxs)("span", {
                        className: "text-[9px] font-mono font-bold px-2 py-0.5 rounded",
                        style: {
                          color: s,
                          backgroundColor: "rgba(0,255,102,0.12)",
                          border: "1px solid rgba(0,255,102,0.4)",
                          textShadow: "0 0 5px rgba(0,255,102,0.3)"
                        },
                        children: ["✓ SLOT ", i + 1]
                      }), (0, o.jsx)("button", {
                        onClick: () => E(i, t.id),
                        className: "text-[9px] font-mono font-bold px-2.5 py-1 rounded cursor-pointer",
                        style: {
                          backgroundColor: B ? "rgba(255,51,51,0.3)" :
                            "rgba(255,51,51,0.1)",
                          border: `1px solid ${B?"#ff3333":"rgba(255,51,51,0.4)"}`,
                          color: "#ff5555",
                          transition: "all 0.2s",
                          transform: B ? "scale(0.9)" : "scale(1)"
                        },
                        onMouseEnter: e => {
                          e.currentTarget.style.backgroundColor =
                            "rgba(255,51,51,0.25)", e.currentTarget
                            .style.transform = "scale(1.05)"
                        },
                        onMouseLeave: e => {
                          e.currentTarget.style.backgroundColor =
                            "rgba(255,51,51,0.1)", e.currentTarget
                            .style.transform = "scale(1)"
                        },
                        children: "✕ UNEQUIP"
                      })]
                    }), !c && (0, o.jsxs)("div", {
                      className: "flex flex-col items-end gap-1",
                      children: [(0, o.jsx)("span", {
                        className: "text-[8px] font-mono font-bold",
                        style: {
                          color: t.color
                        },
                        children: "EQUIP TO →"
                      }), (0, o.jsx)("div", {
                        className: "flex gap-1",
                        children: [0, 1, 2].map(e => {
                          let a = D[e],
                            l = a ? P.find(e => e.id === a) : null;
                          return (0, o.jsxs)("button", {
                            onClick: () => {
                              var o;
                              return o = t.id, void A(() => {
                                r(o, e), eo
                                  .playCoinCollect(), k(
                                  o), setTimeout(() => k(
                                    null), 800)
                              })
                            },
                            className: "text-[8px] font-mono font-bold px-2 py-1 rounded cursor-pointer",
                            style: {
                              backgroundColor: O ?
                                `${t.color}35` : a ?
                                `${t.color}15` : `${t.color}20`,
                              border: `1px solid ${O?t.color:a?t.color+"60":t.color+"50"}`,
                              color: t.color,
                              transition: "all 0.2s",
                              transform: O ? "scale(1.1)" :
                                "scale(1)"
                            },
                            title: a ?
                              `Replace ${l?.name??"skill"} in Slot ${e+1}` :
                              `Equip to Slot ${e+1} (${tm[e]})`,
                            onMouseEnter: e => {
                              e.currentTarget.style
                                .backgroundColor =
                                `${t.color}30`, e
                                .currentTarget.style
                                .transform = "scale(1.08)"
                            },
                            onMouseLeave: e => {
                              e.currentTarget.style
                                .backgroundColor = O ?
                                `${t.color}35` :
                                `${t.color}20`, e
                                .currentTarget.style
                                .transform = "scale(1)"
                            },
                            children: ["Slot ", e + 1, a && (0,
                              o.jsx)("span", {
                              style: {
                                color: "#ff5555"
                              },
                              children: " ⚡"
                            })]
                          }, e)
                        })
                      }), (0, o.jsx)("div", {
                        className: "text-[7px] font-mono",
                        style: {
                          color: "#555"
                        },
                        children: tm.map((e, t) => `${t+1}:${e}`).join(
                          " ")
                      })]
                    })]
                  }) : f ? (0, o.jsx)("button", {
                    onClick: () => h ? A(() => {
                      l(t.id), eo.playCoinCollect()
                    }) : R(() => A(() => {
                      l(t.id), eo.playCoinCollect()
                    })),
                    className: "text-[10px] font-mono font-bold px-2 py-1 rounded",
                    style: {
                      backgroundColor: h ? "rgba(255,215,0,0.15)" :
                        "rgba(0,255,255,0.1)",
                      border: `1px solid ${h?"#ffd700":n}`,
                      color: h ? "#ffd700" : n
                    },
                    children: h ? `${t.unlockCost} 🪙` : "🎬 WATCH AD"
                  }) : "purchase" === t.unlockMethod || "chest" === t.unlockMethod ? (
                    0, o.jsxs)("button", {
                    onClick: () => u && A(() => {
                      l(t.id), eo.playCoinCollect()
                    }),
                    className: "text-[10px] font-mono font-bold px-2 py-1 rounded",
                    style: {
                      backgroundColor: h ? "rgba(255,215,0,0.15)" :
                        "rgba(0,0,0,0.3)",
                      border: `1px solid ${h?"#ffd700":"#333"}`,
                      color: h ? "#ffd700" : "#555"
                    },
                    children: [t.unlockCost, " 🪙"]
                  }) : (0, o.jsx)("span", {
                    className: "text-[9px] font-mono",
                    style: {
                      color: "#555"
                    },
                    children: function(e) {
                      switch (e.unlockMethod) {
                        case "level":
                          return `Reach Lv.${e.unlockLevel}`;
                        case "boss":
                          return `Defeat ${e.unlockBoss||"Boss"}`;
                        case "chest":
                          return e.unlockCost > 0 ? `${e.unlockCost} Coins` :
                            "Find in Chest";
                        case "purchase":
                          return `${e.unlockCost} Coins`;
                        case "ad":
                          return `🎬 Watch Ad — ${e.unlockCost} Coins`;
                        case "story":
                          return "Story Unlock";
                        default:
                          return "???"
                      }
                    }(t)
                  })
                })]
              }, t.id)
            })
          })
        }), (0, o.jsx)("div", {
          className: "w-full max-w-2xl px-4 pb-4",
          children: (0, o.jsx)("button", {
            onClick: () => A(() => {
              ea.getState().currentLevel > 0 ? t("level-map") : t("menu")
            }),
            className: "neon-btn w-full py-2 px-4 text-sm tracking-wider",
            style: {
              borderColor: "#666",
              color: "#888"
            },
            children: "BACK"
          })
        })]
      })
    }

    function ty() {
      let e = ea(e => e.soundSettings),
        t = ea(e => e.setSoundSettings),
        a = ea(e => e.backToMenu),
        l = ea(e => e.setGamePhase),
        r = ea(e => e.currentLevel > 0),
        f = (e, o) => {
          t({
            [e]: o / 100
          }), eo.init(), eo.playMenuClick()
        },
        u = (e, o) => {
          t({
            [e]: o
          }), eo.init(), eo.playMenuClick()
        },
        m = e => ({
          WebkitAppearance: "none",
          appearance: "none",
          width: "100%",
          height: 6,
          borderRadius: 3,
          background: `linear-gradient(to right, ${e} 0%, ${e} var(--value), #222 var(--value), #222 100%)`,
          outline: "none",
          cursor: "pointer"
        });
      return (0, o.jsx)("div", {
        className: "absolute inset-0 z-20 flex items-center justify-center pointer-events-none",
        children: (0, o.jsxs)("div", {
          className: "w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-lg p-6 pointer-events-auto mx-4",
          style: {
            backgroundColor: "rgba(5, 5, 20, 0.97)",
            border: "2px solid #00ffff",
            boxShadow: "0 0 30px #00ffff20"
          },
          children: [(0, o.jsx)("h1", {
            className: "text-3xl font-bold text-center tracking-wider mb-6 font-mono",
            style: {
              color: s,
              textShadow: "0 0 10px #00ff66"
            },
            children: r ? "PAUSED" : "SETTINGS"
          }), (0, o.jsxs)("div", {
            className: "space-y-5 mb-6",
            children: [(0, o.jsxs)("div", {
              children: [(0, o.jsxs)("div", {
                className: "flex justify-between items-center mb-2",
                children: [(0, o.jsx)("label", {
                  className: "text-sm font-mono font-bold",
                  style: {
                    color: n,
                    textShadow: "0 0 5px #00ffff"
                  },
                  children: "MASTER VOLUME"
                }), (0, o.jsxs)("span", {
                  className: "text-sm font-mono",
                  style: {
                    color: n
                  },
                  children: [Math.round(100 * e.masterVolume), "%"]
                })]
              }), (0, o.jsx)("input", {
                type: "range",
                min: "0",
                max: "100",
                value: Math.round(100 * e.masterVolume),
                onChange: e => f("masterVolume", parseInt(e.target.value)),
                className: "w-full",
                style: {
                  ...m(n),
                  "--value": `${100*e.masterVolume}%`
                }
              })]
            }), (0, o.jsxs)("div", {
              children: [(0, o.jsxs)("div", {
                className: "flex justify-between items-center mb-2",
                children: [(0, o.jsx)("label", {
                  className: "text-sm font-mono font-bold",
                  style: {
                    color: c,
                    textShadow: "0 0 5px #ff6600"
                  },
                  children: "SFX VOLUME"
                }), (0, o.jsxs)("div", {
                  className: "flex items-center gap-3",
                  children: [(0, o.jsxs)("span", {
                    className: "text-sm font-mono",
                    style: {
                      color: c
                    },
                    children: [Math.round(100 * e.sfxVolume), "%"]
                  }), (0, o.jsx)("button", {
                    onClick: () => u("sfxEnabled", !e.sfxEnabled),
                    className: "px-2 py-0.5 text-xs font-mono font-bold rounded",
                    style: {
                      border: `1px solid ${e.sfxEnabled?s:"#555"}`,
                      color: e.sfxEnabled ? s : "#555",
                      backgroundColor: e.sfxEnabled ? "rgba(0,255,102,0.1)" :
                        "transparent"
                    },
                    children: e.sfxEnabled ? "ON" : "OFF"
                  })]
                })]
              }), (0, o.jsx)("input", {
                type: "range",
                min: "0",
                max: "100",
                value: Math.round(100 * e.sfxVolume),
                onChange: e => f("sfxVolume", parseInt(e.target.value)),
                className: "w-full",
                style: {
                  ...m(c),
                  "--value": `${100*e.sfxVolume}%`
                }
              })]
            }), (0, o.jsxs)("div", {
              children: [(0, o.jsxs)("div", {
                className: "flex justify-between items-center mb-2",
                children: [(0, o.jsx)("label", {
                  className: "text-sm font-mono font-bold",
                  style: {
                    color: i,
                    textShadow: "0 0 5px #ff00ff"
                  },
                  children: "MUSIC VOLUME"
                }), (0, o.jsxs)("div", {
                  className: "flex items-center gap-3",
                  children: [(0, o.jsxs)("span", {
                    className: "text-sm font-mono",
                    style: {
                      color: i
                    },
                    children: [Math.round(100 * e.musicVolume), "%"]
                  }), (0, o.jsx)("button", {
                    onClick: () => u("musicEnabled", !e.musicEnabled),
                    className: "px-2 py-0.5 text-xs font-mono font-bold rounded",
                    style: {
                      border: `1px solid ${e.musicEnabled?s:"#555"}`,
                      color: e.musicEnabled ? s : "#555",
                      backgroundColor: e.musicEnabled ?
                        "rgba(0,255,102,0.1)" : "transparent"
                    },
                    children: e.musicEnabled ? "ON" : "OFF"
                  })]
                })]
              }), (0, o.jsx)("input", {
                type: "range",
                min: "0",
                max: "100",
                value: Math.round(100 * e.musicVolume),
                onChange: e => f("musicVolume", parseInt(e.target.value)),
                className: "w-full",
                style: {
                  ...m(i),
                  "--value": `${100*e.musicVolume}%`
                }
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "rounded-lg p-4 mb-6",
            style: {
              backgroundColor: "rgba(0,255,255,0.03)",
              border: "1px solid rgba(0,255,255,0.15)"
            },
            children: [(0, o.jsx)("h3", {
              className: "text-sm font-mono font-bold mb-3",
              style: {
                color: d,
                textShadow: "0 0 5px #ffff00"
              },
              children: "CONTROLS"
            }), (0, o.jsxs)("div", {
              className: "grid grid-cols-2 gap-4",
              children: [(0, o.jsxs)("div", {
                children: [(0, o.jsx)("div", {
                  className: "text-xs font-mono font-bold mb-1.5",
                  style: {
                    color: n
                  },
                  children: "TOUCH CONTROLS"
                }), (0, o.jsxs)("div", {
                  className: "text-[10px] font-mono space-y-0.5",
                  style: {
                    color: "#888"
                  },
                  children: [(0, o.jsx)("p", {
                    children: "Joystick — Move"
                  }), (0, o.jsx)("p", {
                    children: "⬆ — Jump"
                  }), (0, o.jsx)("p", {
                    children: "🔥 — Shoot"
                  }), (0, o.jsx)("p", {
                    children: "⚡ — Dash/Skill 1"
                  }), (0, o.jsx)("p", {
                    children: "🛡 — Shield/Skill 2"
                  }), (0, o.jsx)("p", {
                    children: "✦ — Special/Skill 3"
                  })]
                })]
              }), (0, o.jsxs)("div", {
                children: [(0, o.jsx)("div", {
                  className: "text-xs font-mono font-bold mb-1.5",
                  style: {
                    color: h
                  },
                  children: "TIPS"
                }), (0, o.jsxs)("div", {
                  className: "text-[10px] font-mono space-y-0.5",
                  style: {
                    color: "#888"
                  },
                  children: [(0, o.jsx)("p", {
                    children: "Hold 🔥 for auto-fire"
                  }), (0, o.jsx)("p", {
                    children: "Double-tap ⬆ for double jump"
                  }), (0, o.jsx)("p", {
                    children: "Use skills wisely — they have cooldowns"
                  }), (0, o.jsx)("p", {
                    children: "Watch ads to earn coins"
                  }), (0, o.jsx)("p", {
                    children: "Complete levels to unlock skins"
                  }), (0, o.jsx)("p", {
                    children: "Upgrade weapons for more power"
                  })]
                })]
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "flex gap-3",
            children: [r && (0, o.jsx)("button", {
              onClick: () => {
                eo.playMenuClick(), l("playing")
              },
              className: "neon-btn flex-1 py-3 px-4 text-lg font-bold font-mono tracking-wider",
              style: {
                borderColor: s,
                color: s,
                textShadow: "0 0 10px #00ff66"
              },
              children: "RESUME"
            }), (0, o.jsx)("button", {
              onClick: () => {
                eo.playMenuClick(), a()
              },
              className: "neon-btn flex-1 py-3 px-4 text-sm font-bold font-mono tracking-wider",
              style: {
                borderColor: "#666",
                color: "#888",
                textShadow: "none"
              },
              children: "QUIT"
            })]
          })]
        })
      })
    }
    let tb = ["xXDarkSlayerXx", "NeonPhantom", "PixelKnight", "GridWalker", "VoidHunter", "CyberSamurai",
        "FlameReaper", "StormBlade", "GhostRunner", "IronFist", "ShadowPulse", "NovaStrike", "RoguePixel",
        "ZeroPoint", "CodeBreaker", "NightGrid", "ApexNeon", "TurboFlux", "DarkCircuit", "QuantumEdge"
      ],
      tv = ["🐉", "💀", "🔥", "⚡", "🗡️", "🛡️", "🎯", "👻", "🤖", "👾", "🦊", "🐺", "🦅", "🐍", "🦂", "🌋", "🌀", "💎", "⭐", "🌙"],
      tw = ["Nice shot!", "GG!", "Wow!", "Too easy!", "Close one!", "Lucky!", "Let's go!", "No way!", "Haha!",
        "Rematch?"
      ];

    function tk() {
      let e = (0, a.useRef)(null),
        t = (0, a.useRef)(0),
        l = (0, a.useRef)(0),
        r = ea(e => e.saveData),
        x = ea(e => e.updateRanking),
        p = ea(e => e.backToMenu),
        [g, y] = (0, a.useState)("lobby"),
        [b, v] = (0, a.useState)(0),
        [w, k] = (0, a.useState)(null),
        [C, S] = (0, a.useState)(""),
        [T, M] = (0, a.useState)(""),
        [j, N] = (0, a.useState)(!1),
        [P, A] = (0, a.useState)(null),
        [R, I] = (0, a.useState)(0),
        [E, L] = (0, a.useState)(0),
        D = (0, a.useRef)("lobby"),
        W = (0, a.useRef)(null),
        B = (0, a.useRef)(null),
        G = (0, a.useRef)({
          x: 50,
          y: 460,
          health: 500,
          maxHealth: 500,
          team: "blue"
        }),
        $ = (0, a.useRef)({
          x: 1520,
          y: 460,
          health: 500,
          maxHealth: 500,
          team: "red"
        }),
        F = (0, a.useRef)([]),
        H = (0, a.useRef)([]),
        U = (0, a.useRef)(0),
        V = (0, a.useRef)({
          left: !1,
          right: !1,
          up: !1,
          shoot: !1,
          dash: !1,
          shield: !1,
          special: !1
        }),
        z = (0, a.useRef)(.5),
        _ = (0, a.useRef)([]),
        K = (0, a.useRef)(0),
        q = (0, a.useRef)(null),
        Y = O(r.rankingData.elo);
      (0, a.useEffect)(() => {}, []), (0, a.useEffect)(() => {
        if ("searching" !== g) return;
        let e = setInterval(() => {
          v(t => t >= 3 ? (y("matched"), D.current = "matched", clearInterval(e), eo.init(), eo
            .playWaveComplete(), 0) : t + 1)
        }, 1e3);
        return () => clearInterval(e)
      }, [g]), (0, a.useEffect)(() => {
        if ("matched" !== g) return;
        let e = setTimeout(() => {
          y("playing"), D.current = "playing"
        }, 2e3);
        return () => clearTimeout(e)
      }, [g]);
      let J = (0, a.useRef)(0);
      (0, a.useEffect)(() => {
        if ("result" !== g) return;
        J.current = Date.now();
        let e = setInterval(() => {
          L(Math.floor((Date.now() - J.current) / 1e3))
        }, 1e3);
        return () => clearInterval(e)
      }, [g]);
      let Z = (0, a.useCallback)(() => {
        W.current = {
            x: 150,
            y: 460,
            vx: 0,
            vy: 0,
            health: 100,
            maxHealth: 100,
            facing: 1,
            grounded: !1,
            jumpCount: 0,
            shootCooldown: 0,
            animFrame: 0,
            isMoving: !1,
            isShooting: !1,
            color: n,
            dashCooldown: 0,
            isDashing: !1,
            dashTimer: 0,
            shieldCooldown: 0,
            isShielding: !1,
            shieldTimer: 0,
            specialCooldown: 0,
            isUsingSpecial: !1,
            specialTimer: 0,
            invincible: 0
          }, B.current = {
            x: 1450,
            y: 460,
            vx: 0,
            vy: 0,
            health: 100,
            maxHealth: 100,
            facing: -1,
            grounded: !1,
            jumpCount: 0,
            shootCooldown: 0,
            animFrame: 0,
            isMoving: !1,
            isShooting: !1,
            color: f,
            dashCooldown: 0,
            isDashing: !1,
            dashTimer: 0,
            shieldCooldown: 0,
            isShielding: !1,
            shieldTimer: 0,
            specialCooldown: 0,
            isUsingSpecial: !1,
            specialTimer: 0,
            invincible: 0
          }, G.current = {
            x: 50,
            y: 460,
            health: 500,
            maxHealth: 500,
            team: "blue"
          }, $.current = {
            x: 1520,
            y: 460,
            health: 500,
            maxHealth: 500,
            team: "red"
          }, F.current = [], H.current = [], U.current = 0, l.current = 0, _.current = [], K.current > 0 ? z
          .current = Math.min(1, .5 + .15 * K.current) : K.current < 0 ? z.current = Math.max(.1, .5 + .1 * K
            .current) : z.current = .5
      }, []);
      (0, a.useEffect)(() => {
        "playing" === g && Z()
      }, [g, Z]), (0, a.useEffect)(() => {
        let o = e.current;
        if (!o) return;
        let a = o.getContext("2d");
        if (!a) return;
        let h = () => {
          o.width = window.innerWidth, o.height = window.innerHeight
        };
        h(), window.addEventListener("resize", h);
        let m = () => {
          t.current = requestAnimationFrame(m), l.current++;
          let e = o.width,
            h = o.height;
          if ("playing" !== D.current) {
            a.fillStyle = u, a.fillRect(0, 0, e, h), a.globalAlpha = .04, a.strokeStyle = n, a.lineWidth = 1;
            let t = .3 * l.current % 80;
            for (let o = t; o < e; o += 80) a.beginPath(), a.moveTo(o, 0), a.lineTo(o, h), a.stroke();
            for (let t = 0; t < h; t += 80) a.beginPath(), a.moveTo(0, t), a.lineTo(e, t), a.stroke();
            a.globalAlpha = 1;
            return
          }
          let p = W.current,
            g = B.current;
          if (!p || !g) return;
          let b = z.current,
            v = V.current,
            w = 0;
          if (v.left && (w = -1, p.facing = -1), v.right && (w = 1, p.facing = 1), v.dash && p.dashCooldown <=
            0 && !p.isDashing && (p.isDashing = !0, p.dashTimer = 8, p.dashCooldown = 90, p.invincible = 8, p.x,
              p.y), p.isDashing ? (p.dashTimer -= (eG ? 2 : 1), p.vx = 18 * p.facing, p.dashTimer <= 0 && (p
              .isDashing = !1)) : p.vx = (p.grounded ? 4.5 : 3) * w, v.shield && p.shieldCooldown <= 0 && !p
            .isShielding && (p.isShielding = !0, p.shieldTimer = 120, p.shieldCooldown = 300), p.isShielding &&
            (p.shieldTimer -= (eG ? 2 : 1), p.shieldTimer <= 0 && (p.isShielding = !1)), v.special && p
            .specialCooldown <= 0 && !p.isUsingSpecial) {
            p.isUsingSpecial = !0, p.specialTimer = 30, p.specialCooldown = 360;
            for (let e = -.4; e <= .41; e += .13) {
              let t = 9 * p.facing;
              H.current.push({
                x: p.x + 15 * p.facing,
                y: p.y - 25,
                vx: t * Math.cos(e),
                vy: t * Math.sin(e),
                fromBlue: !0,
                damage: 8,
                active: !0,
                color: c,
                radius: 4
              })
            }
          }
          p.isUsingSpecial && (p.specialTimer -= (eG ? 2 : 1), p.specialTimer <= 0 && (p.isUsingSpecial = !1)),
            p.isMoving = Math.abs(w) > 0, v.up && p.jumpCount < 2 && (p.vy = -12, p.grounded = !1, p
              .jumpCount++, eo.init(), eo.playJump()), p.shootCooldown > 0 && (p.shootCooldown -= (eG ? 2 : 1)),
            v.shoot && p.shootCooldown <= 0 && !p.isDashing ? (H.current.push({
              x: p.x + 15 * p.facing,
              y: p.y - 25,
              vx: 9 * p.facing,
              vy: 0,
              fromBlue: !0,
              damage: 8,
              active: !0,
              color: n,
              radius: 4
            }), p.shootCooldown = 10, p.isShooting = !0, eo.init(), eo.playShoot()) : p.isShooting = !1, p
            .dashCooldown > 0 && p.dashCooldown--, p.shieldCooldown > 0 && p.shieldCooldown--, p
            .specialCooldown > 0 && p.specialCooldown--, p.invincible > 0 && (p.invincible -= (eG ? 2 : 1)), p
            .vy += .5, p.vy > 10 && (p.vy = 10), p.x += p.vx, p.y += p.vy, p.y >= 460 && (p.y = 460, p.vy = 0, p
              .grounded = !0, p.jumpCount = 0), p.x < 50 && (p.x = 50), p.x > 1550 && (p.x = 1550);
          let C = Math.abs(g.x - p.x);
          if (Math.random() > (1 - b) * .02 ? C > 200 ? (g.vx = (p.x > g.x ? 1 : -1) * (2 + 2 * b), g.facing = g
              .vx > 0 ? 1 : -1, g.isMoving = !0) : (Math.random() < .3 * b ? g.vx = (p.x > g.x ? -1 : 1) * 2 : g
              .vx = 0, g.isMoving = Math.abs(g.vx) > 0, g.facing = p.x > g.x ? 1 : -1) : (g.vx = 0, g
              .isMoving = !1, g.facing = p.x > g.x ? 1 : -1), g.shootCooldown > 0 && (g.shootCooldown -= (eG ?
              2 : 1)), g.shootCooldown <= 0 && C < 400) {
            let e = p.x - g.x,
              t = p.y - 25 - (g.y - 25),
              o = Math.sqrt(e * e + t * t);
            if (o > 0) {
              let a = (1 - (.7 + .3 * b)) * .5,
                l = (Math.random() - .5) * a,
                r = (Math.random() - .5) * a;
              H.current.push({
                x: g.x + 15 * g.facing,
                y: g.y - 25,
                vx: (e / o + l) * 7,
                vy: (t / o + r) * 7,
                fromBlue: !1,
                damage: 8,
                active: !0,
                color: f,
                radius: 3
              })
            }
            g.shootCooldown = Math.floor((30 + 20 * Math.random()) / (.5 + .5 * b)), g.isShooting = !0
          } else g.isShooting = !1;
          if (g.dashCooldown > 0 && g.dashCooldown--, g.shieldCooldown > 0 && g.shieldCooldown--, g
            .specialCooldown > 0 && g.specialCooldown--, g.invincible > 0 && (g.invincible -= (eG ? 2 : 1)), b >
            .6 && g.dashCooldown <= 0 && C < 200 && Math.random() < .01 * b && (g.isDashing = !0, g.dashTimer =
              8, g.dashCooldown = 90, g.invincible = 8), g.isDashing && (g.dashTimer -= (eG ? 2 : 1), g.vx =
              18 * g.facing, g.dashTimer <= 0 && (g.isDashing = !1)), g.health < .4 * g.maxHealth && g
            .shieldCooldown <= 0 && .005 > Math.random() && (g.isShielding = !0, g.shieldTimer = 60, g
              .shieldCooldown = 200), g.isShielding && (g.shieldTimer -= (eG ? 2 : 1), g.shieldTimer <= 0 && (g
              .isShielding = !1)), b > .5 && g.specialCooldown <= 0 && C < 350 && Math.random() < .003 * b) {
            g.isUsingSpecial = !0, g.specialTimer = 30, g.specialCooldown = 360;
            for (let e = -.3; e <= .31; e += .15) {
              let t = 8 * g.facing;
              H.current.push({
                x: g.x + 15 * g.facing,
                y: g.y - 25,
                vx: t * Math.cos(e),
                vy: t * Math.sin(e),
                fromBlue: !1,
                damage: 6,
                active: !0,
                color: i,
                radius: 3
              })
            }
          }
          g.isUsingSpecial && (g.specialTimer -= (eG ? 2 : 1), g.specialTimer <= 0 && (g.isUsingSpecial = !1)),
            g.grounded && Math.random() < .01 + .02 * b && (g.vy = -11, g.grounded = !1), g.vy += .5, g.vy >
            10 && (g.vy = 10), g.x += g.vx, g.y += g.vy, g.y >= 460 && (g.y = 460, g.vy = 0, g.grounded = !0, g
              .jumpCount = 0), g.x < 50 && (g.x = 50), g.x > 1550 && (g.x = 1550);
          let S = q.current;
          if (.003 > Math.random() && S) {
            let e = tw[Math.floor(Math.random() * tw.length)];
            _.current.push({
              text: `${S.name}: ${e}`,
              timer: 120,
              color: f
            })
          }
          for (let e of (_.current = _.current.filter(e => (e.timer--, e.timer > 0)), U.current++, U.current >=
              300 && (U.current = 0, F.current.push({
                x: 100,
                y: 460,
                vx: 1.5,
                vy: 0,
                team: "blue",
                health: 40,
                maxHealth: 40,
                facing: 1,
                attackCooldown: 0,
                animFrame: 0,
                active: !0
              }), F.current.push({
                x: 1500,
                y: 460,
                vx: -1.5,
                vy: 0,
                team: "red",
                health: 40,
                maxHealth: 40,
                facing: -1,
                attackCooldown: 0,
                animFrame: 0,
                active: !0
              })), F.current)) {
            if (!e.active) continue;
            e.animFrame++;
            let t = F.current.filter(t => t.active && t.team !== e.team && 100 > Math.abs(t.x - e.x));
            if (t.length > 0) {
              let o = t[0];
              e.attackCooldown--, e.attackCooldown <= 0 && (o.health -= 5, e.attackCooldown = 30, o.health <=
                0 && (o.active = !1)), e.vx = 0
            } else e.vx = "blue" === e.team ? 1.2 : -1.2;
            "blue" === e.team && e.x >= $.current.x - 20 && ($.current.health -= 1, e.vx = 0, e
              .attackCooldown--, e.attackCooldown <= 0 && ($.current.health -= 2, e.attackCooldown = 30, eo
                .init(), eo.playHit())), "red" === e.team && e.x <= G.current.x + 40 && (G.current.health -=
              1, e.vx = 0, e.attackCooldown--, e.attackCooldown <= 0 && (G.current.health -= 2, e
                .attackCooldown = 30)), e.x += e.vx
          }
          for (let e of (F.current = F.current.filter(e => e.active), H.current))
            if (e.active) {
              if (e.x += e.vx, e.y += e.vy, e.x < -20 || e.x > 1620) {
                e.active = !1;
                continue
              }
              if (e.fromBlue) {
                let t = B.current;
                for (let o of (t && t.invincible <= 0 && !t.isShielding && 15 > Math.abs(e.x - t.x) && 25 > Math
                    .abs(e.y - (t.y - 25)) && (t.health -= e.damage, t.invincible = 20, e.active = !1, eo
                      .init(), eo.playHit()), F.current))
                  if (o.active && "red" === o.team && 15 > Math.abs(e.x - o.x) && 15 > Math.abs(e.y - (o.y -
                      15))) {
                    o.health -= e.damage, e.active = !1, o.health <= 0 && (o.active = !1, eo.init(), eo
                      .playEnemyDeath());
                    break
                  }
              } else
                for (let t of (p.invincible <= 0 && !p.isShielding && 15 > Math.abs(e.x - p.x) && 25 > Math.abs(
                    e.y - (p.y - 25)) && (p.health -= e.damage, p.invincible = 20, e.active = !1, eo.init(),
                    eo.playDamage()), F.current))
                  if (t.active && "blue" === t.team && 15 > Math.abs(e.x - t.x) && 15 > Math.abs(e.y - (t.y -
                      15))) {
                    t.health -= e.damage, e.active = !1, t.health <= 0 && (t.active = !1);
                    break
                  }
            } H.current = H.current.filter(e => e.active);
          let T = G.current,
            M = $.current;
          if (M.health <= 0 || g.health <= 0) {
            D.current = "result", k("win"), y("result"), K.current = Math.max(K.current + 1, 1), I(K.current),
              x(!0), eo.init(), eo.playLevelComplete();
            return
          }
          if (T.health <= 0 || p.health <= 0) {
            D.current = "result", k("loss"), y("result"), K.current = Math.min(K.current - 1, -1), I(K.current),
              x(!1), eo.init(), eo.playGameOver();
            return
          }
          a.fillStyle = u, a.fillRect(0, 0, e, h);
          let j = Math.min(e / 1600, h / 500),
            N = (e - 1600 * j) / 2,
            P = (h - 500 * j) / 2;
          a.save(), a.translate(N, P), a.scale(j, j), a.globalAlpha = .05, a.strokeStyle = n, a.lineWidth = 1;
          for (let e = 0; e < 1600; e += 80) a.beginPath(), a.moveTo(e, 0), a.lineTo(e, 500), a.stroke();
          for (let e = 0; e < 500; e += 80) a.beginPath(), a.moveTo(0, e), a.lineTo(1600, e), a.stroke();
          a.globalAlpha = 1, a.fillStyle = "#0a1a1a", a.fillRect(0, 460, 1600, 40), a.strokeStyle = s, a
            .shadowBlur = 8, a.shadowColor = s, a.lineWidth = 2, a.beginPath(), a.moveTo(0, 460), a.lineTo(1600,
              460), a.stroke(), a.shadowBlur = 0, a.globalAlpha = .1, a.strokeStyle = d, a.lineWidth = 1, a
            .setLineDash([5, 10]), a.beginPath(), a.moveTo(800, 360), a.lineTo(800, 460), a.stroke(), a
            .setLineDash([]), a.globalAlpha = 1, a.fillStyle = "rgba(0,255,255,0.08)", a.fillRect(T.x - 10, 380,
              50, 80), a.strokeStyle = n, a.shadowBlur = 10, a.shadowColor = n, a.lineWidth = 2, a.strokeRect(T
              .x - 10, 380, 50, 80);
          let A = Math.max(0, T.health / T.maxHealth);
          a.fillStyle = "#001a00", a.fillRect(T.x - 15, 370, 60, 6), a.fillStyle = n, a.shadowColor = n, a
            .fillRect(T.x - 15, 370, 60 * A, 6), a.shadowBlur = 0, a.fillStyle = "rgba(255,51,51,0.08)", a
            .fillRect(M.x - 10, 380, 50, 80), a.strokeStyle = f, a.shadowBlur = 10, a.shadowColor = f, a
            .lineWidth = 2, a.strokeRect(M.x - 10, 380, 50, 80);
          let R = Math.max(0, M.health / M.maxHealth);
          for (let e of (a.fillStyle = "#1a0000", a.fillRect(M.x - 15, 370, 60, 6), a.fillStyle = f, a
              .shadowColor = f, a.fillRect(M.x - 15, 370, 60 * R, 6), a.shadowBlur = 0, F.current)) {
            if (!e.active) continue;
            let t = "blue" === e.team ? n : f;
            a.strokeStyle = t, a.shadowBlur = 5, a.shadowColor = t, a.lineWidth = 1.5;
            let o = e.x,
              l = e.y;
            a.beginPath(), a.arc(o, l - 30, 5, 0, 2 * Math.PI), a.stroke(), a.beginPath(), a.moveTo(o, l - 25),
              a.lineTo(o, l - 8), a.stroke(), a.beginPath(), a.moveTo(o, l - 20), a.lineTo(o - 6, l - 14), a
              .stroke(), a.beginPath(), a.moveTo(o, l - 20), a.lineTo(o + 6, l - 14), a.stroke(), a.beginPath(),
              a.moveTo(o, l - 8), a.lineTo(o - 5, l), a.stroke(), a.beginPath(), a.moveTo(o, l - 8), a.lineTo(
                o + 5, l), a.stroke();
            let r = e.health / e.maxHealth;
            a.fillStyle = "#111", a.fillRect(o - 10, l - 38, 20, 3), a.fillStyle = r > .5 ? s : r > .25 ? c : f,
              a.fillRect(o - 10, l - 38, 20 * r, 3), a.shadowBlur = 0
          }
          tC(a, p.x, p.y, p.facing, p.color, p.animFrame, p.isShooting, p.grounded, p.isMoving, p.isShielding, p
            .invincible > 0);
          let E = Math.max(0, p.health / p.maxHealth);
          a.fillStyle = "#111", a.fillRect(p.x - 15, p.y - 55, 30, 4), a.fillStyle = E > .5 ? s : E > .25 ? c :
            f, a.shadowBlur = 3, a.shadowColor = a.fillStyle, a.fillRect(p.x - 15, p.y - 55, 30 * E, 4), a
            .shadowBlur = 0, tC(a, g.x, g.y, g.facing, g.color, g.animFrame, g.isShooting, g.grounded, g
              .isMoving, g.isShielding, g.invincible > 0);
          let L = Math.max(0, g.health / g.maxHealth);
          for (let e of (a.fillStyle = "#111", a.fillRect(g.x - 15, g.y - 55, 30, 4), a.fillStyle = f, a
              .fillRect(g.x - 15, g.y - 55, 30 * L, 4), H.current)) e.active && (a.shadowBlur = 8, a
            .shadowColor = e.color, a.fillStyle = "#ffffff", a.beginPath(), a.arc(e.x, e.y, e.radius, 0, 2 *
              Math.PI), a.fill(), a.globalAlpha = .4, a.fillStyle = e.color, a.beginPath(), a.arc(e.x, e.y,
              2 * e.radius, 0, 2 * Math.PI), a.fill(), a.globalAlpha = 1, a.shadowBlur = 0);
          a.globalAlpha = .8, a.font = "12px monospace", a.textAlign = "left";
          let O = 80;
          for (let e of _.current.slice(-3)) a.globalAlpha = .8 * Math.min(1, e.timer / 30), a.shadowBlur = 3, a
            .shadowColor = e.color, a.fillStyle = e.color, a.fillText(e.text, 480, O), O += 16;
          a.shadowBlur = 0, a.globalAlpha = 1, a.globalAlpha = .9, a.font = "bold 14px monospace", a.textAlign =
            "center", a.shadowBlur = 5, a.shadowColor = n, a.fillStyle = n, a.font = "16px sans-serif", a
            .fillText(r.avatar, 345, 32), a.font = "bold 14px monospace", a.fillText(r.username, 400, 32), a
            .shadowColor = f, a.fillStyle = f, S && (a.font = "16px sans-serif", a.fillText(S.avatar, 1145,
            32)), a.font = "bold 14px monospace", a.fillText(S?.name ?? "???", 1200, 32), a.shadowColor = d, a
            .fillStyle = d, a.fillText("ONLINE ARENA", 800, 32), Math.abs(K.current) > 1 && (a.font =
              "10px monospace", a.fillStyle = K.current > 0 ? s : f, a.shadowColor = a.fillStyle, a.fillText(K
                .current > 0 ? `${K.current} WIN STREAK` : `${Math.abs(K.current)} LOSS STREAK`, 800, 48)), a
            .shadowBlur = 0, a.globalAlpha = 1;
          a.font = "9px monospace", a.textAlign = "center";
          let Y = [{
            label: "",
            cd: p.dashCooldown,
            max: 90,
            color: n
          }, {
            label: "",
            cd: p.shieldCooldown,
            max: 300,
            color: s
          }, {
            label: "",
            cd: p.specialCooldown,
            max: 360,
            color: c
          }];
          for (let e = 0; e < Y.length; e++) {
            let t = Y[e],
              o = 240 + 45 * e,
              l = t.cd <= 0;
            a.globalAlpha = l ? 1 : .4, a.strokeStyle = t.color, a.lineWidth = l ? 2 : 1, a.shadowBlur = 5 * !!
              l, a.shadowColor = t.color, a.strokeRect(o - 15, 477, 30, 16), a.fillStyle = t.color, a.fillText(t
                .label, o, 488), a.shadowBlur = 0
          }
          a.globalAlpha = 1, a.restore()
        };
        return m(), () => {
          cancelAnimationFrame(t.current), window.removeEventListener("resize", h)
        }
      }, [P, r.username, r.avatar, x]);
      let X = (0, a.useCallback)(() => {
          var e;
          let t, o, a, l, n, i, s, c, d = (e = r.rankingData.elo, a = tb[Math.floor((o = (t = 9301 * Date.now() +
              49297, () => (t = (9301 * t + 49297) % 233280) / 233280))() * tb.length)], l = tv[Math.floor(o() *
              tv.length)], n = Math.max(100, e + Math.floor((o() - .5) * 400)), i = Math.floor(50 * o()) + 5,
            s = Math.floor(40 * o()) + 2, c = O(n), {
              name: a,
              avatar: l,
              elo: n,
              wins: i,
              losses: s,
              rank: c.rank,
              rankIcon: c.icon
            });
          A(d), q.current = d, y("searching"), v(0), D.current = "searching"
        }, [r.rankingData.elo]),
        Q = () => {
          eo.init(), eo.playMenuClick(), D.current = "lobby", p()
        },
        [ee, et] = (0, a.useState)(!1),
        [el, er] = (0, a.useState)(!1),
        en = (e, t) => {
          if (V.current[e] = t, t) try {
            navigator.vibrate?.(10)
          } catch {}
        },
        ei = (e, t, a = 48) => (0, o.jsx)("div", {
          className: "rounded-full flex items-center justify-center flex-shrink-0",
          style: {
            width: a,
            height: a,
            border: `3px solid ${t}`,
            backgroundColor: "rgba(0,0,0,0.5)",
            boxShadow: `0 0 15px ${t}40`,
            fontSize: .5 * a
          },
          children: e
        });
      return (0, o.jsxs)("div", {
        style: {
          backgroundColor: u
        },
        className: "jsx-bfd3ab80909036c6 absolute inset-0 z-20",
        children: [(0, o.jsx)("canvas", {
          ref: e,
          style: {
            touchAction: "none"
          },
          className: "jsx-bfd3ab80909036c6 absolute inset-0 w-full h-full"
        }), "playing" === g && (0, o.jsxs)("div", {
          style: {
            touchAction: "none"
          },
          className: "jsx-bfd3ab80909036c6 absolute inset-0 z-30 pointer-events-none select-none",
          children: [(0, o.jsx)("div", {
            style: {
              touchAction: "none"
            },
            className: "jsx-bfd3ab80909036c6 absolute bottom-5 left-5 flex gap-3 pointer-events-auto",
            children: ["left", "right"].map(e => (0, o.jsx)("button", {
              style: {
                backgroundColor: "rgba(0,255,255,0.1)",
                border: `2px solid ${n}80`,
                color: n
              },
              onTouchStart: t => {
                t.preventDefault(), en(e, !0)
              },
              onTouchEnd: t => {
                t.preventDefault(), en(e, !1)
              },
              onTouchCancel: t => {
                t.preventDefault(), en(e, !1)
              },
              "aria-label": "left" === e ? "Move left" : "Move right",
              className: "jsx-bfd3ab80909036c6 w-16 h-16 rounded-full active:scale-90 font-bold text-2xl",
              children: "left" === e ? "‹" : "›"
            }, e))
          }), (0, o.jsx)("div", {
            style: {
              touchAction: "none"
            },
            className: "jsx-bfd3ab80909036c6 absolute bottom-5 right-5 flex items-end gap-2 pointer-events-auto",
            children: [
              ["dash", "DASH", n],
              ["shield", "SHLD", s],
              ["special", "SPCL", c],
              ["up", "JUMP", s],
              ["shoot", "FIRE", i]
            ].map(([e, t, a]) => (0, o.jsx)("button", {
              style: {
                width: "shoot" === e ? 74 : "up" === e ? 64 : 52,
                height: "shoot" === e ? 74 : "up" === e ? 64 : 52,
                backgroundColor: `${a}18`,
                border: `2px solid ${a}80`,
                color: a,
                fontSize: "shoot" === e ? 12 : 10,
                textShadow: `0 0 6px ${a}`
              },
              onTouchStart: t => {
                t.preventDefault(), en(e, !0)
              },
              onTouchEnd: t => {
                t.preventDefault(), en(e, !1)
              },
              onTouchCancel: t => {
                t.preventDefault(), en(e, !1)
              },
              "aria-label": t,
              className: "jsx-bfd3ab80909036c6 rounded-full active:scale-90 font-mono font-bold",
              children: t
            }, e))
          })]
        }), "lobby" === g && (0, o.jsx)("div", {
          className: "jsx-bfd3ab80909036c6 absolute inset-0 flex items-center justify-center pointer-events-auto",
          children: (0, o.jsxs)("div", {
            style: {
              backgroundColor: "rgba(5,5,20,0.95)",
              border: "2px solid #ff6600",
              boxShadow: "0 0 30px #ff660020"
            },
            className: "jsx-bfd3ab80909036c6 w-full max-w-md p-4 sm:p-6 rounded-lg mx-4",
            children: [(0, o.jsx)("h1", {
              style: {
                color: c,
                textShadow: "0 0 10px #ff6600"
              },
              className: "jsx-bfd3ab80909036c6 text-2xl sm:text-3xl font-bold text-center tracking-wider mb-3 font-mono",
              children: "ONLINE ARENA"
            }), (0, o.jsxs)("div", {
              style: {
                backgroundColor: "rgba(255,215,0,0.05)",
                border: "1px solid rgba(255,215,0,0.2)"
              },
              className: "jsx-bfd3ab80909036c6 text-center mb-4 p-3 rounded-lg",
              children: [(0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex items-center justify-center gap-2 mb-1",
                children: [ei(r.avatar, m, 36), (0, o.jsxs)("div", {
                  className: "jsx-bfd3ab80909036c6 text-left",
                  children: [(0, o.jsxs)("div", {
                    className: "jsx-bfd3ab80909036c6 flex items-center gap-1.5",
                    children: [(0, o.jsx)("span", {
                      className: "jsx-bfd3ab80909036c6 text-lg",
                      children: Y.icon
                    }), (0, o.jsx)("span", {
                      style: {
                        color: m,
                        textShadow: "0 0 5px #ffd700"
                      },
                      className: "jsx-bfd3ab80909036c6 font-mono font-bold text-base",
                      children: Y.rank
                    })]
                  }), (0, o.jsxs)("span", {
                    style: {
                      color: "#aaa"
                    },
                    className: "jsx-bfd3ab80909036c6 font-mono text-sm",
                    children: ["ELO: ", (0, o.jsx)("span", {
                      style: {
                        color: m
                      },
                      className: "jsx-bfd3ab80909036c6",
                      children: r.rankingData.elo
                    })]
                  })]
                })]
              }), (0, o.jsxs)("div", {
                style: {
                  color: "#666"
                },
                className: "jsx-bfd3ab80909036c6 font-mono text-xs mt-1",
                children: [(0, o.jsxs)("span", {
                  style: {
                    color: s
                  },
                  className: "jsx-bfd3ab80909036c6",
                  children: ["W: ", r.rankingData.wins]
                }), (0, o.jsx)("span", {
                  className: "jsx-bfd3ab80909036c6 mx-2",
                  children: "|"
                }), (0, o.jsxs)("span", {
                  style: {
                    color: f
                  },
                  className: "jsx-bfd3ab80909036c6",
                  children: ["L: ", r.rankingData.losses]
                }), 0 !== R && (0, o.jsx)("span", {
                  style: {
                    color: R > 0 ? s : f
                  },
                  className: "jsx-bfd3ab80909036c6 ml-2",
                  children: R > 0 ? `🔥${R}` : `💀${Math.abs(R)}`
                })]
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-bfd3ab80909036c6 flex flex-col gap-2.5",
              children: [(0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), X()
                },
                style: {
                  borderColor: c,
                  color: c,
                  textShadow: "0 0 10px #ff6600"
                },
                className: "jsx-bfd3ab80909036c6 neon-btn w-full py-3 px-6 text-lg font-bold font-mono tracking-wider",
                children: "⚔️ FIND MATCH"
              }), (0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 grid grid-cols-2 gap-2",
                children: [(0, o.jsx)("button", {
                  onClick: () => {
                    eo.init(), eo.playMenuClick(), S(Math.random().toString(36)
                      .substring(2, 8).toUpperCase()), X()
                  },
                  style: {
                    borderColor: n,
                    color: n,
                    textShadow: "0 0 10px #00ffff"
                  },
                  className: "jsx-bfd3ab80909036c6 neon-btn py-2 px-3 text-xs sm:text-sm font-bold font-mono tracking-wider",
                  children: "🏠 CREATE ROOM"
                }), (0, o.jsx)("button", {
                  onClick: () => {
                    eo.init(), eo.playMenuClick(), N(!j)
                  },
                  style: {
                    borderColor: h,
                    color: h,
                    textShadow: "0 0 10px #aa00ff"
                  },
                  className: "jsx-bfd3ab80909036c6 neon-btn py-2 px-3 text-xs sm:text-sm font-bold font-mono tracking-wider",
                  children: "🔗 JOIN ROOM"
                })]
              }), C && (0, o.jsxs)("div", {
                style: {
                  color: m,
                  backgroundColor: "rgba(255,215,0,0.05)",
                  border: "1px solid rgba(255,215,0,0.2)"
                },
                className: "jsx-bfd3ab80909036c6 text-center font-mono text-sm p-2 rounded",
                children: ["Room Code: ", (0, o.jsx)("span", {
                  className: "jsx-bfd3ab80909036c6 font-bold text-lg tracking-widest",
                  children: C
                }), (0, o.jsx)("div", {
                  style: {
                    color: "#666"
                  },
                  className: "jsx-bfd3ab80909036c6 text-[9px]",
                  children: "Share this code with your friend"
                })]
              }), j && (0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex gap-2",
                children: [(0, o.jsx)("input", {
                  type: "text",
                  value: T,
                  onChange: e => M(e.target.value.toUpperCase().slice(0, 6)),
                  placeholder: "ROOM CODE",
                  maxLength: 6,
                  style: {
                    backgroundColor: "rgba(170,0,255,0.1)",
                    border: "1px solid #aa00ff",
                    color: "#fff",
                    outline: "none"
                  },
                  onKeyDown: e => e.stopPropagation(),
                  className: "jsx-bfd3ab80909036c6 flex-1 px-3 py-2 font-mono text-sm rounded"
                }), (0, o.jsx)("button", {
                  onClick: () => {
                    eo.init(), eo.playMenuClick(), T.length >= 4 && X()
                  },
                  disabled: T.length < 4,
                  style: {
                    backgroundColor: T.length >= 4 ? "rgba(170,0,255,0.2)" :
                      "rgba(0,0,0,0.3)",
                    border: `1px solid ${T.length>=4?h:"#444"}`,
                    color: T.length >= 4 ? h : "#555"
                  },
                  className: "jsx-bfd3ab80909036c6 px-4 py-2 font-mono text-sm font-bold rounded",
                  children: "JOIN"
                })]
              }), (0, o.jsx)("button", {
                onClick: Q,
                style: {
                  borderColor: "#666",
                  color: "#888"
                },
                className: "jsx-bfd3ab80909036c6 neon-btn w-full py-2 px-4 text-sm tracking-wider",
                children: "BACK"
              })]
            })]
          })
        }), "searching" === g && (0, o.jsx)("div", {
          className: "jsx-bfd3ab80909036c6 absolute inset-0 flex items-center justify-center pointer-events-auto",
          children: (0, o.jsxs)("div", {
            className: "jsx-bfd3ab80909036c6 text-center",
            children: [(0, o.jsxs)("div", {
              className: "jsx-bfd3ab80909036c6 relative w-32 h-32 mx-auto mb-4",
              children: [(0, o.jsx)("div", {
                style: {
                  border: `2px solid ${c}40`,
                  animation: "search-pulse 1.5s ease-out infinite"
                },
                className: "jsx-bfd3ab80909036c6 absolute inset-0 rounded-full"
              }), (0, o.jsx)("div", {
                style: {
                  border: `2px solid ${c}60`,
                  animation: "search-pulse 1.5s ease-out infinite 0.3s"
                },
                className: "jsx-bfd3ab80909036c6 absolute inset-4 rounded-full"
              }), (0, o.jsx)("div", {
                style: {
                  border: `2px solid ${c}80`,
                  animation: "search-pulse 1.5s ease-out infinite 0.6s"
                },
                className: "jsx-bfd3ab80909036c6 absolute inset-8 rounded-full"
              }), (0, o.jsx)("div", {
                className: "jsx-bfd3ab80909036c6 absolute inset-0 flex items-center justify-center",
                children: (0, o.jsx)("span", {
                  style: {
                    animation: "search-spin 2s linear infinite"
                  },
                  className: "jsx-bfd3ab80909036c6 text-3xl",
                  children: "⚔️"
                })
              })]
            }), (0, o.jsx)("div", {
              style: {
                color: c,
                textShadow: "0 0 15px #ff6600"
              },
              className: "jsx-bfd3ab80909036c6 text-xl sm:text-2xl font-bold font-mono mb-3",
              children: "FINDING OPPONENT..."
            }), b > 0 && (0, o.jsxs)("div", {
              style: {
                color: "#555"
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-xs mb-2",
              children: ["Scanning: ", tb[b % tb.length]]
            }), (0, o.jsx)("div", {
              style: {
                backgroundColor: "#222"
              },
              className: "jsx-bfd3ab80909036c6 w-48 h-2 rounded-full mx-auto overflow-hidden",
              children: (0, o.jsx)("div", {
                style: {
                  width: `${b/3*100}%`,
                  backgroundColor: c,
                  boxShadow: "0 0 10px #ff6600"
                },
                className: "jsx-bfd3ab80909036c6 h-full rounded-full transition-all"
              })
            }), (0, o.jsxs)("div", {
              style: {
                color: "#666"
              },
              className: "jsx-bfd3ab80909036c6 text-xs font-mono mt-2",
              children: [b, "/3"]
            })]
          })
        }), "matched" === g && P && (0, o.jsx)("div", {
          className: "jsx-bfd3ab80909036c6 absolute inset-0 flex items-center justify-center pointer-events-auto",
          children: (0, o.jsxs)("div", {
            style: {
              backgroundColor: "rgba(5,5,20,0.95)",
              border: "2px solid #ff6600",
              boxShadow: "0 0 40px #ff660030"
            },
            className: "jsx-bfd3ab80909036c6 text-center p-6 rounded-lg mx-4 w-full max-w-sm",
            children: [(0, o.jsx)("div", {
              style: {
                color: c,
                textShadow: "0 0 10px #ff6600"
              },
              className: "jsx-bfd3ab80909036c6 text-lg font-bold font-mono mb-4",
              children: "OPPONENT FOUND!"
            }), (0, o.jsxs)("div", {
              className: "jsx-bfd3ab80909036c6 flex items-center justify-center gap-4 mb-4",
              children: [(0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex flex-col items-center",
                children: [ei(r.avatar, n, 56), (0, o.jsx)("div", {
                  style: {
                    color: n
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono font-bold text-sm mt-1.5",
                  children: r.username
                }), (0, o.jsxs)("div", {
                  style: {
                    color: m
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono text-xs",
                  children: [Y.icon, " ", Y.rank]
                }), (0, o.jsxs)("div", {
                  style: {
                    color: "#888"
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono text-xs",
                  children: ["ELO ", r.rankingData.elo]
                })]
              }), (0, o.jsx)("div", {
                style: {
                  color: c,
                  textShadow: "0 0 20px #ff6600"
                },
                className: "jsx-bfd3ab80909036c6 text-2xl font-bold font-mono",
                children: "VS"
              }), (0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex flex-col items-center",
                children: [ei(P.avatar, f, 56), (0, o.jsx)("div", {
                  style: {
                    color: f
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono font-bold text-sm mt-1.5",
                  children: P.name
                }), (0, o.jsxs)("div", {
                  style: {
                    color: m
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono text-xs",
                  children: [P.rankIcon, " ", P.rank]
                }), (0, o.jsxs)("div", {
                  style: {
                    color: "#888"
                  },
                  className: "jsx-bfd3ab80909036c6 font-mono text-xs",
                  children: ["ELO ", P.elo]
                })]
              })]
            }), (0, o.jsx)("div", {
              style: {
                color: s,
                textShadow: "0 0 8px #00ff66"
              },
              className: "jsx-bfd3ab80909036c6 text-xs font-mono animate-pulse",
              children: "MATCH STARTING..."
            })]
          })
        }), "result" === g && w && P && (0, o.jsx)("div", {
          className: "jsx-bfd3ab80909036c6 absolute inset-0 flex items-center justify-center pointer-events-auto",
          children: (0, o.jsxs)("div", {
            className: "jsx-bfd3ab80909036c6 text-center w-full max-w-sm mx-4",
            children: [(0, o.jsxs)("div", {
              className: "jsx-bfd3ab80909036c6 flex items-center justify-center gap-4 mb-3",
              children: [(0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex flex-col items-center",
                children: [ei(r.avatar, "win" === w ? m : "#555", "win" === w ? 64 : 44),
                  "win" === w && (0, o.jsx)("div", {
                    style: {
                      backgroundColor: "rgba(255,215,0,0.2)",
                      color: m
                    },
                    className: "jsx-bfd3ab80909036c6 font-mono text-[10px] mt-1 px-2 py-0.5 rounded",
                    children: "WINNER"
                  }), (0, o.jsx)("div", {
                    style: {
                      color: "win" === w ? n : "#666"
                    },
                    className: "jsx-bfd3ab80909036c6 font-mono font-bold text-xs mt-1",
                    children: r.username
                  })
                ]
              }), (0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex flex-col items-center",
                children: [ei(P.avatar, "loss" === w ? m : "#555", "loss" === w ? 64 :
                  44), "loss" === w && (0, o.jsx)("div", {
                    style: {
                      backgroundColor: "rgba(255,215,0,0.2)",
                      color: m
                    },
                    className: "jsx-bfd3ab80909036c6 font-mono text-[10px] mt-1 px-2 py-0.5 rounded",
                    children: "WINNER"
                  }), (0, o.jsx)("div", {
                    style: {
                      color: "loss" === w ? f : "#666"
                    },
                    className: "jsx-bfd3ab80909036c6 font-mono font-bold text-xs mt-1",
                    children: P.name
                  })
                ]
              })]
            }), (0, o.jsx)("h1", {
              style: {
                color: "win" === w ? s : f,
                textShadow: "win" === w ? "0 0 20px #00ff66, 0 0 40px #00ff66" :
                  "0 0 20px #ff3333, 0 0 40px #ff3333"
              },
              className: "jsx-bfd3ab80909036c6 text-4xl sm:text-6xl font-bold tracking-wider mb-2",
              children: "win" === w ? "VICTORY" : "DEFEATED"
            }), (0, o.jsxs)("div", {
              style: {
                color: "win" === w ? s : f,
                backgroundColor: "win" === w ? "rgba(0,255,102,0.1)" : "rgba(255,51,51,0.1)",
                border: `1px solid ${"win"===w?s:f}30`
              },
              className: "jsx-bfd3ab80909036c6 inline-block font-mono text-sm mb-1 px-3 py-1 rounded",
              children: ["win" === w ? "+" : "", "win" === w ? 25 : "loss" === w ? -15 : 0,
                " ELO"
              ]
            }), (0, o.jsxs)("div", {
              style: {
                color: "#888"
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-lg mb-1",
              children: ["ELO: ", (0, o.jsx)("span", {
                style: {
                  color: m
                },
                className: "jsx-bfd3ab80909036c6",
                children: r.rankingData.elo
              })]
            }), (0, o.jsxs)("div", {
              style: {
                color: "#555"
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-xs mb-2",
              children: ["vs ", P.rankIcon, " ", P.name, " (ELO ", P.elo, ")"]
            }), Math.abs(R) > 1 && (0, o.jsx)("div", {
              style: {
                color: R > 0 ? s : f
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-sm mb-3",
              children: R > 0 ? `🔥 ${R} WIN STREAK!` : `💀 ${Math.abs(R)} losses in a row`
            }), el && (0, o.jsxs)("div", {
              style: {
                color: c,
                textShadow: "0 0 8px #ff6600"
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-sm mb-3",
              children: ["Waiting for ", P.name, "..."]
            }), ee && (0, o.jsxs)("div", {
              style: {
                color: f,
                textShadow: "0 0 8px #ff3333"
              },
              className: "jsx-bfd3ab80909036c6 font-mono text-sm mb-3",
              children: [P.name, " declined rematch. Finding new opponent..."]
            }), !el && !ee && (0, o.jsxs)("div", {
              className: "jsx-bfd3ab80909036c6 flex flex-col gap-2.5 items-center",
              children: [(0, o.jsx)("button", {
                onClick: () => {
                  eo.init(), eo.playMenuClick(), X()
                },
                style: {
                  border: "2px solid #00ff66",
                  color: "#00ff66",
                  textShadow: "0 0 15px #00ff66, 0 0 30px #00ff66",
                  backgroundColor: "rgba(0,255,102,0.1)",
                  boxShadow: "0 0 20px rgba(0,255,102,0.3), inset 0 0 20px rgba(0,255,102,0.05)",
                  borderRadius: "4px",
                  cursor: "pointer",
                  transition: "all 0.2s"
                },
                className: "jsx-bfd3ab80909036c6 w-56 py-3 px-6 text-lg font-bold font-mono tracking-wider",
                children: "NEW GAME ▶"
              }), (0, o.jsxs)("div", {
                className: "jsx-bfd3ab80909036c6 flex flex-col items-center",
                children: [(0, o.jsx)("button", {
                  onClick: () => {
                    eo.init(), eo.playMenuClick(), er(!0), setTimeout(() => {
                      er(!1), .65 > Math.random() ? (et(!0), setTimeout(
                    () => {
                        et(!1), X()
                      }, 2e3)) : (y("playing"), D.current = "playing", Z())
                    }, 1500)
                  },
                  style: {
                    borderColor: c,
                    color: c,
                    textShadow: "0 0 8px #ff6600"
                  },
                  className: "jsx-bfd3ab80909036c6 neon-btn w-48 py-2 px-6 text-base font-bold font-mono tracking-wider",
                  children: "REMATCH"
                }), (0, o.jsx)("span", {
                  style: {
                    color: "#666"
                  },
                  className: "jsx-bfd3ab80909036c6 text-[10px] font-mono mt-1",
                  children: "(Same opponent — may decline)"
                })]
              }), (0, o.jsx)("button", {
                onClick: Q,
                style: {
                  borderColor: "#666",
                  color: "#888"
                },
                className: "jsx-bfd3ab80909036c6 neon-btn w-48 py-2 px-6 text-base font-bold font-mono tracking-wider",
                children: "MAIN MENU"
              })]
            })]
          })
        }), (0, o.jsx)(e9.default, {
          id: "bfd3ab80909036c6",
          children: "@keyframes search-pulse{0%{opacity:1;transform:scale(.5)}to{opacity:0;transform:scale(1.5)}}@keyframes search-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}"
        })]
      })
    }

    function tC(e, t, o, a, l, r, n, i, c, d = !1, h = !1) {
      if (e.save(), e.translate(t, o), h && (e.globalAlpha = .5 + .3 * Math.sin(.3 * r)), e.shadowBlur = 12, e
        .shadowColor = l, e.strokeStyle = l, e.lineWidth = 2, d && (e.globalAlpha = .2, e.fillStyle = s, e
          .beginPath(), e.arc(0, -20, 25, 0, 2 * Math.PI), e.fill(), e.globalAlpha = .8, e.strokeStyle = s, e
          .lineWidth = 1.5, e.beginPath(), e.arc(0, -20, 25, 0, 2 * Math.PI), e.stroke(), e.strokeStyle = l, e
          .lineWidth = 2), e.beginPath(), e.arc(0, -38, 8, 0, 2 * Math.PI), e.stroke(), e.beginPath(), e.moveTo(0, -
          30), e.lineTo(0, -10), e.stroke(), n) e.beginPath(), e.moveTo(0, -25), e.lineTo(22 * a, -25), e.stroke(),
        e.fillStyle = "#ffffff", e.beginPath(), e.arc(25 * a, -25, 3, 0, 2 * Math.PI), e.fill();
      else {
        let t = c ? 10 * Math.sin(.3 * r) : 0;
        e.beginPath(), e.moveTo(0, -25), e.lineTo(-10, -20 + t), e.stroke(), e.beginPath(), e.moveTo(0, -25), e
          .lineTo(10, -20 - t), e.stroke()
      }
      if (c) {
        let t = 12 * Math.sin(.3 * r);
        e.beginPath(), e.moveTo(0, -10), e.lineTo(-7 + .3 * t, 0 + t), e.stroke(), e.beginPath(), e.moveTo(0, -10),
          e.lineTo(7 - .3 * t, 0 - t), e.stroke()
      } else e.beginPath(), e.moveTo(0, -10), e.lineTo(-8, 0), e.stroke(), e.beginPath(), e.moveTo(0, -10), e
        .lineTo(8, 0), e.stroke();
      e.shadowBlur = 0, e.globalAlpha = 1, e.restore()
    }

    function tS() {
      let e = (0, a.useRef)(null),
        t = (0, a.useRef)(0),
        l = (0, a.useRef)(0),
        r = (0, a.useRef)(0),
        s = (0, a.useRef)({
          titleAppear: !1,
          subtitleAppear: !1,
          tapReady: !1
        }),
        c = (0, a.useRef)([]),
        d = (0, a.useRef)([]);
      return (0, a.useEffect)(() => {
        let o = e.current;
        if (!o) return;
        let a = o.getContext("2d");
        l.current = performance.now();
        let h = () => {
          o.width = window.innerWidth, o.height = window.innerHeight
        };
        h(), window.addEventListener("resize", h);
        let f = (e, t, o, a, l) => {
            let r = [{
                x: e,
                y: t
              }],
              n = 8 + Math.floor(6 * Math.random()),
              i = (o - e) / n,
              s = (a - t) / n;
            for (let o = 1; o < n; o++) r.push({
              x: e + i * o + (Math.random() - .5) * 40,
              y: t + s * o + (Math.random() - .5) * 40
            });
            return r.push({
              x: o,
              y: a
            }), {
              points: r,
              life: 12,
              maxLife: 12,
              color: l
            }
          },
          m = (e, t, o, a, l = 3) => {
            for (let r = 0; r < o; r++) c.current.push({
              x: e,
              y: t,
              vx: (Math.random() - .5) * l,
              vy: (Math.random() - .5) * l - 1,
              life: 30 + 40 * Math.random(),
              maxLife: 70,
              color: a,
              size: 1 + 3 * Math.random()
            })
          },
          x = () => {
            t.current = requestAnimationFrame(x), r.current++;
            let e = o.width,
              h = o.height,
              p = (performance.now() - l.current) / 1e3;
            a.fillStyle = u, a.fillRect(0, 0, e, h), a.globalAlpha = .03 + .015 * Math.sin(2 * p), a
              .strokeStyle = n, a.lineWidth = 1;
            let g = .3 * r.current % 80;
            for (let t = g; t < e; t += 80) a.beginPath(), a.moveTo(t, 0), a.lineTo(t, h), a.stroke();
            for (let t = 0; t < h; t += 80) a.beginPath(), a.moveTo(0, t), a.lineTo(e, t), a.stroke();
            a.globalAlpha = 1;
            let y = Math.min(.15, .05 * p),
              b = a.createLinearGradient(0, .55 * h, e, .55 * h);
            if (b.addColorStop(0, "transparent"), b.addColorStop(.3, `rgba(0, 255, 255, ${y})`), b.addColorStop(
                .7, `rgba(0, 255, 255, ${y})`), b.addColorStop(1, "transparent"), a.fillStyle = b, a.fillRect(0,
                .54 * h, e, .04 * h), p < 1) {
              let t = 1 - Math.pow(1 - Math.min(p / .8, 1), 3),
                o = -50 + (.5 * e - -50) * t,
                l = .55 * h,
                i = r.current,
                s = Math.min(12, Math.floor(15 * t));
              for (let e = 1; e <= s; e++) {
                let t = o - 8 * e,
                  r = .4 - .03 * e;
                r <= 0 || (a.globalAlpha = r, a.strokeStyle = n, a.lineWidth = 2, a.beginPath(), a.arc(t, l -
                  28 + 2 * Math.sin(.1 * i + e), 7, 0, 2 * Math.PI), a.stroke(), a.beginPath(), a.moveTo(t,
                  l - 21), a.lineTo(t, l - 5), a.stroke())
              }
              a.globalAlpha = 1, a.save(), a.shadowBlur = 15, a.shadowColor = n, a.strokeStyle = n, a
                .lineWidth = 2.5, a.beginPath(), a.arc(o, l - 38, 9, 0, 2 * Math.PI), a.stroke(), a.fillStyle =
                "#ffffff", a.beginPath(), a.arc(o + 3, l - 39, 2, 0, 2 * Math.PI), a.fill(), a.strokeStyle = n,
                a.beginPath(), a.moveTo(o, l - 29), a.lineTo(o, l - 10), a.stroke();
              let c = 12 * Math.sin(.35 * i);
              a.beginPath(), a.moveTo(o, l - 25), a.lineTo(o - 12, l - 18 + c), a.stroke(), a.beginPath(), a
                .moveTo(o, l - 25), a.lineTo(o + 12, l - 18 - c), a.stroke();
              let d = 14 * Math.sin(.35 * i);
              a.beginPath(), a.moveTo(o, l - 10), a.lineTo(o - 8 + .3 * d, l + d), a.stroke(), a.beginPath(), a
                .moveTo(o, l - 10), a.lineTo(o + 8 - .3 * d, l - d), a.stroke(), a.shadowBlur = 0, a.restore()
            }
            if (p >= 1) {
              let t = "NEON STICKMAN",
                o = Math.min(t.length, Math.floor((p - 1) / (1 / t.length) * 1.2)),
                l = t.slice(0, o);
              !s.current.titleAppear && o > 0 && (s.current.titleAppear = !0, eo.init(), eo
              .playDramaticMoment());
              let r = .32 * h,
                i = Math.min(.08 * e, 56);
              if (a.save(), a.font = `bold ${i}px monospace`, a.textAlign = "center", a.textBaseline = "middle",
                a.shadowBlur = 30, a.shadowColor = n, a.fillStyle = n, a.fillText(l, e / 2, r), a.shadowBlur =
                10, a.shadowColor = "#00ffff", a.fillText(l, e / 2, r), a.shadowBlur = 0, a.fillStyle =
                "#ffffff", a.globalAlpha = .7, a.fillText(l, e / 2, r), a.globalAlpha = 1, a.restore(), p >=
                1.3 && .06 > Math.random()) {
                let o = Math.random() > .5 ? 1 : -1,
                  l = a.measureText ? t.length * i * .6 : .5 * e,
                  s = e / 2 + o * (.4 * l + 60 * Math.random());
                d.current.push(f(s, r - .6 * i, s + (Math.random() - .5) * 80, r + .6 * i, n))
              }
            }
            if (p >= 2) {
              let t = "STICK WAR",
                o = Math.min((p - 2) / .6, 1),
                l = 1 - Math.pow(1 - o, 3),
                r = .42 * h + (1 - l) * 40,
                n = Math.min(.06 * e, 40);
              !s.current.subtitleAppear && o > 0 && (s.current.subtitleAppear = !0, eo.init(), eo
                  .playReinforcement()), a.save(), a.globalAlpha = l, a.font = `bold ${n}px monospace`, a
                .textAlign = "center", a.textBaseline = "middle", a.shadowBlur = 25, a.shadowColor = i, a
                .fillStyle = i, a.fillText(t, e / 2, r), a.shadowBlur = 8, a.shadowColor = "#ff00ff", a
                .fillText(t, e / 2, r), a.shadowBlur = 0, a.fillStyle = "#ffffff", a.globalAlpha = .6 * l, a
                .fillText(t, e / 2, r), a.globalAlpha = 1, a.restore()
            }
            if (p >= 1) {
              let t = .5 * e,
                o = .55 * h,
                l = r.current;
              a.save(), a.shadowBlur = 15, a.shadowColor = n, a.strokeStyle = n, a.lineWidth = 2.5;
              let i = 2 * Math.sin(.08 * l),
                s = Math.sin(.02 * l) > 0 ? 1 : -1;
              a.beginPath(), a.arc(t + 2 * s, o - 38 + i, 9, 0, 2 * Math.PI), a.stroke(), a.fillStyle =
                "#ffffff", a.beginPath(), a.arc(t + 5 * s, o - 39 + i, 2, 0, 2 * Math.PI), a.fill(), a
                .strokeStyle = n, a.beginPath(), a.moveTo(t + +s, o - 29 + i), a.lineTo(t - 2 * s, o - 10 + i),
                a.stroke();
              let c = 3 * Math.sin(.06 * l);
              a.beginPath(), a.moveTo(t, o - 25 + i), a.lineTo(t - 14, o - 30 + i + c), a.stroke(), a
                .beginPath(), a.moveTo(t, o - 25 + i), a.lineTo(t + 12, o - 20 + i - c), a.stroke(), a
                .fillStyle = n, a.beginPath(), a.arc(t + 12, o - 20 + i - c, 3, 0, 2 * Math.PI), a.fill(), a
                .strokeStyle = n;
              let d = 1.5 * Math.sin(.1 * l);
              a.beginPath(), a.moveTo(t - 2 * s, o - 10 + i), a.lineTo(t - 12, o + d + i), a.stroke(), a
                .beginPath(), a.moveTo(t - 2 * s, o - 10 + i), a.lineTo(t + 12, o - d + i), a.stroke(), a
                .shadowBlur = 0, a.restore(), p - 1 > .5 && .08 > Math.random() && m(t + (Math.random() - .5) *
                  30, o - 20, 1, n, 1)
            }
            p >= 1.2 && .12 > Math.random() && m(.3 * e + Math.random() * e * .4, .25 * h + Math.random() * h *
              .2, 1, [n, i, "#00ff88", "#8844ff"][Math.floor(4 * Math.random())], .8);
            let v = [];
            for (let e of c.current)
              if (e.x += e.vx, e.y += e.vy, e.vy += .02, e.life--, e.life > 0) {
                let t = e.life / e.maxLife;
                a.globalAlpha = .6 * t, a.fillStyle = e.color, a.beginPath(), a.arc(e.x, e.y, e.size * t, 0, 2 *
                  Math.PI), a.fill(), v.push(e)
              } c.current = v, a.globalAlpha = 1;
            let w = [];
            for (let e of d.current)
              if (e.life--, e.life > 0) {
                let t = e.life / e.maxLife;
                a.globalAlpha = .8 * t, a.strokeStyle = e.color, a.lineWidth = 2, a.shadowBlur = 15, a
                  .shadowColor = e.color, a.beginPath(), a.moveTo(e.points[0].x, e.points[0].y);
                for (let t = 1; t < e.points.length; t++) a.lineTo(e.points[t].x, e.points[t].y);
                a.stroke(), a.lineWidth = 1, a.strokeStyle = "#ffffff", a.globalAlpha = .5 * t, a.beginPath(), a
                  .moveTo(e.points[0].x, e.points[0].y);
                for (let t = 1; t < e.points.length; t++) a.lineTo(e.points[t].x, e.points[t].y);
                a.stroke(), a.shadowBlur = 0, w.push(e)
              } if (d.current = w, a.globalAlpha = 1, p >= 3 && p < 4.5) {
              let t = Math.min((p - 3) / 1.2, 1),
                o = Math.min(.6 * e, 400),
                l = (e - o) / 2,
                r = .62 * h;
              a.fillStyle = "#ffffff10", a.fillRect(l, r, o, 8);
              let i = a.createLinearGradient(l, r, l + o * t, r);
              i.addColorStop(0, n), i.addColorStop(1, "#00aaff"), a.fillStyle = i, a.shadowBlur = 10, a
                .shadowColor = n, a.fillRect(l, r, o * t, 8), a.shadowBlur = 0;
              let s = ".".repeat(Math.floor(3 * p) % 4);
              a.font = "14px monospace", a.textAlign = "center", a.fillStyle = "#00ffff88", a.fillText(
                `LOADING${s}`, e / 2, r + 28), a.fillStyle = n, a.font = "bold 14px monospace", a.fillText(
                `${Math.floor(100*t)}%`, e / 2, r - 10)
            }
            if (p >= 4.5) {
              let t = .6 + .35 * Math.sin(4 * p),
                o = Math.min(.05 * e, 28);
              a.save();
              let l = "TAP TO START";
              a.font = `bold ${o}px monospace`, a.textAlign = "center", a.textBaseline = "middle";
              let r = a.measureText(l).width,
                c = .72 * h,
                u = (e - r) / 2 - 16,
                m = c - o / 2 - 8,
                x = r + 32,
                g = o + 16;
              a.globalAlpha = .12 * t, a.fillStyle = n, a.beginPath();
              let y = g / 2;
              if (a.moveTo(u + y, m), a.lineTo(u + x - y, m), a.quadraticCurveTo(u + x, m, u + x, m + y), a
                .lineTo(u + x, m + g - y), a.quadraticCurveTo(u + x, m + g, u + x - y, m + g), a.lineTo(u + y,
                  m + g), a.quadraticCurveTo(u, m + g, u, m + g - y), a.lineTo(u, m + y), a.quadraticCurveTo(u,
                  m, u + y, m), a.closePath(), a.fill(), a.globalAlpha = .3 * t, a.strokeStyle = n, a
                .lineWidth = 1.5, a.stroke(), a.globalAlpha = t, a.shadowBlur = 20, a.shadowColor = n, a
                .fillStyle = "#ffffff", a.fillText(l, e / 2, c), a.shadowBlur = 0, a.restore(), s.current
                .tapReady || (s.current.tapReady = !0, eo.init(), eo.playAbilityReady()), .03 > Math.random()) {
                let t = Math.random() > .5 ? 1 : -1;
                d.current.push(f(e / 2 + .3 * e * t, .15 * h, e / 2 + .25 * e * t + (Math.random() - .5) * 100,
                  .5 * h, t > 0 ? n : i))
              }
            }
            if (p >= 1) {
              a.globalAlpha = .1 + .05 * Math.sin(3 * p), a.fillStyle = n;
              for (let t = 0; t < 6; t++) {
                let o = 20 + 15 * t;
                a.beginPath(), a.arc(o, 20, 2, 0, 2 * Math.PI), a.fill(), a.beginPath(), a.arc(e - o, h - 20, 2,
                  0, 2 * Math.PI), a.fill()
              }
              a.fillStyle = i;
              for (let t = 0; t < 6; t++) {
                let o = 25 + 15 * t;
                a.beginPath(), a.arc(o, h - 25, 2, 0, 2 * Math.PI), a.fill(), a.beginPath(), a.arc(e - o, 20, 2,
                  0, 2 * Math.PI), a.fill()
              }
              a.globalAlpha = 1
            }
            p >= 2 && (a.globalAlpha = .2, a.font = "10px monospace", a.textAlign = "right", a.fillStyle = n, a
              .fillText("v1.0", e - 15, h - 15), a.globalAlpha = 1)
          };
        return x(), () => {
          cancelAnimationFrame(t.current), window.removeEventListener("resize", h)
        }
      }, []), (0, o.jsx)("div", {
        className: "absolute inset-0 z-50 flex flex-col items-center justify-center cursor-pointer",
        style: {
          backgroundColor: u,
          touchAction: "manipulation"
        },
        onClick: () => {
          let e = new CustomEvent("splash-end");
          window.dispatchEvent(e)
        },
        onTouchEnd: e => {
          e.preventDefault();
          let t = new CustomEvent("splash-end");
          window.dispatchEvent(t)
        },
        children: (0, o.jsx)("canvas", {
          ref: e,
          className: "absolute inset-0 w-full h-full",
          style: {
            touchAction: "none"
          }
        })
      })
    }
    let tT = ["⚔️", "🗡️", "🔥", "⚡", "💀", "👑", "🎮", "🕹️", "🌟", "💎", "🦊", "🐺", "🐉", "🔮", "🎯", "🛡️"],
      tM = ["United States", "United Kingdom", "Canada", "Australia", "Germany", "France", "Japan", "South Korea",
        "Brazil", "India", "Mexico", "Russia", "China", "Italy", "Spain", "Netherlands", "Sweden", "Poland",
        "Turkey", "Other"
      ];

    function tj(e) {
      return e.startsWith("data:")
    }

    function tN() {
      let e = ea(e => e.saveData),
        t = ea(e => e.updateProfile),
        l = ea(e => e.setGamePhase);
      ea(e => e.loadGame);
      let r = ea(e => e.loadCloudSave),
        [i, d] = (0, a.useState)(e.username),
        [f, u] = (0, a.useState)(e.avatar),
        [x, p] = (0, a.useState)(e.about),
        [g, y] = (0, a.useState)(e.nationality),
        [b, v] = (0, a.useState)(!1),
        [w, k] = (0, a.useState)({
          user: null,
          loading: !0,
          error: null,
          isAnonymous: !1
        }),
        [C, S] = (0, a.useState)("idle"),
        [T, M] = (0, a.useState)(!1),
        j = (0, a.useRef)(null);
      (0, a.useEffect)(() => es(e => {
        k(e)
      }), []);
      let N = O(e.rankingData.elo),
        P = ex(),
        A = W.reduce((t, o, a) => e.rankingData.elo >= o.min ? a : t, 0),
        R = A < W.length - 1 ? W[A + 1] : null,
        I = R ? Math.round((e.rankingData.elo - W[A].min) / (R.min - W[A].min) * 100) : 100,
        E = (0, a.useCallback)(e => {
          e.stopPropagation()
        }, []),
        L = (0, a.useCallback)(async () => {
          eo.init(), eo.playMenuClick();
          let o = await eh();
          o && "NeonWarrior" === e.username && (t({
            username: `Player${o.uid.slice(0,6)}`
          }), d(`Player${o.uid.slice(0,6)}`))
        }, [e.username, t]),
        D = (0, a.useCallback)(async () => {
          eo.init(), eo.playMenuClick();
          let e = await ef();
          e && e.displayName && (t({
            username: e.displayName.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 15) || "NeonWarrior"
          }), d(e.displayName.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 15) || "NeonWarrior"))
        }, [t]),
        B = (0, a.useCallback)(async () => {
          eo.init(), eo.playMenuClick(), await em()
        }, []),
        G = (0, a.useCallback)(async () => {
          if (!w.user) return;
          S("uploading"), eo.init(), eo.playMenuClick();
          let t = await (0, ep.uploadSaveToCloud)(e);
          S(t ? "done" : "error"), t ? setTimeout(() => S("idle"), 2e3) : setTimeout(() => S("idle"), 3e3)
        }, [w.user, e]),
        $ = (0, a.useCallback)(async () => {
          if (!w.user) return;
          S("downloading"), eo.init(), eo.playMenuClick();
          let e = await (0, ep.downloadSaveFromCloud)();
          e ? (r(e), S("done")) : S("error"), setTimeout(() => S("idle"), 2e3)
        }, [w.user, r]),
        F = (0, a.useCallback)(async e => {
          let t = e.target.files?.[0];
          if (t && t.type.startsWith("image/")) {
            M(!0);
            try {
              let e = await new Promise((e, o) => {
                let a = new FileReader;
                a.onload = t => {
                  let a = new Image;
                  a.onload = () => {
                    let t = document.createElement("canvas"),
                      {
                        width: l,
                        height: r
                      } = a;
                    if (l > 100 || r > 100) {
                      let e = Math.min(100 / l, 100 / r);
                      l = Math.round(l * e), r = Math.round(r * e)
                    }
                    t.width = l, t.height = r;
                    let n = t.getContext("2d");
                    if (!n) return void o(Error("Canvas not supported"));
                    n.drawImage(a, 0, 0, l, r);
                    let i = .7,
                      s = t.toDataURL("image/jpeg", i);
                    for (; s.length > 28057.600000000002 && i > .1;) i -= .1, s = t.toDataURL(
                      "image/jpeg", i);
                    e(s)
                  }, a.onerror = () => o(Error("Failed to load image")), a.src = t.target?.result
                }, a.onerror = () => o(Error("Failed to read file")), a.readAsDataURL(t)
              });
              u(e), eo.init(), eo.playMenuClick()
            } catch (e) {
              console.error("Failed to process image:", e)
            } finally {
              M(!1), j.current && (j.current.value = "")
            }
          }
        }, []),
        H = e.rankingData.wins + e.rankingData.losses > 0 ? Math.round(e.rankingData.wins / (e.rankingData.wins + e
          .rankingData.losses) * 100) : 0,
        U = (e = 36) => tj(f) ? (0, o.jsx)("img", {
          src: f,
          alt: "Profile",
          className: "rounded-full object-cover",
          style: {
            width: e,
            height: e
          }
        }) : (0, o.jsx)("span", {
          style: {
            fontSize: .5 * e
          },
          children: f
        });
      return (0, o.jsx)("div", {
        className: "absolute inset-0 z-20 flex items-center justify-center pointer-events-none",
        children: (0, o.jsxs)("div", {
          className: "w-full max-w-md p-4 rounded-lg mx-4 pointer-events-auto max-h-[90vh] overflow-y-auto",
          style: {
            backgroundColor: "rgba(5,5,20,0.95)",
            border: "2px solid #aa00ff",
            boxShadow: "0 0 30px #aa00ff20",
            WebkitOverflowScrolling: "touch",
            scrollbarWidth: "none"
          },
          onKeyDown: e => e.stopPropagation(),
          children: [(0, o.jsx)("h2", {
            className: "text-xl font-bold text-center tracking-wider mb-3 font-mono",
            style: {
              color: h,
              textShadow: "0 0 10px #aa00ff"
            },
            children: "PROFILE"
          }), (0, o.jsxs)("div", {
            className: "flex items-center gap-3 mb-3 p-3 rounded-lg",
            style: {
              backgroundColor: "rgba(0,0,0,0.3)",
              border: "1px solid #333"
            },
            children: [(0, o.jsx)("div", {
              className: "relative",
              children: (0, o.jsx)("div", {
                className: "rounded-full flex items-center justify-center overflow-hidden",
                style: {
                  width: 64,
                  height: 64,
                  backgroundColor: "rgba(0,255,255,0.1)",
                  border: "2px solid #00ffff40",
                  boxShadow: "0 0 12px #aa00ff40"
                },
                children: U(64)
              })
            }), (0, o.jsxs)("div", {
              className: "flex-1 min-w-0",
              children: [(0, o.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [(0, o.jsx)("span", {
                  className: "text-xl",
                  children: N.icon
                }), (0, o.jsx)("span", {
                  className: "font-mono font-bold text-sm",
                  style: {
                    color: m,
                    textShadow: "0 0 5px #ffd700"
                  },
                  children: N.rank
                })]
              }), (0, o.jsxs)("div", {
                className: "font-mono text-xs mt-0.5",
                style: {
                  color: "#888"
                },
                children: ["ELO: ", (0, o.jsx)("span", {
                  style: {
                    color: n
                  },
                  children: e.rankingData.elo
                }), R && (0, o.jsxs)(o.Fragment, {
                  children: [" ", "→ ", (0, o.jsx)("span", {
                    style: {
                      color: m
                    },
                    children: R.rank
                  }), (0, o.jsx)("div", {
                    className: "w-full h-1.5 rounded-full mt-1",
                    style: {
                      backgroundColor: "rgba(255,255,255,0.1)"
                    },
                    children: (0, o.jsx)("div", {
                      className: "h-full rounded-full transition-all duration-500",
                      style: {
                        width: `${I}%`,
                        backgroundColor: m,
                        boxShadow: "0 0 4px #ffd700"
                      }
                    })
                  })]
                })]
              }), (0, o.jsxs)("div", {
                className: "font-mono text-[10px] mt-1",
                style: {
                  color: "#666"
                },
                children: ["W/R: ", H, "% | ", e.rankingData.wins, "W ", e.rankingData
                  .losses, "L"
                ]
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3 p-2.5 rounded",
            style: {
              backgroundColor: "rgba(0,0,0,0.3)",
              border: "1px solid #222"
            },
            children: [(0, o.jsxs)("div", {
              className: "flex items-center justify-between mb-1",
              children: [(0, o.jsx)("span", {
                className: "font-mono text-[10px]",
                style: {
                  color: "#888"
                },
                children: "LEVEL PROGRESS"
              }), (0, o.jsxs)("span", {
                className: "font-mono text-xs font-bold",
                style: {
                  color: n
                },
                children: ["Zone ", e.highestLevel]
              })]
            }), (0, o.jsx)("div", {
              className: "w-full h-2 rounded-full",
              style: {
                backgroundColor: "rgba(0,255,255,0.1)"
              },
              children: (0, o.jsx)("div", {
                className: "h-full rounded-full transition-all duration-500",
                style: {
                  width: `${Math.min(e.highestLevel/100*100,100)}%`,
                  backgroundColor: n,
                  boxShadow: "0 0 6px #00ffff"
                }
              })
            }), (0, o.jsxs)("div", {
              className: "flex justify-between mt-1",
              children: [(0, o.jsx)("span", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#555"
                },
                children: "Zone 1"
              }), (0, o.jsx)("span", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#555"
                },
                children: "Zone 100+"
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "grid grid-cols-4 gap-1.5 mb-3",
            children: [(0, o.jsxs)("div", {
              className: "text-center p-1.5 rounded",
              style: {
                backgroundColor: "rgba(0,0,0,0.2)",
                border: "1px solid #222"
              },
              children: [(0, o.jsx)("div", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#888"
                },
                children: "Level"
              }), (0, o.jsx)("div", {
                className: "font-mono text-xs font-bold",
                style: {
                  color: n
                },
                children: e.highestLevel
              })]
            }), (0, o.jsxs)("div", {
              className: "text-center p-1.5 rounded",
              style: {
                backgroundColor: "rgba(0,0,0,0.2)",
                border: "1px solid #222"
              },
              children: [(0, o.jsx)("div", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#888"
                },
                children: "Kills"
              }), (0, o.jsx)("div", {
                className: "font-mono text-xs font-bold",
                style: {
                  color: c
                },
                children: e.totalKills
              })]
            }), (0, o.jsxs)("div", {
              className: "text-center p-1.5 rounded",
              style: {
                backgroundColor: "rgba(0,0,0,0.2)",
                border: "1px solid #222"
              },
              children: [(0, o.jsx)("div", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#888"
                },
                children: "Coins"
              }), (0, o.jsx)("div", {
                className: "font-mono text-xs font-bold",
                style: {
                  color: m
                },
                children: e.totalCoins
              })]
            }), (0, o.jsxs)("div", {
              className: "text-center p-1.5 rounded",
              style: {
                backgroundColor: "rgba(0,0,0,0.2)",
                border: "1px solid #222"
              },
              children: [(0, o.jsx)("div", {
                className: "font-mono text-[9px]",
                style: {
                  color: "#888"
                },
                children: "Skills"
              }), (0, o.jsx)("div", {
                className: "font-mono text-xs font-bold",
                style: {
                  color: h
                },
                children: e.unlockedSkills.length
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3 p-3 rounded-lg",
            style: {
              backgroundColor: "rgba(0,0,0,0.3)",
              border: "1px solid #333"
            },
            children: [(0, o.jsx)("div", {
              className: "text-xs font-mono font-bold mb-2",
              style: {
                color: n
              },
              children: "CLOUD SAVE"
            }), w.loading ? (0, o.jsx)("div", {
              className: "text-xs font-mono text-center py-2",
              style: {
                color: "#888"
              },
              children: "Connecting..."
            }) : w.user ? (0, o.jsxs)("div", {
              className: "space-y-2",
              children: [(0, o.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [(0, o.jsx)("div", {
                  className: "w-8 h-8 rounded-full flex items-center justify-center overflow-hidden",
                  style: {
                    backgroundColor: "rgba(0,255,255,0.1)",
                    border: "1px solid #00ffff40"
                  },
                  children: P?.photoURL ? (0, o.jsx)("img", {
                    src: P.photoURL,
                    alt: "avatar",
                    className: "w-8 h-8 rounded-full object-cover"
                  }) : U(32)
                }), (0, o.jsxs)("div", {
                  className: "flex-1 min-w-0",
                  children: [(0, o.jsxs)("div", {
                    className: "flex items-center gap-1.5",
                    children: [(0, o.jsx)("div", {
                      className: "w-2 h-2 rounded-full",
                      style: {
                        backgroundColor: w.isAnonymous ? c : s,
                        boxShadow: `0 0 4px ${w.isAnonymous?c:s}`
                      }
                    }), (0, o.jsx)("span", {
                      className: "font-mono text-xs font-bold truncate",
                      style: {
                        color: w.isAnonymous ? c : s
                      },
                      children: w.isAnonymous ? "Guest" : P
                        ?.displayName || "Signed In"
                    })]
                  }), P?.email && (0, o.jsx)("div", {
                    className: "font-mono text-[10px] truncate",
                    style: {
                      color: "#666"
                    },
                    children: P.email
                  })]
                })]
              }), (0, o.jsxs)("div", {
                className: "flex gap-2",
                children: [(0, o.jsx)("button", {
                  onClick: G,
                  disabled: "uploading" === C,
                  className: "flex-1 py-1.5 px-2 text-[10px] font-mono font-bold rounded",
                  style: {
                    backgroundColor: "done" === C ? "rgba(0,255,102,0.15)" :
                      "rgba(0,255,255,0.08)",
                    border: `1px solid ${"done"===C?s:"error"===C?"#ff3333":n}`,
                    color: "done" === C ? s : "error" === C ? "#ff3333" : n,
                    opacity: "uploading" === C ? .5 : 1
                  },
                  children: "uploading" === C ? "⬆ SYNCING..." : "done" === C ?
                    "✓ UPLOADED" : "error" === C ? "✗ FAILED" : "⬆ UPLOAD"
                }), (0, o.jsx)("button", {
                  onClick: $,
                  disabled: "downloading" === C,
                  className: "flex-1 py-1.5 px-2 text-[10px] font-mono font-bold rounded",
                  style: {
                    backgroundColor: "rgba(255,102,0,0.08)",
                    border: `1px solid ${"error"===C?"#ff3333":c}`,
                    color: "error" === C ? "#ff3333" : c,
                    opacity: "downloading" === C ? .5 : 1
                  },
                  children: "downloading" === C ? "⬇ LOADING..." : "⬇ DOWNLOAD"
                })]
              }), w.isAnonymous && (0, o.jsxs)("button", {
                onClick: D,
                className: "w-full py-1.5 px-2 text-[10px] font-mono font-bold rounded flex items-center justify-center gap-1.5",
                style: {
                  backgroundColor: "rgba(255,215,0,0.08)",
                  border: "1px solid #ffd70060",
                  color: m
                },
                children: [(0, o.jsxs)("svg", {
                  width: "14",
                  height: "14",
                  viewBox: "0 0 24 24",
                  style: {
                    flexShrink: 0
                  },
                  children: [(0, o.jsx)("path", {
                    fill: "#4285F4",
                    d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                  }), (0, o.jsx)("path", {
                    fill: "#34A853",
                    d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  }), (0, o.jsx)("path", {
                    fill: "#FBBC05",
                    d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  }), (0, o.jsx)("path", {
                    fill: "#EA4335",
                    d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  })]
                }), "LINK GOOGLE ACCOUNT"]
              }), (0, o.jsx)("button", {
                onClick: B,
                className: "w-full py-1 px-2 text-[9px] font-mono rounded",
                style: {
                  border: "1px solid #444",
                  color: "#666"
                },
                children: "SIGN OUT"
              })]
            }) : (0, o.jsxs)("div", {
              className: "space-y-2",
              children: [(0, o.jsx)("div", {
                className: "text-[10px] font-mono mb-2",
                style: {
                  color: "#888"
                },
                children: "Sign in to save your progress to the cloud"
              }), (0, o.jsx)("button", {
                onClick: L,
                className: "w-full py-2 px-3 text-xs font-mono font-bold rounded",
                style: {
                  backgroundColor: "rgba(0,255,255,0.08)",
                  border: "1px solid #00ffff60",
                  color: n
                },
                children: "PLAY AS GUEST"
              }), (0, o.jsxs)("button", {
                onClick: D,
                className: "w-full py-2 px-3 text-xs font-mono font-bold rounded flex items-center justify-center gap-2",
                style: {
                  backgroundColor: "rgba(255,215,0,0.08)",
                  border: "1px solid #ffd70060",
                  color: m
                },
                children: [(0, o.jsxs)("svg", {
                  width: "16",
                  height: "16",
                  viewBox: "0 0 24 24",
                  style: {
                    flexShrink: 0
                  },
                  children: [(0, o.jsx)("path", {
                    fill: "#4285F4",
                    d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                  }), (0, o.jsx)("path", {
                    fill: "#34A853",
                    d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  }), (0, o.jsx)("path", {
                    fill: "#FBBC05",
                    d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  }), (0, o.jsx)("path", {
                    fill: "#EA4335",
                    d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  })]
                }), "SIGN IN WITH GOOGLE"]
              })]
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3",
            children: [(0, o.jsx)("label", {
              className: "text-xs font-mono mb-1.5 block",
              style: {
                color: "#888"
              },
              children: "AVATAR"
            }), (0, o.jsxs)("div", {
              className: "flex items-center gap-2 mb-2",
              children: [(0, o.jsx)("div", {
                className: "rounded-full flex items-center justify-center overflow-hidden",
                style: {
                  width: 48,
                  height: 48,
                  backgroundColor: "rgba(170,0,255,0.15)",
                  border: "2px solid #aa00ff",
                  boxShadow: "0 0 10px #aa00ff40"
                },
                children: U(48)
              }), (0, o.jsxs)("div", {
                className: "flex-1 flex gap-2",
                children: [(0, o.jsx)("button", {
                  onClick: () => j.current?.click(),
                  disabled: T,
                  className: "flex-1 py-1.5 px-2 text-[10px] font-mono font-bold rounded",
                  style: {
                    backgroundColor: "rgba(170,0,255,0.08)",
                    border: "1px solid #aa00ff60",
                    color: h,
                    opacity: T ? .5 : 1
                  },
                  children: T ? "⏳ PROCESSING..." : "📷 UPLOAD IMAGE"
                }), tj(f) && (0, o.jsx)("button", {
                  onClick: () => {
                    u("⚔️"), eo.init(), eo.playMenuClick()
                  },
                  className: "py-1.5 px-2 text-[10px] font-mono font-bold rounded",
                  style: {
                    backgroundColor: "rgba(255,51,51,0.08)",
                    border: "1px solid #ff333360",
                    color: "#ff3333"
                  },
                  children: "✕ REMOVE"
                })]
              }), (0, o.jsx)("input", {
                ref: j,
                type: "file",
                accept: "image/*",
                onChange: F,
                className: "hidden"
              })]
            }), (0, o.jsx)("div", {
              className: "flex flex-wrap gap-1.5",
              children: tT.map(e => (0, o.jsx)("button", {
                onClick: () => {
                  u(e), eo.init(), eo.playMenuClick()
                },
                className: "w-8 h-8 text-base rounded flex items-center justify-center transition-all",
                style: {
                  backgroundColor: f !== e || tj(f) ? "rgba(0,0,0,0.3)" :
                    "rgba(170,0,255,0.2)",
                  border: f !== e || tj(f) ? "1px solid #333" : "2px solid #aa00ff",
                  boxShadow: f !== e || tj(f) ? "none" : "0 0 8px #aa00ff"
                },
                children: e
              }, e))
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3",
            children: [(0, o.jsx)("label", {
              className: "text-xs font-mono mb-1 block",
              style: {
                color: "#888"
              },
              children: "USERNAME"
            }), (0, o.jsx)("input", {
              type: "text",
              value: i,
              onChange: e => d(e.target.value.slice(0, 15)),
              onKeyDown: E,
              className: "w-full px-3 py-2 rounded font-mono text-sm",
              style: {
                backgroundColor: "rgba(0,0,0,0.4)",
                border: "1px solid #444",
                color: n,
                outline: "none"
              },
              maxLength: 15
            }), (0, o.jsxs)("span", {
              className: "text-[10px] font-mono",
              style: {
                color: "#555"
              },
              children: [i.length, "/15"]
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3",
            children: [(0, o.jsx)("label", {
              className: "text-xs font-mono mb-1 block",
              style: {
                color: "#888"
              },
              children: "ABOUT"
            }), (0, o.jsx)("input", {
              type: "text",
              value: x,
              onChange: e => p(e.target.value.slice(0, 50)),
              onKeyDown: E,
              className: "w-full px-3 py-2 rounded font-mono text-sm",
              style: {
                backgroundColor: "rgba(0,0,0,0.4)",
                border: "1px solid #444",
                color: "#ddd",
                outline: "none"
              },
              maxLength: 50,
              placeholder: "Tell us about yourself..."
            }), (0, o.jsxs)("span", {
              className: "text-[10px] font-mono",
              style: {
                color: "#555"
              },
              children: [x.length, "/50"]
            })]
          }), (0, o.jsxs)("div", {
            className: "mb-3",
            children: [(0, o.jsx)("label", {
              className: "text-xs font-mono mb-1 block",
              style: {
                color: "#888"
              },
              children: "NATIONALITY"
            }), (0, o.jsxs)("select", {
              value: g,
              onChange: e => y(e.target.value),
              className: "w-full px-3 py-2 rounded font-mono text-sm",
              style: {
                backgroundColor: "rgba(0,0,0,0.4)",
                border: "1px solid #444",
                color: "#ddd",
                outline: "none"
              },
              children: [(0, o.jsx)("option", {
                value: "",
                children: "Select..."
              }), tM.map(e => (0, o.jsx)("option", {
                value: e,
                children: e
              }, e))]
            })]
          }), (0, o.jsx)("button", {
            onClick: () => {
              eo.init(), eo.playMenuClick(), t({
                username: i.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 15) || "NeonWarrior",
                avatar: f,
                about: x.slice(0, 50),
                nationality: g
              }), v(!0), setTimeout(() => v(!1), 2e3)
            },
            className: "neon-btn w-full py-2.5 px-6 text-base font-bold font-mono tracking-wider mb-2",
            style: {
              borderColor: b ? s : h,
              color: b ? s : h,
              textShadow: b ? "0 0 10px #00ff66" : "0 0 10px #aa00ff"
            },
            children: b ? "✓ SAVED!" : "SAVE"
          }), (0, o.jsx)("button", {
            onClick: () => {
              eo.init(), eo.playMenuClick(), l("menu")
            },
            className: "neon-btn w-full py-2 px-4 text-sm tracking-wider",
            style: {
              borderColor: "#666",
              color: "#888"
            },
            children: "BACK"
          })]
        })
      })
    }
    let tP = ["NeonBlade99", "PixelStorm", "VoidRunner", "CyberWolf", "GridMaster", "DarkFlare", "CrimsonX",
      "GhostHack", "StormPilot", "ZeroGravity", "NightShade", "IronPulse", "FrostByte", "ThunderCore",
      "ShadowRift", "BlazeFury", "OmegaZ", "NovaStar", "RogueAgent", "ApexHunter"
    ];

    function tA() {
      let e = ea(e => e.saveData),
        t = ea(e => e.setGamePhase),
        l = (0, a.useMemo)(() => (function(e, t) {
          let o, a = (o = 439939, () => (o = (9301 * o + 49297) % 233280) / 233280),
            l = [];
          for (let e = 0; e < 19; e++) {
            let t = 800 + Math.floor(1200 * a());
            l.push({
              name: tP[e],
              elo: t,
              wins: Math.floor(100 * a()) + 5,
              losses: Math.floor(60 * a()) + 2,
              isPlayer: !1
            })
          }
          return l.push({
            name: t,
            elo: e,
            wins: 0,
            losses: 0,
            isPlayer: !0
          }), l.sort((e, t) => t.elo - e.elo), l
        })(e.rankingData.elo, e.username), [e.rankingData.elo, e.username]);
      return (0, o.jsx)("div", {
        className: "absolute inset-0 z-20 flex items-center justify-center pointer-events-none",
        children: (0, o.jsxs)("div", {
          className: "w-full max-w-md p-6 rounded-lg mx-4 pointer-events-auto max-h-[90vh] overflow-y-auto",
          style: {
            backgroundColor: "rgba(5,5,20,0.95)",
            border: "2px solid #ffd700",
            boxShadow: "0 0 30px #ffd70020"
          },
          children: [(0, o.jsx)("h2", {
            className: "text-2xl font-bold text-center tracking-wider mb-4 font-mono",
            style: {
              color: m,
              textShadow: "0 0 10px #ffd700"
            },
            children: "🏆 LEADERBOARD"
          }), (0, o.jsx)("div", {
            className: "flex flex-col gap-1.5",
            children: l.map((t, a) => {
              let l = O(t.elo);
              return (0, o.jsxs)("div", {
                className: "flex items-center gap-2 p-2 rounded",
                style: {
                  backgroundColor: t.isPlayer ? "rgba(255,215,0,0.1)" : "rgba(0,0,0,0.2)",
                  border: t.isPlayer ? "1px solid #ffd70060" : "1px solid #222"
                },
                children: [(0, o.jsx)("span", {
                  className: "font-bold font-mono text-sm w-8 text-center",
                  style: {
                    color: a < 3 ? m : "#666"
                  },
                  children: a + 1
                }), (0, o.jsx)("span", {
                  className: "text-lg",
                  children: l.icon
                }), (0, o.jsx)("span", {
                  className: "flex-1 font-mono text-sm truncate",
                  style: {
                    color: t.isPlayer ? m : n
                  },
                  children: t.name
                }), (0, o.jsx)("span", {
                  className: "font-mono text-xs",
                  style: {
                    color: c
                  },
                  children: t.elo
                }), (0, o.jsx)("span", {
                  className: "font-mono text-[10px]",
                  style: {
                    color: "#555"
                  },
                  children: t.isPlayer ?
                    `${e.rankingData.wins}W ${e.rankingData.losses}L` : `${t.wins}W`
                })]
              }, t.name)
            })
          }), (0, o.jsx)("button", {
            onClick: () => {
              eo.init(), eo.playMenuClick(), t("menu")
            },
            className: "neon-btn w-full py-2 px-4 text-sm tracking-wider mt-4",
            style: {
              borderColor: "#666",
              color: "#888"
            },
            children: "BACK"
          })]
        })
      })
    }
    let tR = {
      1: {
        color: "#00ffff",
        glow: "#00ffff",
        gradient: "linear-gradient(135deg, #00ffff20, #00446610)",
        icon: "⚡",
        name: "THE AWAKENING"
      },
      2: {
        color: "#aa44ff",
        glow: "#aa44ff",
        gradient: "linear-gradient(135deg, #aa44ff20, #44008810)",
        icon: "👥",
        name: "THE GANG"
      },
      3: {
        color: "#ff4444",
        glow: "#ff4444",
        gradient: "linear-gradient(135deg, #ff444420, #66000010)",
        icon: "🛡️",
        name: "THE RESCUE"
      },
      4: {
        color: "#ff44aa",
        glow: "#ff44aa",
        gradient: "linear-gradient(135deg, #ff44aa20, #66004410)",
        icon: "🏰",
        name: "PROTECT"
      },
      5: {
        color: "#ffd700",
        glow: "#ffd700",
        gradient: "linear-gradient(135deg, #ffd70020, #66440010)",
        icon: "⚔️",
        name: "THE FINAL WAR"
      },
      6: {
        color: "#00ff66",
        glow: "#00ff66",
        gradient: "linear-gradient(135deg, #00ff6620, #00442210)",
        icon: "🔮",
        name: "THE INFINITE GRID"
      },
      7: {
        color: "#ff4400",
        glow: "#ff4400",
        gradient: "linear-gradient(135deg, #ff440020, #44110010)",
        icon: "🐉",
        name: "DRAGON'S DOMAIN"
      },
      8: {
        color: "#aaaaaa",
        glow: "#aaaaaa",
        gradient: "linear-gradient(135deg, #aaaaaa20, #44444410)",
        icon: "🤖",
        name: "MECH WARFARE"
      },
      9: {
        color: "#8800ff",
        glow: "#8800ff",
        gradient: "linear-gradient(135deg, #8800ff20, #22006610)",
        icon: "👁️",
        name: "SHADOW REALM"
      },
      10: {
        color: "#ff8800",
        glow: "#ff8800",
        gradient: "linear-gradient(135deg, #ff880020, #44220010)",
        icon: "🔥",
        name: "PHOENIX RISING"
      }
    };

    function tI(e) {
      if (tR[e]) return tR[e];
      let t = `hsl(${37*e%360}, 100%, 60%)`;
      return {
        color: t,
        glow: t,
        gradient: `linear-gradient(135deg, ${t}20, ${t}08)`,
        icon: "🌀",
        name: `ZONE ${e}`
      }
    }

    function tE({
      levelNum: e,
      highestLevel: t,
      completedLevels: l,
      isFoggy: r,
      stars: n,
      onClick: i
    }) {
      let s = e > t,
        c = l.includes(e),
        d = e === t,
        h = e > 8 ? e % (e > 50 ? 3 : 5) == 0 : [6, 8].includes(e),
        f = tI(Math.ceil(e / 10)),
        u = G.find(t => t.id === e);
      u && u.name;
      let x = h ? 56 : d ? 52 : 46,
        p = h ? "text-xs" : d ? "text-[11px]" : "text-[10px]",
        [g, y] = (0, a.useState)(0);
      (0, a.useEffect)(() => {
        if (!d || r) return;
        let e = setInterval(() => {
          y(e => (e + 1) % 60)
        }, 50);
        return () => clearInterval(e)
      }, [d, r]);
      let b = d ? 1 + .06 * Math.sin(g / 60 * Math.PI * 2) : 1,
        v = {},
        w = "1px solid #1a1a2e",
        k = {
          color: "#333"
        },
        C = null;
      return r ? (v = {
        background: "radial-gradient(circle, rgba(20,10,40,0.4), rgba(5,5,16,0.6))"
      }, w = "1px dashed #1a1a2e", k = {
        color: "#1a1a2e"
      }, C = (0, o.jsx)("span", {
        style: {
          fontSize: 10,
          opacity: .3
        },
        children: "?"
      })) : c ? (v = {
        background: `radial-gradient(circle, ${f.color}25, ${f.color}08)`,
        boxShadow: `0 0 12px ${f.color}30, inset 0 0 8px ${f.color}10`
      }, w = `2px solid ${f.color}`, k = {
        color: f.color,
        textShadow: `0 0 8px ${f.color}80`
      }, C = (0, o.jsx)("div", {
        className: "flex gap-px",
        children: [1, 2, 3].map(e => (0, o.jsx)("span", {
          style: {
            fontSize: 7,
            color: e <= n ? "#ffd700" : "#333",
            textShadow: e <= n ? "0 0 4px #ffd700" : "none"
          },
          children: "★"
        }, e))
      })) : d ? (v = {
        background: `radial-gradient(circle, ${m}35, ${m}10)`,
        boxShadow: `0 0 20px ${m}60, 0 0 40px ${m}25, inset 0 0 15px ${m}15`,
        transform: `scale(${b})`
      }, w = `2px solid ${m}`, k = {
        color: m,
        textShadow: `0 0 10px ${m}`
      }, C = (0, o.jsx)("span", {
        style: {
          fontSize: 10
        },
        children: "▶"
      })) : s && (v = {
        background: "radial-gradient(circle, rgba(15,15,30,0.5), rgba(5,5,16,0.7))"
      }, w = "1px solid #1a1a2e", k = {
        color: "#2a2a3e"
      }, C = (0, o.jsx)("span", {
        style: {
          fontSize: 9,
          opacity: .5
        },
        children: "🔒"
      })), (0, o.jsxs)("button", {
        onClick: i,
        className: "flex flex-col items-center justify-center rounded-xl transition-all duration-300 hover:scale-105 active:scale-95",
        style: {
          width: x,
          height: x,
          ...v,
          border: w,
          cursor: r || s ? "not-allowed" : "pointer",
          opacity: r ? .3 : 1
        },
        children: [h && !r && !s && (0, o.jsx)("span", {
          style: {
            fontSize: 9,
            lineHeight: 1,
            marginBottom: -2,
            filter: c ? `drop-shadow(0 0 3px ${f.color})` : "none"
          },
          children: "👑"
        }), (0, o.jsx)("span", {
          className: `font-bold font-mono ${p} leading-none`,
          style: k,
          children: e
        }), C]
      })
    }

    function tL({
      chapterNum: e,
      theme: t,
      completedInChapter: a,
      totalInChapter: l,
      isFoggy: r,
      chapterRef: n
    }) {
      let i = l > 0 ? a / l * 100 : 0,
        c = a === l;
      return (0, o.jsx)("div", {
        ref: n,
        className: "w-full mb-3",
        children: (0, o.jsx)("div", {
          className: "relative rounded-lg overflow-hidden px-4 py-2.5 mb-2",
          style: {
            background: r ? "linear-gradient(135deg, rgba(20,10,40,0.2), rgba(10,5,20,0.3))" : t.gradient,
            border: r ? "1px dashed #1a1a2e" : `1px solid ${t.color}40`,
            boxShadow: r ? "none" : `0 0 15px ${t.glow}15`
          },
          children: (0, o.jsxs)("div", {
            className: "flex items-center gap-2",
            children: [(0, o.jsx)("span", {
              className: "text-lg",
              style: {
                opacity: r ? .2 : 1
              },
              children: t.icon
            }), (0, o.jsxs)("div", {
              className: "flex-1 min-w-0",
              children: [(0, o.jsxs)("div", {
                className: "flex items-baseline gap-2",
                children: [(0, o.jsxs)("span", {
                  className: "font-bold font-mono text-xs tracking-widest",
                  style: {
                    color: r ? "#1a1a2e" : t.color,
                    textShadow: r ? "none" : `0 0 8px ${t.glow}60`
                  },
                  children: ["CH.", e]
                }), (0, o.jsx)("span", {
                  className: "font-mono text-[10px] truncate",
                  style: {
                    color: r ? "#1a1a2e" : "#888"
                  },
                  children: r ? "???" : t.name
                })]
              }), !r && (0, o.jsxs)("div", {
                className: "flex items-center gap-2 mt-1",
                children: [(0, o.jsx)("div", {
                  className: "flex-1 h-1.5 rounded-full overflow-hidden",
                  style: {
                    backgroundColor: "rgba(255,255,255,0.05)"
                  },
                  children: (0, o.jsx)("div", {
                    className: "h-full rounded-full transition-all duration-700",
                    style: {
                      width: `${i}%`,
                      backgroundColor: c ? s : t.color,
                      boxShadow: `0 0 6px ${c?s:t.color}50`
                    }
                  })
                }), (0, o.jsxs)("span", {
                  className: "font-mono text-[8px] flex-shrink-0",
                  style: {
                    color: c ? s : "#555",
                    textShadow: c ? "0 0 5px #00ff66" : "none"
                  },
                  children: [a, "/", l]
                })]
              })]
            }), c && !r && (0, o.jsx)("span", {
              className: "text-[10px] font-mono font-bold px-1.5 py-0.5 rounded",
              style: {
                color: s,
                backgroundColor: "#00ff6615",
                border: "1px solid #00ff6640",
                textShadow: "0 0 5px #00ff66"
              },
              children: "DONE"
            })]
          })
        })
      })
    }

    function tD({
      color: e
    }) {
      let t = Array.from({
        length: 6
      }, (e, t) => ({
        id: t,
        delay: .5 * t,
        x: 20 + 60 * Math.random(),
        size: 2 + 3 * Math.random()
      }));
      return (0, o.jsx)("div", {
        className: "absolute inset-0 pointer-events-none overflow-hidden",
        children: t.map(t => (0, o.jsx)("div", {
          className: "absolute rounded-full",
          style: {
            width: t.size,
            height: t.size,
            backgroundColor: e,
            boxShadow: `0 0 ${2*t.size}px ${e}`,
            left: `${t.x}%`,
            bottom: "0%",
            animation: "float-up 2s ease-out infinite",
            animationDelay: `${t.delay}s`,
            opacity: 0
          }
        }, t.id))
      })
    }

    function tW({
      highestLevel: e
    }) {
      let t = (0, a.useRef)(null),
        l = (0, a.useRef)(0),
        r = (0, a.useRef)([]),
        n = (0, a.useRef)([]),
        i = (0, a.useRef)([]),
        s = (0, a.useRef)(0),
        c = (0, a.useRef)(0),
        d = R(A((Math.ceil(Math.max(e, 1) / 10) - 1) % 10 * 10 + 1)),
        h = d.particleColor,
        f = d.platformGlow,
        u = (0, a.useCallback)(e => {
          let t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
          return t ? {
            r: parseInt(t[1], 16),
            g: parseInt(t[2], 16),
            b: parseInt(t[3], 16)
          } : {
            r: 0,
            g: 255,
            b: 255
          }
        }, []);
      return (0, a.useEffect)(() => {
        r.current = Array.from({
          length: 65
        }, () => ({
          x: Math.random(),
          y: Math.random(),
          size: .5 + 1.5 * Math.random(),
          twinkleSpeed: .5 + 2 * Math.random(),
          twinkleOffset: Math.random() * Math.PI * 2,
          baseOpacity: .3 + .5 * Math.random()
        })), n.current = Array.from({
          length: 25
        }, () => ({
          x: Math.random(),
          y: Math.random(),
          vx: (Math.random() - .5) * 3e-4,
          vy: -2e-4 - 5e-4 * Math.random(),
          size: 1.5 + 3 * Math.random(),
          opacity: Math.random(),
          opacityDir: (Math.random() > .5 ? 1 : -1) * (.005 + .01 * Math.random()),
          color: Math.random() > .3 ? h : "#ffffff",
          life: 300 * Math.random(),
          maxLife: 300 + 200 * Math.random()
        }));
        let e = ["triangle", "diamond", "hexagon", "circle"];
        i.current = Array.from({
          length: 7
        }, () => ({
          x: .05 + .9 * Math.random(),
          y: .05 + .9 * Math.random(),
          vx: (Math.random() - .5) * 1e-4,
          vy: (Math.random() - .5) * 1e-4,
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - .5) * .005,
          size: 8 + 16 * Math.random(),
          opacity: .06 + .1 * Math.random(),
          type: e[Math.floor(Math.random() * e.length)],
          color: Math.random() > .4 ? h : f
        }))
      }, [h, f]), (0, a.useEffect)(() => {
        let e = t.current;
        if (!e) return;
        let o = e.getContext("2d");
        if (!o) return;
        let a = u(h),
          d = () => {
            let t = e.width,
              f = e.height;
            if (0 === t || 0 === f) {
              l.current = requestAnimationFrame(d);
              return
            }
            s.current += 1, c.current = (c.current + .15) % 50;
            let m = s.current;
            o.fillStyle = "rgba(5, 5, 16, 1)", o.fillRect(0, 0, t, f);
            let x = [{
              r: a.r,
              g: a.g,
              b: a.b
            }, {
              r: Math.min(255, a.r + 60),
              g: Math.max(0, a.g - 40),
              b: Math.min(255, a.b + 80)
            }, {
              r: Math.max(0, a.r - 40),
              g: Math.min(255, a.g + 60),
              b: Math.max(0, a.b - 40)
            }];
            for (let e = 0; e < 3; e++) {
              let a = x[e];
              o.beginPath(), o.moveTo(0, 0);
              let l = f * (.08 + .05 * e);
              for (let a = 0; a <= t; a += 4) {
                let r = a / t,
                  n = l + .04 * f * Math.sin(3 * r + .008 * m + 1.2 * e) + .02 * f * Math.sin(5 * r + .012 * m +
                    .7 * e);
                o.lineTo(a, n)
              }
              o.lineTo(t, 0), o.closePath();
              let r = .04 + .015 * Math.sin(.01 * m + e);
              o.fillStyle = `rgba(${a.r}, ${a.g}, ${a.b}, ${r})`, o.fill()
            }
            let p = c.current;
            o.strokeStyle = `rgba(${a.r}, ${a.g}, ${a.b}, 0.04)`, o.lineWidth = .5;
            for (let e = p; e < t; e += 50) o.beginPath(), o.moveTo(e, 0), o.lineTo(e, f), o.stroke();
            for (let e = p; e < f; e += 50) o.beginPath(), o.moveTo(0, e), o.lineTo(t, e), o.stroke();
            for (let e of r.current) {
              let a = Math.sin(.02 * m * e.twinkleSpeed + e.twinkleOffset),
                l = e.baseOpacity + .25 * a;
              l <= 0 || (o.beginPath(), o.arc(e.x * t, e.y * f, e.size, 0, 2 * Math.PI), o.fillStyle =
                `rgba(255, 255, 255, ${Math.min(1,Math.max(0,l))})`, o.fill())
            }
            for (let e of n.current) {
              e.x += e.vx, e.y += e.vy, e.opacity += e.opacityDir, e.life += 1, (e.y < -.05 || e.x < -.05 || e
                  .x > 1.05 || e.opacity <= 0 || e.life > e.maxLife) && (e.x = Math.random(), e.y = .9 + .15 *
                  Math.random(), e.vx = (Math.random() - .5) * 3e-4, e.vy = -2e-4 - 5e-4 * Math.random(), e
                  .opacity = 0, e.opacityDir = Math.abs(e.opacityDir), e.life = 0, e.color = Math.random() >
                  .3 ? h : "#ffffff"), e.opacity >= .8 && (e.opacityDir = -Math.abs(e.opacityDir)), e.opacity <=
                0 && (e.opacityDir = Math.abs(e.opacityDir));
              let a = u(e.color),
                l = e.x * t,
                r = e.y * f,
                n = .7 * Math.max(0, Math.min(1, e.opacity)),
                i = o.createRadialGradient(l, r, 0, l, r, 3 * e.size);
              i.addColorStop(0, `rgba(${a.r}, ${a.g}, ${a.b}, ${n})`), i.addColorStop(1,
                  `rgba(${a.r}, ${a.g}, ${a.b}, 0)`), o.beginPath(), o.arc(l, r, 3 * e.size, 0, 2 * Math.PI), o
                .fillStyle = i, o.fill(), o.beginPath(), o.arc(l, r, e.size, 0, 2 * Math.PI), o.fillStyle =
                `rgba(${a.r}, ${a.g}, ${a.b}, ${n})`, o.fill()
            }
            for (let e of i.current) {
              e.x += e.vx, e.y += e.vy, e.rotation += e.rotationSpeed, (e.x < .02 || e.x > .98) && (e.vx *= -1),
                (e.y < .02 || e.y > .98) && (e.vy *= -1);
              let a = e.x * t,
                l = e.y * f,
                r = u(e.color);
              o.save(), o.translate(a, l), o.rotate(e.rotation), o.strokeStyle =
                `rgba(${r.r}, ${r.g}, ${r.b}, ${e.opacity})`, o.lineWidth = 1, o.beginPath();
              let n = e.size;
              switch (e.type) {
                case "triangle":
                  o.moveTo(0, -n), o.lineTo(.866 * n, .5 * n), o.lineTo(-(.866 * n), .5 * n), o.closePath();
                  break;
                case "diamond":
                  o.moveTo(0, -n), o.lineTo(.6 * n, 0), o.lineTo(0, n), o.lineTo(-(.6 * n), 0), o.closePath();
                  break;
                case "hexagon":
                  for (let e = 0; e < 6; e++) {
                    let t = Math.PI / 3 * e - Math.PI / 6,
                      a = Math.cos(t) * n * .7,
                      l = Math.sin(t) * n * .7;
                    0 === e ? o.moveTo(a, l) : o.lineTo(a, l)
                  }
                  o.closePath();
                  break;
                case "circle":
                  o.arc(0, 0, .6 * n, 0, 2 * Math.PI)
              }
              o.stroke(), o.strokeStyle = `rgba(${r.r}, ${r.g}, ${r.b}, ${.3*e.opacity})`, o.lineWidth = 3, o
                .stroke(), o.restore()
            }
            let g = o.createRadialGradient(t / 2, f / 2, .3 * f, t / 2, f / 2, .9 * f);
            g.addColorStop(0, "rgba(5, 5, 16, 0)"), g.addColorStop(1, "rgba(5, 5, 16, 0.5)"), o.fillStyle = g, o
              .fillRect(0, 0, t, f), l.current = requestAnimationFrame(d)
          };
        return l.current = requestAnimationFrame(d), () => cancelAnimationFrame(l.current)
      }, [h, u]), (0, a.useEffect)(() => {
        let e = t.current;
        if (!e) return;
        let o = () => {
          let t = e.parentElement;
          t && (e.width = t.clientWidth, e.height = t.clientHeight)
        };
        o();
        let a = new ResizeObserver(o);
        return a.observe(e.parentElement), () => a.disconnect()
      }, []), (0, o.jsx)("canvas", {
        ref: t,
        className: "absolute inset-0",
        style: {
          zIndex: 0,
          pointerEvents: "none"
        }
      })
    }

    function tO() {
      let e = ea(e => e.saveData),
        t = ea(e => e.startLevel),
        l = ea(e => e.setGamePhase),
        r = (0, a.useRef)(null),
        [c, d] = (0, a.useState)(null),
        h = (0, a.useRef)({}),
        f = e.highestLevel,
        u = e.missionsCompleted.map(Number),
        x = f > 100,
        p = x ? Math.min(Math.ceil(f / 10) + 1, Math.ceil(220)) : 10,
        g = (0, a.useCallback)(e => {
          eo.init(), eo.playMenuClick(), e()
        }, []);
      (0, a.useEffect)(() => {
        let e = Math.min(Math.ceil(f / 10), p);
        setTimeout(() => {
          let t = h.current[e];
          t && t.scrollIntoView({
            behavior: "smooth",
            block: "center"
          })
        }, 300)
      }, [f, p]);
      let y = (l, r, n) => {
          let i = tI(n),
            s = "ltr" === r ? l : [...l].reverse();
          return (0, o.jsx)("div", {
            className: "flex items-center justify-center gap-0",
            children: s.map((l, r) => {
              let n = l > 100 && !x,
                c = l === f,
                h = u.includes(l),
                p = r > 0 ? s[r - 1] : null;
              return (0, o.jsxs)(a.default.Fragment, {
                children: [r > 0 && p && (0, o.jsx)("div", {
                  className: "flex-shrink-0",
                  style: {
                    width: 12,
                    height: 2,
                    backgroundColor: h && u.includes(p) ? i.color : "#1a1a2e",
                    boxShadow: h && u.includes(p) ? `0 0 4px ${i.color}50` : "none",
                    opacity: h && u.includes(p) ? .7 : .3,
                    borderRadius: 1
                  }
                }), (0, o.jsxs)("div", {
                  className: "relative flex-shrink-0",
                  children: [(0, o.jsx)(tE, {
                    levelNum: l,
                    highestLevel: f,
                    completedLevels: u,
                    isFoggy: n,
                    stars: e.levelStars?.[String(l)] ?? +!!u.includes(l),
                    onClick: () => (e => {
                      let o = e > f,
                        a = e > 100 && !x;
                      if (o || a) {
                        eo.init(), eo.playMenuClick();
                        return
                      }
                      g(() => {
                        d(e), ev(), t(e)
                      })
                    })(l)
                  }), c && !n && (0, o.jsx)(tD, {
                    color: m
                  })]
                })]
              }, l)
            })
          })
        },
        b = (e, t, a) => {
          let l = tI(a),
            r = u.includes(e) && u.includes(t),
            n = e > 100 && !x;
          return (0, o.jsx)("div", {
            className: "flex justify-end pr-4",
            style: {
              padding: "2px 0"
            },
            children: (0, o.jsx)("div", {
              style: {
                width: 2,
                height: 14,
                backgroundColor: n ? "#0a0a15" : r ? l.color : "#1a1a2e",
                boxShadow: r ? `0 0 4px ${l.color}50` : "none",
                opacity: n ? .1 : r ? .7 : .3,
                borderRadius: 1
              }
            })
          })
        },
        v = [];
      for (let e = 1; e <= p; e++) {
        let t = (e - 1) * 10 + 1,
          a = Math.min(10 * e, 100),
          l = e > 10 && !x,
          r = l ? .15 : 1,
          n = tI(e),
          i = Array.from({
            length: a - t + 1
          }, (e, o) => t + o).filter(e => u.includes(e)).length,
          s = a - t + 1,
          c = Array.from({
            length: 5
          }, (e, o) => t + o),
          d = Array.from({
            length: Math.min(5, a - t - 4)
          }, (e, o) => t + 5 + o);
        v.push((0, o.jsxs)("div", {
          style: {
            opacity: r
          },
          className: "mb-2",
          children: [(0, o.jsx)(tL, {
            chapterNum: e,
            theme: n,
            completedInChapter: i,
            totalInChapter: s,
            isFoggy: l,
            chapterRef: t => {
              h.current[e] = t
            }
          }), (0, o.jsxs)("div", {
            className: "flex flex-col items-center px-2 mb-1",
            children: [y(c, "ltr", e), d.length > 0 && b(c[4], d[0], e), d.length > 0 && y(d, "rtl", e)]
          }), e < p && (0, o.jsx)("div", {
            className: "flex items-center justify-center py-2",
            children: (0, o.jsxs)("div", {
              className: "flex flex-col items-center gap-0.5",
              children: [
                [0, 1, 2].map(e => (0, o.jsx)("div", {
                  className: "w-1 h-1 rounded-full",
                  style: {
                    backgroundColor: i === s ? n.color : "#1a1a2e",
                    boxShadow: i === s ? `0 0 4px ${n.color}50` : "none",
                    opacity: .5 + .1 * e
                  }
                }, e)), (0, o.jsx)("svg", {
                  width: "8",
                  height: "8",
                  viewBox: "0 0 8 8",
                  style: {
                    opacity: .4
                  },
                  children: (0, o.jsx)("path", {
                    d: "M4 0 L8 4 L4 8 L0 4 Z",
                    fill: i === s ? n.color : "#1a1a2e"
                  })
                })
              ]
            })
          })]
        }, e))
      }
      let w = u.length,
        k = Math.min(w / 100 * 100, 100);
      return (0, o.jsxs)("div", {
        style: {
          backgroundColor: "transparent"
        },
        className: "jsx-ab3c149bca899a0f absolute inset-0 z-30 flex flex-col",
        children: [(0, o.jsx)(tW, {
          highestLevel: f
        }), (0, o.jsxs)("div", {
          style: {
            borderBottom: "1px solid rgba(0, 255, 255, 0.15)",
            background: "linear-gradient(180deg, rgba(5,5,16,0.98) 0%, rgba(5,5,16,0.92) 100%)"
          },
          className: "jsx-ab3c149bca899a0f relative z-10 flex-shrink-0 px-4 py-3",
          children: [(0, o.jsxs)("div", {
            className: "jsx-ab3c149bca899a0f flex items-center justify-between mb-2",
            children: [(0, o.jsxs)("button", {
              onClick: () => g(() => l("menu")),
              style: {
                border: "1px solid #333",
                color: "#888"
              },
              className: "jsx-ab3c149bca899a0f flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all hover:bg-white/5",
              children: [(0, o.jsx)("span", {
                style: {
                  fontSize: 12
                },
                className: "jsx-ab3c149bca899a0f",
                children: "←"
              }), (0, o.jsx)("span", {
                className: "jsx-ab3c149bca899a0f font-mono text-xs font-bold tracking-wider",
                children: "BACK"
              })]
            }), (0, o.jsx)("h2", {
              style: {
                color: n,
                textShadow: "0 0 15px #00ffff80, 0 0 30px #00ffff30"
              },
              className: "jsx-ab3c149bca899a0f text-lg font-bold tracking-widest font-mono",
              children: "LEVEL MAP"
            }), (0, o.jsxs)("div", {
              style: {
                color: m,
                textShadow: "0 0 8px #ffd70040"
              },
              className: "jsx-ab3c149bca899a0f font-mono text-xs font-bold",
              children: ["LV ", f]
            })]
          }), (0, o.jsxs)("div", {
            className: "jsx-ab3c149bca899a0f flex items-center gap-2",
            children: [(0, o.jsx)("div", {
              style: {
                backgroundColor: "rgba(255,255,255,0.05)"
              },
              className: "jsx-ab3c149bca899a0f flex-1 h-2 rounded-full overflow-hidden",
              children: (0, o.jsx)("div", {
                style: {
                  width: `${k}%`,
                  background: "linear-gradient(90deg, #00ffff, #00ff66, #ffd700)",
                  boxShadow: "0 0 8px rgba(0,255,102,0.4)"
                },
                className: "jsx-ab3c149bca899a0f h-full rounded-full transition-all duration-1000"
              })
            }), (0, o.jsxs)("span", {
              style: {
                color: "#666"
              },
              className: "jsx-ab3c149bca899a0f font-mono text-[9px] flex-shrink-0",
              children: [w, "/", 100]
            })]
          })]
        }), (0, o.jsx)("div", {
          style: {
            borderBottom: "1px solid rgba(255,255,255,0.03)",
            scrollbarWidth: "none"
          },
          className: "jsx-ab3c149bca899a0f relative z-10 flex-shrink-0 flex gap-1.5 px-3 py-2 overflow-x-auto",
          children: Array.from({
            length: p
          }, (e, t) => t + 1).map(e => {
            let t = Math.ceil(f / 10) === e,
              a = tI(e),
              l = e > 10 && !x;
            return (0, o.jsx)("button", {
              onClick: () => {
                let t = h.current[e];
                t && t.scrollIntoView({
                  behavior: "smooth",
                  block: "center"
                }), eo.init(), eo.playMenuClick()
              },
              style: {
                backgroundColor: t ? `${a.color}18` : "rgba(0,0,0,0.2)",
                border: t ? `1px solid ${a.color}60` : "1px solid #1a1a2e",
                color: l ? "#1a1a2e" : t ? a.color : "#555",
                textShadow: t ? `0 0 8px ${a.color}60` : "none",
                boxShadow: t ? `0 0 10px ${a.color}20` : "none"
              },
              className: "jsx-ab3c149bca899a0f flex-shrink-0 px-2.5 py-1.5 rounded-lg transition-all hover:scale-105 active:scale-95",
              children: (0, o.jsxs)("span", {
                className: "jsx-ab3c149bca899a0f font-mono text-[9px] font-bold tracking-wider",
                children: [a.icon, " ", e]
              })
            }, e)
          })
        }), (0, o.jsx)("div", {
          ref: r,
          style: {
            scrollbarWidth: "none",
            WebkitOverflowScrolling: "touch",
            maskImage: "linear-gradient(to bottom, transparent 0%, black 3%, black 97%, transparent 100%)",
            WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 3%, black 97%, transparent 100%)"
          },
          className: "jsx-ab3c149bca899a0f relative z-10 flex-1 overflow-y-auto px-2 py-4",
          children: (0, o.jsxs)("div", {
            className: "jsx-ab3c149bca899a0f max-w-md mx-auto",
            children: [v, x ? null : (0, o.jsx)("div", {
              className: "w-full mt-6 mb-8",
              children: (0, o.jsxs)("div", {
                className: "relative rounded-xl p-5 text-center overflow-hidden",
                style: {
                  background: "linear-gradient(180deg, rgba(20,10,40,0.3) 0%, rgba(10,5,25,0.5) 100%)",
                  border: "1px dashed #2a1a4e"
                },
                children: [(0, o.jsx)("div", {
                  className: "absolute inset-0",
                  style: {
                    background: "radial-gradient(ellipse at 50% 50%, rgba(60,20,100,0.15), transparent 70%)",
                    animation: "fog-drift 8s ease-in-out infinite alternate"
                  }
                }), (0, o.jsxs)("div", {
                  className: "relative z-10",
                  children: [(0, o.jsx)("div", {
                    className: "text-2xl mb-2",
                    children: "🌫️"
                  }), (0, o.jsx)("div", {
                    className: "font-bold font-mono text-sm tracking-wider mb-1",
                    style: {
                      color: "#6a3abe",
                      textShadow: "0 0 10px #6a3abe60"
                    },
                    children: "??? MYSTERY ZONE ???"
                  }), (0, o.jsx)("div", {
                    className: "text-[10px] font-mono",
                    style: {
                      color: "#4a3a8e"
                    },
                    children: "Complete Level 100 to unlock the path beyond..."
                  }), (0, o.jsx)("div", {
                    className: "mt-3 flex items-center justify-center gap-2",
                    children: [1, 2, 3, 4, 5].map(e => (0, o.jsx)("div", {
                      className: "w-1.5 h-1.5 rounded-full",
                      style: {
                        backgroundColor: "#4a2a8e",
                        animation: `neon-pulse ${1.5+.3*e}s ease-in-out infinite`,
                        animationDelay: `${.2*e}s`
                      }
                    }, e))
                  })]
                })]
              })
            }), x && (0, o.jsx)("div", {
              className: "jsx-ab3c149bca899a0f mt-6 mb-8 text-center",
              children: (0, o.jsxs)("div", {
                style: {
                  background: "linear-gradient(135deg, rgba(170,0,255,0.1), rgba(255,0,102,0.1))",
                  border: "1px solid #aa00ff30"
                },
                className: "jsx-ab3c149bca899a0f rounded-xl p-4",
                children: [(0, o.jsx)("div", {
                  className: "jsx-ab3c149bca899a0f text-xl mb-1",
                  children: "🌌"
                }), (0, o.jsx)("div", {
                  style: {
                    color: i,
                    textShadow: "0 0 15px #ff00ff60"
                  },
                  className: "jsx-ab3c149bca899a0f font-bold font-mono text-xs tracking-wider mb-1",
                  children: "THE INFINITE FRONTIER"
                }), (0, o.jsxs)("div", {
                  style: {
                    color: "#888"
                  },
                  className: "jsx-ab3c149bca899a0f text-[10px] font-mono",
                  children: [100, " levels await beyond..."]
                })]
              })
            })]
          })
        }), (0, o.jsx)("div", {
          style: {
            borderTop: "1px solid rgba(0, 255, 255, 0.1)",
            background: "linear-gradient(0deg, rgba(5,5,16,0.98) 0%, rgba(5,5,16,0.92) 100%)"
          },
          className: "jsx-ab3c149bca899a0f relative z-10 flex-shrink-0 px-4 py-2.5",
          children: (0, o.jsxs)("div", {
            className: "jsx-ab3c149bca899a0f flex items-center justify-center gap-5 text-[9px] font-mono",
            children: [(0, o.jsxs)("div", {
              className: "jsx-ab3c149bca899a0f flex items-center gap-1",
              children: [(0, o.jsx)("div", {
                style: {
                  backgroundColor: s,
                  boxShadow: "0 0 4px #00ff66"
                },
                className: "jsx-ab3c149bca899a0f w-2.5 h-2.5 rounded-sm"
              }), (0, o.jsx)("span", {
                style: {
                  color: "#666"
                },
                className: "jsx-ab3c149bca899a0f",
                children: "Cleared"
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-ab3c149bca899a0f flex items-center gap-1",
              children: [(0, o.jsx)("div", {
                style: {
                  backgroundColor: m,
                  boxShadow: "0 0 4px #ffd700"
                },
                className: "jsx-ab3c149bca899a0f w-2.5 h-2.5 rounded-sm"
              }), (0, o.jsx)("span", {
                style: {
                  color: "#666"
                },
                className: "jsx-ab3c149bca899a0f",
                children: "Current"
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-ab3c149bca899a0f flex items-center gap-1",
              children: [(0, o.jsx)("div", {
                style: {
                  backgroundColor: "#0a0a15"
                },
                className: "jsx-ab3c149bca899a0f w-2.5 h-2.5 rounded-sm border border-[#333]"
              }), (0, o.jsx)("span", {
                style: {
                  color: "#666"
                },
                className: "jsx-ab3c149bca899a0f",
                children: "Locked"
              })]
            }), (0, o.jsxs)("div", {
              className: "jsx-ab3c149bca899a0f flex items-center gap-1",
              children: [(0, o.jsx)("span", {
                style: {
                  fontSize: 10
                },
                className: "jsx-ab3c149bca899a0f",
                children: "👑"
              }), (0, o.jsx)("span", {
                style: {
                  color: "#666"
                },
                className: "jsx-ab3c149bca899a0f",
                children: "Boss"
              })]
            })]
          })
        }), (0, o.jsx)(e9.default, {
          id: "ab3c149bca899a0f",
          children: "@keyframes float-up{0%{opacity:0;transform:translateY(0)scale(1)}20%{opacity:.8}to{opacity:0;transform:translateY(-40px)scale(.3)}}@keyframes fog-drift{0%{transform:translate(-5%)scaleY(1)}to{transform:translate(5%)scaleY(1.1)}}"
        })]
      })
    }

    function tB({
      onComplete: e
    }) {
      let [t, l] = (0, a.useState)(0);
      return (0, a.useEffect)(() => {
        let e = setInterval(() => {
          l(t => t >= 100 ? (clearInterval(e), 100) : t + 2)
        }, 60);
        return () => clearInterval(e)
      }, []), (0, a.useEffect)(() => {
        if (t >= 100) {
          let t = setTimeout(e, 300);
          return () => clearTimeout(t)
        }
      }, [t, e]), (0, o.jsx)("div", {
        className: "fixed inset-0 z-50 flex flex-col items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.95)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("div", {
            className: "text-2xl font-bold font-mono mb-4",
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            children: "🎬 WATCHING AD"
          }), (0, o.jsx)("div", {
            className: "w-64 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${t}%`,
                backgroundColor: n,
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: t < 100 ? "Please wait..." : "✅ 2x Reward unlocked!"
          })]
        })
      })
    }

    function tG() {
      let e = ea(e => e.saveData),
        t = ea(e => e.claimDailyReward),
        [l, r] = (0, a.useState)(!1),
        [c, d] = (0, a.useState)(0),
        [h, f] = (0, a.useState)(0),
        [u, x] = (0, a.useState)(!1),
        [p, g] = (0, a.useState)(!1),
        [y, b] = (0, a.useState)(!1),
        v = e.dailyRewardStreak || 0,
        w = h || Math.min(v, 7),
        k = (0, a.useCallback)(() => {
          eo.init(), eo.playCoinCollect();
          let e = t();
          e && (r(!0), d(e.coins), f(e.day), g(!0), setTimeout(() => g(!1), 1e3))
        }, [t]),
        C = (0, a.useCallback)(() => {
          b(!0)
        }, []),
        S = (0, a.useCallback)(() => {
          b(!1), ea.getState().addCoinsReward(c), x(!0), eo.playCoinCollect()
        }, [c]),
        T = (0, a.useCallback)(() => {
          eo.init(), eo.playMenuClick(), window.dispatchEvent(new Event("daily-reward-dismissed"))
        }, []);
      return (0, o.jsxs)("div", {
        style: {
          backgroundColor: "rgba(0,0,0,0.9)"
        },
        className: "jsx-326cf905996ee422 fixed inset-0 z-40 flex items-center justify-center",
        children: [y && (0, o.jsx)(tB, {
          onComplete: S
        }), (0, o.jsxs)("div", {
          style: {
            backgroundColor: "#0a0a20",
            border: "2px solid #ffd70060",
            boxShadow: "0 0 40px rgba(255,215,0,0.2), inset 0 0 40px rgba(255,215,0,0.05)"
          },
          className: "jsx-326cf905996ee422 text-center p-6 rounded-xl max-w-sm w-full mx-4",
          children: [(0, o.jsx)("h2", {
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            className: "jsx-326cf905996ee422 text-2xl font-bold font-mono tracking-wider mb-1",
            children: "📅 DAILY REWARD"
          }), (0, o.jsx)("p", {
            style: {
              color: "#888"
            },
            className: "jsx-326cf905996ee422 text-xs font-mono mb-4",
            children: "Login every day for bigger rewards!"
          }), (0, o.jsx)("div", {
            className: "jsx-326cf905996ee422 grid grid-cols-7 gap-1 mb-4",
            children: N.map((e, t) => {
              let a = t + 1,
                r = a === (l ? w : Math.min(v + 1, 7)),
                i = a <= v || l && a < w,
                c = l && a === w;
              return (0, o.jsxs)("div", {
                style: {
                  backgroundColor: c ? "rgba(255,215,0,0.15)" : r ? "rgba(0,255,255,0.1)" :
                    i ? "rgba(0,255,102,0.08)" : "rgba(0,0,0,0.3)",
                  border: `1px solid ${c?"#ffd700":r?n:i?"#00ff6640":"#33333330"}`
                },
                className: "jsx-326cf905996ee422 flex flex-col items-center p-1.5 rounded",
                children: [(0, o.jsxs)("div", {
                  style: {
                    color: c ? m : r ? n : i ? s : "#444"
                  },
                  className: "jsx-326cf905996ee422 text-[7px] font-mono font-bold",
                  children: ["D", a]
                }), (0, o.jsx)("div", {
                  style: {
                    color: c ? m : i ? "#888" : "#555"
                  },
                  className: "jsx-326cf905996ee422 text-[9px] font-mono font-bold",
                  children: c ? "✓" : `${e.coins}`
                })]
              }, a)
            })
          }), !l && (0, o.jsxs)("div", {
            style: {
              backgroundColor: "rgba(255,215,0,0.08)",
              border: "1px solid #ffd70030"
            },
            className: "jsx-326cf905996ee422 mb-4 p-3 rounded-lg",
            children: [(0, o.jsx)("div", {
              style: {
                color: "#888"
              },
              className: "jsx-326cf905996ee422 text-xs font-mono mb-1",
              children: "TODAY'S REWARD"
            }), (0, o.jsxs)("div", {
              style: {
                color: m,
                textShadow: "0 0 15px #ffd700"
              },
              className: "jsx-326cf905996ee422 text-3xl font-bold font-mono",
              children: ["🪙 ", N[Math.min(v, 6)]?.coins || 50]
            })]
          }), l && p && (0, o.jsxs)("div", {
            style: {
              backgroundColor: "rgba(0,255,102,0.1)",
              border: "1px solid rgba(0,255,102,0.3)",
              animation: "neon-pulse 0.5s ease-out"
            },
            className: "jsx-326cf905996ee422 mb-4 p-3 rounded-lg",
            children: [(0, o.jsxs)("div", {
              style: {
                color: s,
                textShadow: "0 0 15px #00ff66"
              },
              className: "jsx-326cf905996ee422 text-xl font-bold font-mono",
              children: ["+", c, " 🪙"]
            }), u && (0, o.jsxs)("div", {
              style: {
                color: i,
                textShadow: "0 0 10px #ff00ff"
              },
              className: "jsx-326cf905996ee422 text-lg font-bold font-mono mt-1",
              children: ["+", c, " BONUS! 🎬"]
            })]
          }), l && !p && (0, o.jsxs)("div", {
            style: {
              backgroundColor: "rgba(0,255,102,0.1)",
              border: "1px solid rgba(0,255,102,0.3)"
            },
            className: "jsx-326cf905996ee422 mb-4 p-3 rounded-lg",
            children: [(0, o.jsxs)("div", {
              style: {
                color: s,
                textShadow: "0 0 15px #00ff66"
              },
              className: "jsx-326cf905996ee422 text-xl font-bold font-mono",
              children: ["+", c, " 🪙 CLAIMED!"]
            }), u && (0, o.jsxs)("div", {
              style: {
                color: i,
                textShadow: "0 0 10px #ff00ff"
              },
              className: "jsx-326cf905996ee422 text-lg font-bold font-mono mt-1",
              children: ["+", c, " BONUS! 🎬"]
            })]
          }), (0, o.jsxs)("div", {
            className: "jsx-326cf905996ee422 flex flex-col gap-2",
            children: [!l && (0, o.jsx)("button", {
              onClick: k,
              style: {
                borderColor: m,
                color: m,
                textShadow: "0 0 10px #ffd700",
                boxShadow: "0 0 20px rgba(255,215,0,0.3)",
                animation: "neon-pulse 2s ease-in-out infinite"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              className: "jsx-326cf905996ee422 neon-btn w-full py-3 px-4 text-lg font-bold font-mono tracking-wider",
              children: "🪙 CLAIM"
            }), l && !u && (0, o.jsx)("button", {
              onClick: C,
              style: {
                borderColor: n,
                color: n,
                textShadow: "0 0 8px #00ffff"
              },
              onMouseEnter: () => {
                eo.init(), eo.playMenuHover()
              },
              className: "jsx-326cf905996ee422 neon-btn w-full py-2 px-4 text-sm font-bold font-mono tracking-wider",
              children: "🎬 WATCH AD FOR 2X"
            }), (0, o.jsx)("button", {
              onClick: T,
              style: {
                color: "#666",
                border: "1px solid #333"
              },
              className: "jsx-326cf905996ee422 text-xs font-mono px-4 py-1.5 rounded",
              children: l ? "CLOSE" : "SKIP"
            })]
          }), (0, o.jsxs)("div", {
            style: {
              color: "#555"
            },
            className: "jsx-326cf905996ee422 mt-3 text-[9px] font-mono",
            children: ["Streak: ", l ? w : v, " / 7 days"]
          })]
        }), (0, o.jsx)(e9.default, {
          id: "326cf905996ee422",
          children: "@keyframes neon-pulse{0%,to{opacity:1}50%{opacity:.85}}"
        })]
      })
    }
    let t$ = {
        damage: "⚔️",
        fireRate: "🔥",
        bulletSpeed: "💨",
        bulletSize: "⭕",
        criticalChance: "💥"
      },
      tF = {
        damage: f,
        fireRate: c,
        bulletSpeed: n,
        bulletSize: i,
        criticalChance: m
      },
      tH = {
        damage: "+15% damage per level",
        fireRate: "+10% faster shooting per level",
        bulletSpeed: "+12% bullet speed per level",
        bulletSize: "+10% bullet size per level",
        criticalChance: "+2% crit chance per level (max 50)"
      };

    function tU({
      onComplete: e
    }) {
      let [t, l] = (0, a.useState)(0);
      return (0, a.useEffect)(() => {
        let e = setInterval(() => {
          l(t => t >= 100 ? (clearInterval(e), 100) : t + 2)
        }, 60);
        return () => clearInterval(e)
      }, []), (0, a.useEffect)(() => {
        if (t >= 100) {
          let t = setTimeout(e, 300);
          return () => clearTimeout(t)
        }
      }, [t, e]), (0, o.jsx)("div", {
        className: "fixed inset-0 z-50 flex flex-col items-center justify-center",
        style: {
          backgroundColor: "rgba(0,0,0,0.95)"
        },
        children: (0, o.jsxs)("div", {
          className: "text-center",
          children: [(0, o.jsx)("div", {
            className: "text-2xl font-bold font-mono mb-4",
            style: {
              color: m,
              textShadow: "0 0 15px #ffd700"
            },
            children: "🎬 WATCHING AD"
          }), (0, o.jsx)("div", {
            className: "w-64 h-3 rounded-full mx-auto mb-3",
            style: {
              backgroundColor: "#222",
              border: "1px solid #444"
            },
            children: (0, o.jsx)("div", {
              className: "h-full rounded-full transition-all duration-100",
              style: {
                width: `${t}%`,
                backgroundColor: n,
                boxShadow: "0 0 10px #00ffff"
              }
            })
          }), (0, o.jsx)("div", {
            className: "text-sm font-mono",
            style: {
              color: "#888"
            },
            children: t < 100 ? "Please wait..." : "✅ Free upgrade unlocked!"
          })]
        })
      })
    }

    function tV() {
      let e = ea(e => e.saveData),
        t = ea(e => e.setGamePhase),
        l = ea(e => e.upgradeWeapon),
        r = ea(e => e.upgradeWeaponByAd),
        i = ea(e => e.addCoinsReward),
        [c, d] = (0, a.useState)(!1),
        [h, u] = (0, a.useState)(null),
        x = e => {
          eo.init(), eo.playMenuClick(), e()
        },
        p = (0, a.useCallback)(() => {
          d(!1), h && (i(200), r(h), eo.playCoinCollect(), u(null))
        }, [h, i, r]);
      return (0, o.jsxs)("div", {
        className: "absolute inset-0 z-20 flex flex-col pointer-events-auto",
        style: {
          backgroundColor: "rgba(5,5,16,0.92)"
        },
        children: [c && (0, o.jsx)(tU, {
          onComplete: p
        }), (0, o.jsx)("div", {
          className: "flex-1 overflow-y-auto px-3 py-4",
          style: {
            scrollbarWidth: "none"
          },
          children: (0, o.jsxs)("div", {
            className: "max-w-md mx-auto",
            children: [(0, o.jsxs)("div", {
              className: "text-center mb-3",
              children: [(0, o.jsx)("h2", {
                className: "text-xl font-bold font-mono tracking-wider",
                style: {
                  color: f,
                  textShadow: "0 0 15px #ff3333, 0 0 30px #ff333366"
                },
                children: "🔫 WEAPON UPGRADES"
              }), (0, o.jsxs)("div", {
                className: "text-xs font-mono mt-1",
                style: {
                  color: m
                },
                children: ["🪙 ", e.totalCoins.toLocaleString(), " COINS"]
              })]
            }), (0, o.jsx)("div", {
              className: "space-y-2.5",
              children: ["damage", "fireRate", "bulletSpeed", "bulletSize", "criticalChance"]
                .map(t => {
                  let a = y[t],
                    r = e.weaponUpgrades[t] ?? 0,
                    i = b(t, r),
                    c = e.totalCoins >= i,
                    h = r >= a.maxLevel,
                    f = tF[t],
                    p = t$[t],
                    g = tH[t],
                    v = r > 0 ? `+${(r*a.effectPerLevel*100).toFixed(0)}%` : "Base",
                    w = h ? "MAX" : `+${((r+1)*a.effectPerLevel*100).toFixed(0)}%`;
                  return (0, o.jsxs)("div", {
                    className: "rounded-xl p-3",
                    style: {
                      backgroundColor: `${f}08`,
                      border: `1.5px solid ${f}30`,
                      boxShadow: `0 0 12px ${f}08`
                    },
                    children: [(0, o.jsxs)("div", {
                      className: "flex items-center gap-2 mb-1.5",
                      children: [(0, o.jsx)("span", {
                        className: "text-lg",
                        children: p
                      }), (0, o.jsxs)("div", {
                        className: "flex-1",
                        children: [(0, o.jsxs)("div", {
                          className: "flex items-center gap-2",
                          children: [(0, o.jsx)("span", {
                            className: "font-bold text-sm font-mono",
                            style: {
                              color: f
                            },
                            children: a.name
                          }), (0, o.jsxs)("span", {
                            className: "text-[9px] font-mono font-bold px-1.5 py-0.5 rounded",
                            style: {
                              backgroundColor: `${f}20`,
                              color: f,
                              border: `1px solid ${f}40`
                            },
                            children: ["LV ", r]
                          })]
                        }), (0, o.jsx)("div", {
                          className: "text-[9px] font-mono",
                          style: {
                            color: "#888"
                          },
                          children: g
                        })]
                      })]
                    }), (0, o.jsxs)("div", {
                      className: "flex items-center gap-2 mb-2 text-[10px] font-mono",
                      children: [(0, o.jsx)("span", {
                        style: {
                          color: "#666"
                        },
                        children: "Current:"
                      }), (0, o.jsx)("span", {
                        style: {
                          color: r > 0 ? s : "#555"
                        },
                        children: v
                      }), !h && (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)("span", {
                          style: {
                            color: "#444"
                          },
                          children: "→"
                        }), (0, o.jsx)("span", {
                          style: {
                            color: f
                          },
                          children: w
                        })]
                      })]
                    }), (0, o.jsx)("div", {
                      className: "w-full h-1.5 rounded-full mb-2",
                      style: {
                        backgroundColor: "#1a1a2a"
                      },
                      children: (0, o.jsx)("div", {
                        className: "h-full rounded-full transition-all duration-300",
                        style: {
                          width: h ? "100%" :
                            `${Math.min(100,r/Math.min(a.maxLevel,50)*100)}%`,
                          backgroundColor: h ? m : f,
                          boxShadow: `0 0 6px ${h?m:f}66`
                        }
                      })
                    }), !h && (0, o.jsxs)("div", {
                      className: "flex gap-2",
                      children: [(0, o.jsxs)("button", {
                        onClick: () => x(() => {
                          l(t) && eo.playCoinCollect()
                        }),
                        className: "flex-1 py-1.5 px-2 rounded-lg text-xs font-mono font-bold transition-all",
                        style: {
                          backgroundColor: c ? "rgba(255,215,0,0.12)" :
                            "rgba(0,0,0,0.3)",
                          border: `1.5px solid ${c?"#ffd700":"#333"}`,
                          color: c ? "#ffd700" : "#555",
                          textShadow: c ? "0 0 6px #ffd70066" : "none",
                          cursor: c ? "pointer" : "not-allowed"
                        },
                        children: ["🪙 ", i.toLocaleString()]
                      }), (0, o.jsx)("button", {
                        onClick: () => x(() => {
                          d(!0), u(t)
                        }),
                        className: "flex-1 py-1.5 px-2 rounded-lg text-xs font-mono font-bold transition-all",
                        style: {
                          backgroundColor: "rgba(0,255,255,0.08)",
                          border: "1.5px solid rgba(0,255,255,0.4)",
                          color: n,
                          textShadow: "0 0 6px #00ffff66",
                          cursor: "pointer"
                        },
                        children: "🎬 AD (FREE)"
                      })]
                    }), h && (0, o.jsx)("div", {
                      className: "text-center text-xs font-mono font-bold py-1",
                      style: {
                        color: m,
                        textShadow: "0 0 8px #ffd700"
                      },
                      children: "★ MAX LEVEL ★"
                    })]
                  }, t)
                })
            }), (0, o.jsx)("div", {
              className: "text-center mt-4 text-[8px] font-mono",
              style: {
                color: "#ffffff22"
              },
              children: "Watch ads for free upgrades • Prices increase exponentially • No limit on upgrades"
            }), (0, o.jsx)("button", {
              onClick: () => x(() => t("menu")),
              className: "neon-btn w-full py-2 mt-3 text-xs tracking-wider font-mono font-bold",
              style: {
                borderColor: "#666",
                color: "#888"
              },
              children: "← BACK TO MENU"
            })]
          })
        })]
      })
    }
    e.s(["default", 0, function() {
      let e = ea(e => e.gamePhase),
        t = ea(e => e.setGamePhase),
        l = ea(e => e.saveData),
        r = ea(e => e.setCloudSync),
        n = ea(e => e.loadCloudSave);
      (0, a.useEffect)(() => {
        eb.initialize(), eu(), ed();
        let e = !1;
        return es(async t => {
          if (r(!!t.user), t.user && !e) {
            e = !0;
            try {
              let e = await (0, ep.downloadSaveFromCloud)();
              e && n(e)
            } catch {}
          }
        })
      }, [r, n]);
      let [i, s] = (0, a.useState)(() => {
        try {
          let e = localStorage.getItem("neon-stickwar-save");
          if (e) {
            let t = JSON.parse(e);
            if (t && t.highestLevel > 0) return !0
          }
        } catch {}
        return !1
      }), [c, d] = (0, a.useState)(""), h = (0, a.useMemo)(() => "menu" === e && Q(l) && l
        .lastDailyRewardDay !== c, [e, l, c]);
      return ((0, a.useEffect)(() => {
        let e = () => {
          d(l.lastDailyRewardDay)
        };
        return window.addEventListener("daily-reward-dismissed", e), () => window.removeEventListener(
          "daily-reward-dismissed", e)
      }, [l.lastDailyRewardDay]), (0, a.useEffect)(() => {
        i && "splash" === e && t("menu")
      }, [i, e, t]), (0, a.useEffect)(() => {
        if (!i) {
          let e = setTimeout(() => {
            s(!0), t("menu")
          }, 1e4);
          return () => clearTimeout(e)
        }
      }, [i, t]), (0, a.useEffect)(() => {
        let e = () => {
          i || (s(!0), t("menu"))
        };
        return window.addEventListener("splash-end", e), () => window.removeEventListener("splash-end",
          e)
      }, [i, t]), (0, a.useEffect)(() => {
        if ("u" > typeof screen && screen.orientation && "lock" in screen.orientation) try {
          screen.orientation.lock("landscape").catch(() => {})
        } catch {}
      }, []), i || "splash" !== e) ? (0, o.jsxs)("main", {
        className: "fixed inset-0 w-screen h-[100dvh] bg-[#050510] overflow-hidden",
        children: [(0, o.jsx)(eC, {}), h && (0, o.jsx)(tG, {}), (0, o.jsx)(e6, {}), "menu" === e && (0, o
            .jsx)(eI, {}), "cutscene" === e && (0, o.jsx)(ta, {}), "game-over" === e && (0, o.jsx)(
            e8, {}), "level-complete" === e && (0, o.jsx)(te, {}), "victory" === e && (0, o.jsx)(
          tt, {}), "skin-shop" === e && (0, o.jsx)(tc, {}), "skill-shop" === e && (0, o.jsx)(tg, {}),
          "settings" === e && (0, o.jsx)(ty, {}), "profile" === e && (0, o.jsx)(tN, {}),
          "leaderboard" === e && (0, o.jsx)(tA, {}), "level-map" === e && (0, o.jsx)(tO, {}),
          "weapon-shop" === e && (0, o.jsx)(tV, {}), "online-arena" === e && (0, o.jsx)(tk, {}),
          "online-lobby" === e && (0, o.jsx)(tk, {})
        ]
      }) : (0, o.jsx)("main", {
        className: "fixed inset-0 w-screen h-[100dvh] bg-[#050510] overflow-hidden",
        children: (0, o.jsx)(tS, {})
      })
    }], 52683)
  }
]);